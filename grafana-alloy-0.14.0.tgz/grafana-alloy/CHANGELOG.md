# Changelog

## [0.14.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.13.0...grafana-alloy-v0.14.0) (2026-11-02)


### Features

* **grafana-alloy:** add scrapeSelected to scrape named Services and Pods once per cluster ([#616](https://github.com/chanzuckerberg/argo-helm-charts/issues/616)) ([8a4dc05](https://github.com/chanzuckerberg/argo-helm-charts/commit/8a4dc059748f34574e94f26ada8c847246557fde))

## [0.13.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.12.0...grafana-alloy-v0.13.0) (2026-11-02)


### Features

* **grafana-alloy:** add alloyConfig.extraContent to append config to a hand-written pipeline ([#614](https://github.com/chanzuckerberg/argo-helm-charts/issues/614)) ([e9b68ae](https://github.com/chanzuckerberg/argo-helm-charts/commit/e9b68ae352c5069d88ea39168d85b19b7255be8e))

## [0.12.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.11.0...grafana-alloy-v0.12.0) (2026-10-26)


### Features

* **grafana-alloy:** add scrapePushgateway to scrape the Pushgateway with honor_labels (CCIE-7593) ([#602](https://github.com/chanzuckerberg/argo-helm-charts/issues/602)) ([9eebb11](https://github.com/chanzuckerberg/argo-helm-charts/commit/9eebb117b835e45b7b9f001399b85840a3f4c1ff))

## [0.11.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.10.1...grafana-alloy-v0.11.0) (2026-10-21)


### Features

* **grafana-alloy:** add bearerAuth to Loki endpoints for token file authentication ([#599](https://github.com/chanzuckerberg/argo-helm-charts/issues/599)) ([56e846d](https://github.com/chanzuckerberg/argo-helm-charts/commit/56e846df314f68cb9eac6d1bdc9fc76be7b60659))

## [0.10.1](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.10.0...grafana-alloy-v0.10.1) (2026-07-08)


### Bug Fixes

* **grafana-alloy:** derive ConfigMap name from configMap.name value ([#501](https://github.com/chanzuckerberg/argo-helm-charts/issues/501)) ([7b9771b](https://github.com/chanzuckerberg/argo-helm-charts/commit/7b9771b3657e07dda579926f845ace00ba3a2d02))

## [0.10.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.9.0...grafana-alloy-v0.10.0) (2026-06-03)


### Features

* node-shard cluster-wide scrapes (avoids grafana-alloy clustering) ([#471](https://github.com/chanzuckerberg/argo-helm-charts/issues/471)) ([086a1ab](https://github.com/chanzuckerberg/argo-helm-charts/commit/086a1aba658baa3ef1dd5be8d99d2a252f2ccd15))


### Bug Fixes

* shard pods_metrics discovery by node to stop duplicate scrapes ([#468](https://github.com/chanzuckerberg/argo-helm-charts/issues/468)) ([328f12e](https://github.com/chanzuckerberg/argo-helm-charts/commit/328f12e5874f264563181bf858329ad487966f94))

## [0.9.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.8.1...grafana-alloy-v0.9.0) (2026-05-19)


### Features

* Allow node level metric scraping ([#456](https://github.com/chanzuckerberg/argo-helm-charts/issues/456)) ([ee6b899](https://github.com/chanzuckerberg/argo-helm-charts/commit/ee6b8992132df639b2b073b6ba489b773e9b8ae7))

## [0.8.1](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.8.0...grafana-alloy-v0.8.1) (2026-04-21)


### Bug Fixes

* release please version release broken ([#443](https://github.com/chanzuckerberg/argo-helm-charts/issues/443)) ([1ae5eb1](https://github.com/chanzuckerberg/argo-helm-charts/commit/1ae5eb12be74719b571b443f0bff2c97ad3a58df))

## [0.8.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.7.0...grafana-alloy-v0.8.0) (2026-04-02)


### Features

* add relabelNamespace to copy exported_namespace to namespace ([#412](https://github.com/chanzuckerberg/argo-helm-charts/issues/412)) ([12004f1](https://github.com/chanzuckerberg/argo-helm-charts/commit/12004f198253c3984c6a4d6ce0f76156c48f9579))
* remote write, scrapes, and relabeling ([#420](https://github.com/chanzuckerberg/argo-helm-charts/issues/420)) ([f2578f0](https://github.com/chanzuckerberg/argo-helm-charts/commit/f2578f07b2fcc83f98f5895cee44eaf287859884))

## [0.7.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.6.0...grafana-alloy-v0.7.0) (2026-03-19)


### Features

* Add shardByNode option for kubelet and cadvisor scraping ([#407](https://github.com/chanzuckerberg/argo-helm-charts/issues/407)) ([493d52e](https://github.com/chanzuckerberg/argo-helm-charts/commit/493d52e476f45326e2a44897bd2723ae6bc2e816))

## [0.6.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.5.0...grafana-alloy-v0.6.0) (2026-03-13)


### Features

* Enable tailscale metric scraping ([#386](https://github.com/chanzuckerberg/argo-helm-charts/issues/386)) ([86bc9fe](https://github.com/chanzuckerberg/argo-helm-charts/commit/86bc9fe2d8d0ef82ba0c222ea6fcd611537c57ce))

## [0.5.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.4.0...grafana-alloy-v0.5.0) (2026-02-17)


### ⚠ BREAKING CHANGES

* Switched grafana alloy kube-state-metrics label to selector ([#375](https://github.com/chanzuckerberg/argo-helm-charts/issues/375))
* Add metrics and logs support to grafana-alloy chart [DO NOT MERGE]  ([#354](https://github.com/chanzuckerberg/argo-helm-charts/issues/354))

### Features

* Add metrics and logs support to grafana-alloy chart [DO NOT MERGE]  ([#354](https://github.com/chanzuckerberg/argo-helm-charts/issues/354)) ([ca28853](https://github.com/chanzuckerberg/argo-helm-charts/commit/ca288534328f9d04c8b86820cc0ca7d2c29fa7c7))
* Allow grafana-alloy to scrape service endpoints ([#380](https://github.com/chanzuckerberg/argo-helm-charts/issues/380)) ([a11c9bc](https://github.com/chanzuckerberg/argo-helm-charts/commit/a11c9bcd9d74743ad221ed2943f663ceffcc8977))
* Enable basic auth support for prometheus remote write endpoints ([#372](https://github.com/chanzuckerberg/argo-helm-charts/issues/372)) ([c7566a2](https://github.com/chanzuckerberg/argo-helm-charts/commit/c7566a2f87db27160074281f998541c94e81622b))
* enable Beyla for ebpf in Grafana Alloy ([#363](https://github.com/chanzuckerberg/argo-helm-charts/issues/363)) ([f4eff06](https://github.com/chanzuckerberg/argo-helm-charts/commit/f4eff0659ac6916c7e17ce9a9d767a4300abfd8d))
* Enable grafana alloy to scrape kubelet and cadvisor metrics ([#376](https://github.com/chanzuckerberg/argo-helm-charts/issues/376)) ([760a632](https://github.com/chanzuckerberg/argo-helm-charts/commit/760a6326906db70f412e8e76cf40c70f79d36cda))
* Extract all kuberentes node labels in grafana alloy ([#377](https://github.com/chanzuckerberg/argo-helm-charts/issues/377)) ([a069ba0](https://github.com/chanzuckerberg/argo-helm-charts/commit/a069ba01ecb9a0346d088ee7e80fc91d92291bcd))
* Retain kubernetes_build_info region label only ([#379](https://github.com/chanzuckerberg/argo-helm-charts/issues/379)) ([0f43663](https://github.com/chanzuckerberg/argo-helm-charts/commit/0f43663f7c0cb8fe5e609529507d3daccc0639f3))
* Scrape kube state metrics in grafana alloy ([#374](https://github.com/chanzuckerberg/argo-helm-charts/issues/374)) ([2f8e8d9](https://github.com/chanzuckerberg/argo-helm-charts/commit/2f8e8d99c201d0ea459920bfcfaf21cf9d4262dc))
* Support log level for alloy and beyla ([#373](https://github.com/chanzuckerberg/argo-helm-charts/issues/373)) ([14ccc84](https://github.com/chanzuckerberg/argo-helm-charts/commit/14ccc8445ad4aa801560468e07016391653d39cc))
* Switched grafana alloy kube-state-metrics label to selector ([#375](https://github.com/chanzuckerberg/argo-helm-charts/issues/375)) ([ad4378f](https://github.com/chanzuckerberg/argo-helm-charts/commit/ad4378fc00a40375b0bfa082d77ff7c7ab92516a))


### Bug Fixes

* allow debug mode for beyla ([#366](https://github.com/chanzuckerberg/argo-helm-charts/issues/366)) ([103bd00](https://github.com/chanzuckerberg/argo-helm-charts/commit/103bd0078cadd437f9429c940cbbfdf9e37edafd))
* experimenting different beyla config ([#368](https://github.com/chanzuckerberg/argo-helm-charts/issues/368)) ([95f3868](https://github.com/chanzuckerberg/argo-helm-charts/commit/95f386823cf96d93726f1aa36eab1a7b423afccc))
* Fix alloy namespace labels for cadvisor and kube-state-metrics metrics ([#381](https://github.com/chanzuckerberg/argo-helm-charts/issues/381)) ([f31df4e](https://github.com/chanzuckerberg/argo-helm-charts/commit/f31df4e14f520e1dc02f6d774764fcc361f72aaf))
* Fix kubelet metrics label extraction (we are looking for topology labels) ([#378](https://github.com/chanzuckerberg/argo-helm-charts/issues/378)) ([073a0b3](https://github.com/chanzuckerberg/argo-helm-charts/commit/073a0b39ca61aab2e1f7e86638a03e6a2a601c07))
* grafana beyla config type error ([#364](https://github.com/chanzuckerberg/argo-helm-charts/issues/364)) ([773fc44](https://github.com/chanzuckerberg/argo-helm-charts/commit/773fc44ea0da1143592f6c5d69fdd01fb059deae))
* grafana metric output ([#365](https://github.com/chanzuckerberg/argo-helm-charts/issues/365)) ([41c4e6b](https://github.com/chanzuckerberg/argo-helm-charts/commit/41c4e6baad28869733a31c837947dd6eaa9cdf7a))
* type mismatch ([#367](https://github.com/chanzuckerberg/argo-helm-charts/issues/367)) ([9ac22fd](https://github.com/chanzuckerberg/argo-helm-charts/commit/9ac22fd6c04521526f4ce1604f613057aeaf1f74))

## [0.4.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.3.0...grafana-alloy-v0.4.0) (2026-01-15)


### Features

* Parametrize basic auth credential environment variable name for grafana alloy ([#352](https://github.com/chanzuckerberg/argo-helm-charts/issues/352)) ([92c1fad](https://github.com/chanzuckerberg/argo-helm-charts/commit/92c1fad276bbc81834ec4428a39ef971f8ada951))

## [0.3.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.2.0...grafana-alloy-v0.3.0) (2026-01-05)


### Features

* Disable central loki by default in grafana-alloy chart ([#348](https://github.com/chanzuckerberg/argo-helm-charts/issues/348)) ([a34b484](https://github.com/chanzuckerberg/argo-helm-charts/commit/a34b484a8a2dec5a6bca993830ba0ed74024a0c8))

## [0.2.0](https://github.com/chanzuckerberg/argo-helm-charts/compare/grafana-alloy-v0.1.0...grafana-alloy-v0.2.0) (2026-01-05)


### Features

* Grafana Alloy chart ([#347](https://github.com/chanzuckerberg/argo-helm-charts/issues/347)) ([1fd6265](https://github.com/chanzuckerberg/argo-helm-charts/commit/1fd6265be1589345db9b8623c8b2b8569eb2712d))
