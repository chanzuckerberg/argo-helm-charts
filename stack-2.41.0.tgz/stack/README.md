# stack

**Title:** stack

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                               | Pattern | Type   | Deprecated | Definition | Title/Description                                                                                            |
| -------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------ |
| - [argus-config](#argus-config )       | No      | object | No         | -          | Allows values for the argus-config Helm chart                                                                |
| - [cronJobs](#cronJobs )               | No      | object | No         | -          | Cron jobs to deploy                                                                                          |
| - [global](#global )                   | No      | object | No         | -          | Global configuration for the stack - this serves as the default configuration for all services/jobs/cronjobs |
| - [jobs](#jobs )                       | No      | object | No         | -          | Jobs to deploy                                                                                               |
| - [rollout](#rollout )                 | No      | object | No         | -          | -                                                                                                            |
| - [rolloutAnalysis](#rolloutAnalysis ) | No      | object | No         | -          | defines a template that is used to create a analysisRun                                                      |
| - [services](#services )               | No      | object | No         | -          | Services to deploy                                                                                           |

## <a name="argus-config"></a>1. Property `stack > argus-config`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Allows values for the argus-config Helm chart

## <a name="cronJobs"></a>2. Property `stack > cronJobs`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Cron jobs to deploy

| Property                      | Pattern | Type   | Deprecated | Definition             | Title/Description                                                                                            |
| ----------------------------- | ------- | ------ | ---------- | ---------------------- | ------------------------------------------------------------------------------------------------------------ |
| - [^.*$](#cronJobs_pattern1 ) | Yes     | object | No         | In #/properties/global | Global configuration for the stack - this serves as the default configuration for all services/jobs/cronjobs |

### <a name="cronJobs_pattern1"></a>2.1. Pattern Property `stack > cronJobs > global`
> All properties whose name matches the regular expression
```^.*$``` ([Test](https://regex101.com/?regex=%5E.%2A%24))
must respect the following conditions

|                           |                     |
| ------------------------- | ------------------- |
| **Type**                  | `object`            |
| **Required**              | No                  |
| **Additional properties** | Any type allowed    |
| **Defined in**            | #/properties/global |

**Description:** Global configuration for the stack - this serves as the default configuration for all services/jobs/cronjobs

| Property                                                                     | Pattern | Type             | Deprecated | Definition              | Title/Description                                                                                                                                                                                                                                                                |
| ---------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [affinity](#cronJobs_pattern1_affinity )                                   | No      | object           | No         | -                       | Affinity for the pod                                                                                                                                                                                                                                                             |
| - [annotations](#cronJobs_pattern1_annotations )                             | No      | object           | No         | -                       | Global annotations to add to all resources                                                                                                                                                                                                                                       |
| - [appContext](#cronJobs_pattern1_appContext )                               | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [appSecrets](#cronJobs_pattern1_appSecrets )                               | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [argoBuildEnv](#cronJobs_pattern1_argoBuildEnv )                           | No      | object           | No         | -                       | Argo built-in environment parameters (provided by Argus API)                                                                                                                                                                                                                     |
| - [args](#cronJobs_pattern1_args )                                           | No      | array of string  | No         | -                       | Arguments to pass to the command in the primary container                                                                                                                                                                                                                        |
| - [argusMetadata](#cronJobs_pattern1_argusMetadata )                         | No      | object           | No         | -                       | Argus metadata (provided by Argus API)                                                                                                                                                                                                                                           |
| - [autoscaling](#cronJobs_pattern1_autoscaling )                             | No      | object           | No         | -                       | Autoscaling configuration                                                                                                                                                                                                                                                        |
| - [command](#cronJobs_pattern1_command )                                     | No      | array of string  | No         | -                       | Command to run in the primary container                                                                                                                                                                                                                                          |
| - [deploymentKind](#cronJobs_pattern1_deploymentKind )                       | No      | enum (of string) | No         | -                       | Specifies the Kubernetes Kind for the main application workload controller (Deployment or Rollout).                                                                                                                                                                              |
| - [deploymentStage](#cronJobs_pattern1_deploymentStage )                     | No      | string           | No         | -                       | Deployment stage                                                                                                                                                                                                                                                                 |
| - [dnsPolicy](#cronJobs_pattern1_dnsPolicy )                                 | No      | enum (of string) | No         | -                       | DNS policy for the pod                                                                                                                                                                                                                                                           |
| - [env](#cronJobs_pattern1_env )                                             | No      | array of object  | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [envFrom](#cronJobs_pattern1_envFrom )                                     | No      | array of object  | No         | -                       | Environment variables from configmaps or secrets                                                                                                                                                                                                                                 |
| - [fullnameOverride](#cronJobs_pattern1_fullnameOverride )                   | No      | string           | No         | -                       | Name to prefix the K8s resources with, replaces the stack name prefix                                                                                                                                                                                                            |
| - [gateway](#cronJobs_pattern1_gateway )                                     | No      | object           | No         | -                       | Gateway API HTTPRoute configuration                                                                                                                                                                                                                                              |
| - [grafanaDashboard](#cronJobs_pattern1_grafanaDashboard )                   | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [image](#cronJobs_pattern1_image )                                         | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [imagePullSecrets](#cronJobs_pattern1_imagePullSecrets )                   | No      | array of string  | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [ingress](#cronJobs_pattern1_ingress )                                     | No      | object           | No         | -                       | Ingress configuration                                                                                                                                                                                                                                                            |
| - [initContainers](#cronJobs_pattern1_initContainers )                       | No      | array            | No         | -                       | List of init containers                                                                                                                                                                                                                                                          |
| - [kedaAutoscaling](#cronJobs_pattern1_kedaAutoscaling )                     | No      | object           | No         | -                       | KEDA autoscaling configuration (creates a ScaledObject instead of HPA)                                                                                                                                                                                                           |
| - [livenessProbe](#cronJobs_pattern1_livenessProbe )                         | No      | object           | No         | -                       | Liveness probe configuration                                                                                                                                                                                                                                                     |
| - [nameOverride](#cronJobs_pattern1_nameOverride )                           | No      | string           | No         | -                       | Name to prefix the K8s resources with, combined with the stack name prefix                                                                                                                                                                                                       |
| - [nodeSelector](#cronJobs_pattern1_nodeSelector )                           | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [oidcProxy](#cronJobs_pattern1_oidcProxy )                                 | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [oidcProxyGateway](#cronJobs_pattern1_oidcProxyGateway )                   | No      | object           | No         | -                       | Native Envoy Gateway OIDC authentication configuration (used when gateway.oidcProtected is true). Requires explicit clientID and issuer configuration. clientSecret is auto-referenced from appSecrets. redirectURL is auto-generated as https://<gateway.host>/oauth2/callback. |
| - [persistence](#cronJobs_pattern1_persistence )                             | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [podAnnotations](#cronJobs_pattern1_podAnnotations )                       | No      | object           | No         | -                       | Annotations to add to pods                                                                                                                                                                                                                                                       |
| - [podLabels](#cronJobs_pattern1_podLabels )                                 | No      | object           | No         | -                       | Global labels to add to all pods                                                                                                                                                                                                                                                 |
| - [podSecurityContext](#cronJobs_pattern1_podSecurityContext )               | No      | object           | No         | -                       | Pod security context                                                                                                                                                                                                                                                             |
| - [progressDeadlineSeconds](#cronJobs_pattern1_progressDeadlineSeconds )     | No      | integer          | No         | -                       | the number of seconds the Deployment controller waits before indicating (in the Deployment status) that the Deployment progress has stalled                                                                                                                                      |
| - [readinessProbe](#cronJobs_pattern1_readinessProbe )                       | No      | object           | No         | -                       | Readiness probe configuration                                                                                                                                                                                                                                                    |
| - [replicaCount](#cronJobs_pattern1_replicaCount )                           | No      | integer          | No         | -                       | Number of replicas                                                                                                                                                                                                                                                               |
| - [resources](#cronJobs_pattern1_resources )                                 | No      | object           | No         | -                       | Resource requests and limits for the primary container                                                                                                                                                                                                                           |
| - [restartPolicy](#cronJobs_pattern1_restartPolicy )                         | No      | enum (of string) | No         | -                       | Restart policy for the pod                                                                                                                                                                                                                                                       |
| - [rollout](#cronJobs_pattern1_rollout )                                     | No      | object           | No         | In #/properties/rollout | -                                                                                                                                                                                                                                                                                |
| - [s3Storage](#cronJobs_pattern1_s3Storage )                                 | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [securityContext](#cronJobs_pattern1_securityContext )                     | No      | object           | No         | -                       | Security context                                                                                                                                                                                                                                                                 |
| - [service](#cronJobs_pattern1_service )                                     | No      | object           | No         | -                       | Service configuration                                                                                                                                                                                                                                                            |
| - [serviceAccount](#cronJobs_pattern1_serviceAccount )                       | No      | object           | No         | -                       | Service account configuration                                                                                                                                                                                                                                                    |
| - [shareProcessNamespace](#cronJobs_pattern1_shareProcessNamespace )         | No      | boolean          | No         | -                       | Share process namespace                                                                                                                                                                                                                                                          |
| - [sidecars](#cronJobs_pattern1_sidecars )                                   | No      | array            | No         | -                       | List of sidecars                                                                                                                                                                                                                                                                 |
| - [startupProbe](#cronJobs_pattern1_startupProbe )                           | No      | object           | No         | -                       | Startup probe configuration                                                                                                                                                                                                                                                      |
| - [tolerations](#cronJobs_pattern1_tolerations )                             | No      | array            | No         | -                       | Tolerations for the pod                                                                                                                                                                                                                                                          |
| - [topologySpreadConstraints](#cronJobs_pattern1_topologySpreadConstraints ) | No      | array            | No         | -                       | Topology spread constraints for the pod                                                                                                                                                                                                                                          |
| - [volumeMounts](#cronJobs_pattern1_volumeMounts )                           | No      | array            | No         | -                       | Additional volume mounts on the output Deployment definition                                                                                                                                                                                                                     |
| - [volumes](#cronJobs_pattern1_volumes )                                     | No      | array            | No         | -                       | Additional volumes on the output Deployment definition                                                                                                                                                                                                                           |

#### <a name="cronJobs_pattern1_affinity"></a>2.1.1. Property `stack > cronJobs > ^.*$ > affinity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Affinity for the pod

#### <a name="cronJobs_pattern1_annotations"></a>2.1.2. Property `stack > cronJobs > ^.*$ > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global annotations to add to all resources

#### <a name="cronJobs_pattern1_appContext"></a>2.1.3. Property `stack > cronJobs > ^.*$ > appContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [envContextConfigMapName](#cronJobs_pattern1_appContext_envContextConfigMapName )     | No      | string | No         | -          | -                 |
| - [stackContextConfigMapName](#cronJobs_pattern1_appContext_stackContextConfigMapName ) | No      | string | No         | -          | -                 |

##### <a name="cronJobs_pattern1_appContext_envContextConfigMapName"></a>2.1.3.1. Property `stack > cronJobs > ^.*$ > appContext > envContextConfigMapName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appContext_stackContextConfigMapName"></a>2.1.3.2. Property `stack > cronJobs > ^.*$ > appContext > stackContextConfigMapName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_appSecrets"></a>2.1.4. Property `stack > cronJobs > ^.*$ > appSecrets`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [clusterSecret](#cronJobs_pattern1_appSecrets_clusterSecret ) | No      | object | No         | -          | -                 |
| - [envSecret](#cronJobs_pattern1_appSecrets_envSecret )         | No      | object | No         | -          | -                 |
| - [stackSecret](#cronJobs_pattern1_appSecrets_stackSecret )     | No      | object | No         | -          | -                 |

##### <a name="cronJobs_pattern1_appSecrets_clusterSecret"></a>2.1.4.1. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_clusterSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_clusterSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_clusterSecret_secretKey"></a>2.1.4.1.1. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_clusterSecret_secretName"></a>2.1.4.1.2. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appSecrets_envSecret"></a>2.1.4.2. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_envSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_envSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_envSecret_secretKey"></a>2.1.4.2.1. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_envSecret_secretName"></a>2.1.4.2.2. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appSecrets_stackSecret"></a>2.1.4.3. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                              | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_stackSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_stackSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_stackSecret_secretKey"></a>2.1.4.3.1. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_stackSecret_secretName"></a>2.1.4.3.2. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_argoBuildEnv"></a>2.1.5. Property `stack > cronJobs > ^.*$ > argoBuildEnv`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Argo built-in environment parameters (provided by Argus API)

| Property                                                                              | Pattern | Type   | Deprecated | Definition | Title/Description                                                                         |
| ------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------------------------------------------------------------- |
| - [appName](#cronJobs_pattern1_argoBuildEnv_appName )                                 | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_NAME (this is the ArgoCD app name, not the Argus app name) |
| - [appNamespace](#cronJobs_pattern1_argoBuildEnv_appNamespace )                       | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_NAMESPACE                                                  |
| - [appRevision](#cronJobs_pattern1_argoBuildEnv_appRevision )                         | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION                                                   |
| - [appRevisionShort](#cronJobs_pattern1_argoBuildEnv_appRevisionShort )               | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION_SHORT                                             |
| - [appRevisionShort8](#cronJobs_pattern1_argoBuildEnv_appRevisionShort8 )             | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION_SHORT_8                                           |
| - [appSourcePath](#cronJobs_pattern1_argoBuildEnv_appSourcePath )                     | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_PATH                                                |
| - [appSourceRepoUrl](#cronJobs_pattern1_argoBuildEnv_appSourceRepoUrl )               | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL                                            |
| - [appSourceTargetRevision](#cronJobs_pattern1_argoBuildEnv_appSourceTargetRevision ) | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL                                            |

##### <a name="cronJobs_pattern1_argoBuildEnv_appName"></a>2.1.5.1. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_NAME (this is the ArgoCD app name, not the Argus app name)

##### <a name="cronJobs_pattern1_argoBuildEnv_appNamespace"></a>2.1.5.2. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appNamespace`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_NAMESPACE

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevision"></a>2.1.5.3. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevision`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevisionShort"></a>2.1.5.4. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevisionShort`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION_SHORT

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevisionShort8"></a>2.1.5.5. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevisionShort8`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION_SHORT_8

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourcePath"></a>2.1.5.6. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourcePath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_PATH

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourceRepoUrl"></a>2.1.5.7. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourceRepoUrl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourceTargetRevision"></a>2.1.5.8. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourceTargetRevision`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL

#### <a name="cronJobs_pattern1_args"></a>2.1.6. Property `stack > cronJobs > ^.*$ > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Arguments to pass to the command in the primary container

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be             | Description |
| ------------------------------------------- | ----------- |
| [args items](#cronJobs_pattern1_args_items) | -           |

##### <a name="cronJobs_pattern1_args_items"></a>2.1.6.1. stack > cronJobs > ^.*$ > args > args items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_argusMetadata"></a>2.1.7. Property `stack > cronJobs > ^.*$ > argusMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Argus metadata (provided by Argus API)

| Property                                                   | Pattern | Type   | Deprecated | Definition | Title/Description                          |
| ---------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------ |
| - [appName](#cronJobs_pattern1_argusMetadata_appName )     | No      | string | No         | -          | Set by Argus API to Argus app name         |
| - [envName](#cronJobs_pattern1_argusMetadata_envName )     | No      | string | No         | -          | Set by Argus API to Argus environment name |
| - [repoName](#cronJobs_pattern1_argusMetadata_repoName )   | No      | string | No         | -          | Set by Argus API to Argus repository name  |
| - [repoOwner](#cronJobs_pattern1_argusMetadata_repoOwner ) | No      | string | No         | -          | Set by Argus API to Argus repository owner |
| - [stackName](#cronJobs_pattern1_argusMetadata_stackName ) | No      | string | No         | -          | Set by Argus API to Argus stack name       |

##### <a name="cronJobs_pattern1_argusMetadata_appName"></a>2.1.7.1. Property `stack > cronJobs > ^.*$ > argusMetadata > appName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus app name

##### <a name="cronJobs_pattern1_argusMetadata_envName"></a>2.1.7.2. Property `stack > cronJobs > ^.*$ > argusMetadata > envName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus environment name

##### <a name="cronJobs_pattern1_argusMetadata_repoName"></a>2.1.7.3. Property `stack > cronJobs > ^.*$ > argusMetadata > repoName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus repository name

##### <a name="cronJobs_pattern1_argusMetadata_repoOwner"></a>2.1.7.4. Property `stack > cronJobs > ^.*$ > argusMetadata > repoOwner`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus repository owner

##### <a name="cronJobs_pattern1_argusMetadata_stackName"></a>2.1.7.5. Property `stack > cronJobs > ^.*$ > argusMetadata > stackName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus stack name

#### <a name="cronJobs_pattern1_autoscaling"></a>2.1.8. Property `stack > cronJobs > ^.*$ > autoscaling`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Autoscaling configuration

| Property                                                                                                 | Pattern | Type    | Deprecated | Definition | Title/Description                    |
| -------------------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------ |
| - [enabled](#cronJobs_pattern1_autoscaling_enabled )                                                     | No      | boolean | No         | -          | Enable autoscaling                   |
| - [maxReplicas](#cronJobs_pattern1_autoscaling_maxReplicas )                                             | No      | integer | No         | -          | Maximum number of replicas           |
| - [minReplicas](#cronJobs_pattern1_autoscaling_minReplicas )                                             | No      | integer | No         | -          | Minimum number of replicas           |
| - [targetCPUUtilizationPercentage](#cronJobs_pattern1_autoscaling_targetCPUUtilizationPercentage )       | No      | integer | No         | -          | Target CPU utilization percentage    |
| - [targetMemoryUtilizationPercentage](#cronJobs_pattern1_autoscaling_targetMemoryUtilizationPercentage ) | No      | integer | No         | -          | Target memory utilization percentage |

##### <a name="cronJobs_pattern1_autoscaling_enabled"></a>2.1.8.1. Property `stack > cronJobs > ^.*$ > autoscaling > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable autoscaling

##### <a name="cronJobs_pattern1_autoscaling_maxReplicas"></a>2.1.8.2. Property `stack > cronJobs > ^.*$ > autoscaling > maxReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Maximum number of replicas

##### <a name="cronJobs_pattern1_autoscaling_minReplicas"></a>2.1.8.3. Property `stack > cronJobs > ^.*$ > autoscaling > minReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Minimum number of replicas

##### <a name="cronJobs_pattern1_autoscaling_targetCPUUtilizationPercentage"></a>2.1.8.4. Property `stack > cronJobs > ^.*$ > autoscaling > targetCPUUtilizationPercentage`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Target CPU utilization percentage

##### <a name="cronJobs_pattern1_autoscaling_targetMemoryUtilizationPercentage"></a>2.1.8.5. Property `stack > cronJobs > ^.*$ > autoscaling > targetMemoryUtilizationPercentage`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Target memory utilization percentage

#### <a name="cronJobs_pattern1_command"></a>2.1.9. Property `stack > cronJobs > ^.*$ > command`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Command to run in the primary container

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                   | Description |
| ------------------------------------------------- | ----------- |
| [command items](#cronJobs_pattern1_command_items) | -           |

##### <a name="cronJobs_pattern1_command_items"></a>2.1.9.1. stack > cronJobs > ^.*$ > command > command items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_deploymentKind"></a>2.1.10. Property `stack > cronJobs > ^.*$ > deploymentKind`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |
| **Default**  | `"Deployment"`     |

**Description:** Specifies the Kubernetes Kind for the main application workload controller (Deployment or Rollout).

Must be one of:
* "Deployment"
* "Rollout"

#### <a name="cronJobs_pattern1_deploymentStage"></a>2.1.11. Property `stack > cronJobs > ^.*$ > deploymentStage`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Deployment stage

#### <a name="cronJobs_pattern1_dnsPolicy"></a>2.1.12. Property `stack > cronJobs > ^.*$ > dnsPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** DNS policy for the pod

Must be one of:
* "ClusterFirst"
* "Default"
* "None"

#### <a name="cronJobs_pattern1_env"></a>2.1.13. Property `stack > cronJobs > ^.*$ > env`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be           | Description |
| ----------------------------------------- | ----------- |
| [env items](#cronJobs_pattern1_env_items) | -           |

##### <a name="cronJobs_pattern1_env_items"></a>2.1.13.1. stack > cronJobs > ^.*$ > env > env items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_env_items_name )   | No      | string | No         | -          | -                 |
| - [value](#cronJobs_pattern1_env_items_value ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_env_items_name"></a>2.1.13.1.1. Property `stack > cronJobs > ^.*$ > env > env items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_env_items_value"></a>2.1.13.1.2. Property `stack > cronJobs > ^.*$ > env > env items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_envFrom"></a>2.1.14. Property `stack > cronJobs > ^.*$ > envFrom`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Environment variables from configmaps or secrets

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                   | Description |
| ------------------------------------------------- | ----------- |
| [envFrom items](#cronJobs_pattern1_envFrom_items) | -           |

##### <a name="cronJobs_pattern1_envFrom_items"></a>2.1.14.1. stack > cronJobs > ^.*$ > envFrom > envFrom items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [configMapRef](#cronJobs_pattern1_envFrom_items_configMapRef ) | No      | object | No         | -          | -                 |
| - [prefix](#cronJobs_pattern1_envFrom_items_prefix )             | No      | string | No         | -          | -                 |
| - [secretRef](#cronJobs_pattern1_envFrom_items_secretRef )       | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_envFrom_items_configMapRef"></a>2.1.14.1.1. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > configMapRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_envFrom_items_prefix"></a>2.1.14.1.2. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > prefix`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_envFrom_items_secretRef"></a>2.1.14.1.3. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > secretRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

#### <a name="cronJobs_pattern1_fullnameOverride"></a>2.1.15. Property `stack > cronJobs > ^.*$ > fullnameOverride`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name to prefix the K8s resources with, replaces the stack name prefix

#### <a name="cronJobs_pattern1_gateway"></a>2.1.16. Property `stack > cronJobs > ^.*$ > gateway`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Gateway API HTTPRoute configuration

| Property                                                           | Pattern | Type            | Deprecated | Definition | Title/Description                                                                                                                                                                                                                                                   |
| ------------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_gateway_annotations )           | No      | object          | No         | -          | Annotations to add to HTTPRoute resources                                                                                                                                                                                                                           |
| - [backendTLS](#cronJobs_pattern1_gateway_backendTLS )             | No      | object          | No         | -          | TLS to the upstream Service via a BackendTLSPolicy (gateway.networking.k8s.io/v1)                                                                                                                                                                                   |
| - [basicAuth](#cronJobs_pattern1_gateway_basicAuth )               | No      | object          | No         | -          | HTTP basic auth via a SecurityPolicy. Mutually exclusive with gateway.oidcProtected                                                                                                                                                                                 |
| - [cors](#cronJobs_pattern1_gateway_cors )                         | No      | object          | No         | -          | CORS via a SecurityPolicy                                                                                                                                                                                                                                           |
| - [enabled](#cronJobs_pattern1_gateway_enabled )                   | No      | boolean         | No         | -          | Enable Gateway API HTTPRoute (alternative to Ingress)                                                                                                                                                                                                               |
| - [gatewayName](#cronJobs_pattern1_gateway_gatewayName )           | No      | string          | No         | -          | Name of the Gateway resource to attach to                                                                                                                                                                                                                           |
| - [gatewayNamespace](#cronJobs_pattern1_gateway_gatewayNamespace ) | No      | string          | No         | -          | Namespace of the Gateway resource                                                                                                                                                                                                                                   |
| - [host](#cronJobs_pattern1_gateway_host )                         | No      | string          | No         | -          | Hostname for HTTPRoute                                                                                                                                                                                                                                              |
| - [hostRewrite](#cronJobs_pattern1_gateway_hostRewrite )           | No      | string          | No         | -          | Rewrite the Host header sent upstream via an HTTPRoute URLRewrite filter, empty disables it                                                                                                                                                                         |
| - [ipAllowList](#cronJobs_pattern1_gateway_ipAllowList )           | No      | array           | No         | -          | Client IP allowlist of CIDRs that renders a SecurityPolicy authorization rule (defaultAction Deny). Empty disables it                                                                                                                                               |
| - [oidcProtected](#cronJobs_pattern1_gateway_oidcProtected )       | No      | boolean         | No         | -          | Enable OIDC protection via Envoy Gateway SecurityPolicy (requires oidcProxyGateway configuration)                                                                                                                                                                   |
| - [paths](#cronJobs_pattern1_gateway_paths )                       | No      | array of object | No         | -          | List of HTTPRoute paths                                                                                                                                                                                                                                             |
| - [rateLimit](#cronJobs_pattern1_gateway_rateLimit )               | No      | object          | No         | -          | Local rate limit via a BackendTrafficPolicy (Envoy local token bucket, no burst concept)                                                                                                                                                                            |
| - [redirect](#cronJobs_pattern1_gateway_redirect )                 | No      | object          | No         | -          | Whole-route redirect via an HTTPRoute RequestRedirect filter, replaces backend routing for the host                                                                                                                                                                 |
| - [requestHeaders](#cronJobs_pattern1_gateway_requestHeaders )     | No      | object          | No         | -          | Request header modifications (HTTPRoute RequestHeaderModifier filter)                                                                                                                                                                                               |
| - [responseHeaders](#cronJobs_pattern1_gateway_responseHeaders )   | No      | object          | No         | -          | Response header modifications (HTTPRoute ResponseHeaderModifier filter)                                                                                                                                                                                             |
| - [rules](#cronJobs_pattern1_gateway_rules )                       | No      | array           | No         | -          | List of additional HTTPRoute rules with custom hosts. Each entry takes host, optional paths, and an optional vanity block (enabled, hostname, clusterIssuer) that renders a per-host ListenerSet so the extra host can be a vanity domain, mirroring gateway.vanity |
| - [sectionName](#cronJobs_pattern1_gateway_sectionName )           | No      | string          | No         | -          | Optional section name (listener name) on the Gateway                                                                                                                                                                                                                |
| - [sessionAffinity](#cronJobs_pattern1_gateway_sessionAffinity )   | No      | object          | No         | -          | Cookie-based sticky sessions via a BackendTrafficPolicy. Off by default (the ingress cookie-affinity default is not carried to the gateway)                                                                                                                         |
| - [timeouts](#cronJobs_pattern1_gateway_timeouts )                 | No      | object          | No         | -          | HTTPRoute timeouts. request maps to nginx proxy-read and send-timeout. connect (optional) renders a BackendTrafficPolicy                                                                                                                                            |
| - [tlsPassthrough](#cronJobs_pattern1_gateway_tlsPassthrough )     | No      | object          | No         | -          | TLS passthrough via a TLSRoute (the Gateway does not terminate TLS). Mutually exclusive with the L7 gateway features, and requires a Passthrough listener on the shared Gateway                                                                                     |
| - [vanity](#cronJobs_pattern1_gateway_vanity )                     | No      | object          | No         | -          | Self-serve public/vanity-domain TLS via a tenant-owned Gateway API ListenerSet (requires Envoy Gateway >= v1.8 and cert-manager >= v1.20)                                                                                                                           |

##### <a name="cronJobs_pattern1_gateway_annotations"></a>2.1.16.1. Property `stack > cronJobs > ^.*$ > gateway > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to HTTPRoute resources

| Property                                                                                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [external-dns.alpha.kubernetes.io/ttl](#cronJobs_pattern1_gateway_annotations_external-dnsalphakubernetesio/ttl ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_gateway_annotations_external-dnsalphakubernetesio/ttl"></a>2.1.16.1.1. Property `stack > cronJobs > ^.*$ > gateway > annotations > external-dns.alpha.kubernetes.io/ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_gateway_backendTLS"></a>2.1.16.2. Property `stack > cronJobs > ^.*$ > gateway > backendTLS`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** TLS to the upstream Service via a BackendTLSPolicy (gateway.networking.k8s.io/v1)

| Property                                                                                    | Pattern | Type    | Deprecated | Definition | Title/Description                                                                |
| ------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | -------------------------------------------------------------------------------- |
| - [caCertificateRefs](#cronJobs_pattern1_gateway_backendTLS_caCertificateRefs )             | No      | array   | No         | -          | ConfigMap refs holding the CA bundle for self-signed/internal upstreams          |
| - [enabled](#cronJobs_pattern1_gateway_backendTLS_enabled )                                 | No      | boolean | No         | -          | Enable upstream TLS                                                              |
| - [hostname](#cronJobs_pattern1_gateway_backendTLS_hostname )                               | No      | string  | No         | -          | SNI/validation hostname presented by the upstream (required when enabled)        |
| - [wellKnownCACertificates](#cronJobs_pattern1_gateway_backendTLS_wellKnownCACertificates ) | No      | string  | No         | -          | Use the System trust store, or set "" and use caCertificateRefs for a private CA |

###### <a name="cronJobs_pattern1_gateway_backendTLS_caCertificateRefs"></a>2.1.16.2.1. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > caCertificateRefs`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** ConfigMap refs holding the CA bundle for self-signed/internal upstreams

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_backendTLS_enabled"></a>2.1.16.2.2. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable upstream TLS

###### <a name="cronJobs_pattern1_gateway_backendTLS_hostname"></a>2.1.16.2.3. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** SNI/validation hostname presented by the upstream (required when enabled)

###### <a name="cronJobs_pattern1_gateway_backendTLS_wellKnownCACertificates"></a>2.1.16.2.4. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > wellKnownCACertificates`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Use the System trust store, or set "" and use caCertificateRefs for a private CA

##### <a name="cronJobs_pattern1_gateway_basicAuth"></a>2.1.16.3. Property `stack > cronJobs > ^.*$ > gateway > basicAuth`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP basic auth via a SecurityPolicy. Mutually exclusive with gateway.oidcProtected

| Property                                                         | Pattern | Type    | Deprecated | Definition | Title/Description                             |
| ---------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | --------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_basicAuth_enabled )       | No      | boolean | No         | -          | Enable basic auth                             |
| - [secretName](#cronJobs_pattern1_gateway_basicAuth_secretName ) | No      | string  | No         | -          | Name of an Opaque Secret with a .htpasswd key |

###### <a name="cronJobs_pattern1_gateway_basicAuth_enabled"></a>2.1.16.3.1. Property `stack > cronJobs > ^.*$ > gateway > basicAuth > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable basic auth

###### <a name="cronJobs_pattern1_gateway_basicAuth_secretName"></a>2.1.16.3.2. Property `stack > cronJobs > ^.*$ > gateway > basicAuth > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of an Opaque Secret with a .htpasswd key

##### <a name="cronJobs_pattern1_gateway_cors"></a>2.1.16.4. Property `stack > cronJobs > ^.*$ > gateway > cors`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CORS via a SecurityPolicy

| Property                                                                | Pattern | Type    | Deprecated | Definition | Title/Description                                    |
| ----------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------------------------------------- |
| - [allowCredentials](#cronJobs_pattern1_gateway_cors_allowCredentials ) | No      | boolean | No         | -          | Allow credentials                                    |
| - [allowHeaders](#cronJobs_pattern1_gateway_cors_allowHeaders )         | No      | array   | No         | -          | Allowed request headers                              |
| - [allowMethods](#cronJobs_pattern1_gateway_cors_allowMethods )         | No      | array   | No         | -          | Allowed methods                                      |
| - [allowOrigins](#cronJobs_pattern1_gateway_cors_allowOrigins )         | No      | array   | No         | -          | Allowed origins (string patterns)                    |
| - [enabled](#cronJobs_pattern1_gateway_cors_enabled )                   | No      | boolean | No         | -          | Enable CORS                                          |
| - [exposeHeaders](#cronJobs_pattern1_gateway_cors_exposeHeaders )       | No      | array   | No         | -          | Response headers exposed to the browser              |
| - [maxAge](#cronJobs_pattern1_gateway_cors_maxAge )                     | No      | string  | No         | -          | Preflight cache duration (e.g. "1h"), empty omits it |

###### <a name="cronJobs_pattern1_gateway_cors_allowCredentials"></a>2.1.16.4.1. Property `stack > cronJobs > ^.*$ > gateway > cors > allowCredentials`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Allow credentials

###### <a name="cronJobs_pattern1_gateway_cors_allowHeaders"></a>2.1.16.4.2. Property `stack > cronJobs > ^.*$ > gateway > cors > allowHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed request headers

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_allowMethods"></a>2.1.16.4.3. Property `stack > cronJobs > ^.*$ > gateway > cors > allowMethods`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed methods

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_allowOrigins"></a>2.1.16.4.4. Property `stack > cronJobs > ^.*$ > gateway > cors > allowOrigins`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed origins (string patterns)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_enabled"></a>2.1.16.4.5. Property `stack > cronJobs > ^.*$ > gateway > cors > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable CORS

###### <a name="cronJobs_pattern1_gateway_cors_exposeHeaders"></a>2.1.16.4.6. Property `stack > cronJobs > ^.*$ > gateway > cors > exposeHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Response headers exposed to the browser

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_maxAge"></a>2.1.16.4.7. Property `stack > cronJobs > ^.*$ > gateway > cors > maxAge`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Preflight cache duration (e.g. "1h"), empty omits it

##### <a name="cronJobs_pattern1_gateway_enabled"></a>2.1.16.5. Property `stack > cronJobs > ^.*$ > gateway > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable Gateway API HTTPRoute (alternative to Ingress)

##### <a name="cronJobs_pattern1_gateway_gatewayName"></a>2.1.16.6. Property `stack > cronJobs > ^.*$ > gateway > gatewayName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the Gateway resource to attach to

##### <a name="cronJobs_pattern1_gateway_gatewayNamespace"></a>2.1.16.7. Property `stack > cronJobs > ^.*$ > gateway > gatewayNamespace`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Namespace of the Gateway resource

##### <a name="cronJobs_pattern1_gateway_host"></a>2.1.16.8. Property `stack > cronJobs > ^.*$ > gateway > host`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Hostname for HTTPRoute

##### <a name="cronJobs_pattern1_gateway_hostRewrite"></a>2.1.16.9. Property `stack > cronJobs > ^.*$ > gateway > hostRewrite`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Rewrite the Host header sent upstream via an HTTPRoute URLRewrite filter, empty disables it

##### <a name="cronJobs_pattern1_gateway_ipAllowList"></a>2.1.16.10. Property `stack > cronJobs > ^.*$ > gateway > ipAllowList`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Client IP allowlist of CIDRs that renders a SecurityPolicy authorization rule (defaultAction Deny). Empty disables it

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_oidcProtected"></a>2.1.16.11. Property `stack > cronJobs > ^.*$ > gateway > oidcProtected`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC protection via Envoy Gateway SecurityPolicy (requires oidcProxyGateway configuration)

##### <a name="cronJobs_pattern1_gateway_paths"></a>2.1.16.12. Property `stack > cronJobs > ^.*$ > gateway > paths`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of HTTPRoute paths

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                       | Description |
| ----------------------------------------------------- | ----------- |
| [paths items](#cronJobs_pattern1_gateway_paths_items) | -           |

###### <a name="cronJobs_pattern1_gateway_paths_items"></a>2.1.16.12.1. stack > cronJobs > ^.*$ > gateway > paths > paths items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                     |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------- |
| - [path](#cronJobs_pattern1_gateway_paths_items_path )         | No      | string | No         | -          | HTTPRoute path                        |
| - [pathType](#cronJobs_pattern1_gateway_paths_items_pathType ) | No      | string | No         | -          | HTTPRoute path type (Exact or Prefix) |

###### <a name="cronJobs_pattern1_gateway_paths_items_path"></a>2.1.16.12.1.1. Property `stack > cronJobs > ^.*$ > gateway > paths > paths items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** HTTPRoute path

###### <a name="cronJobs_pattern1_gateway_paths_items_pathType"></a>2.1.16.12.1.2. Property `stack > cronJobs > ^.*$ > gateway > paths > paths items > pathType`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** HTTPRoute path type (Exact or Prefix)

##### <a name="cronJobs_pattern1_gateway_rateLimit"></a>2.1.16.13. Property `stack > cronJobs > ^.*$ > gateway > rateLimit`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Local rate limit via a BackendTrafficPolicy (Envoy local token bucket, no burst concept)

| Property                                                     | Pattern | Type    | Deprecated | Definition | Title/Description                           |
| ------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_rateLimit_enabled )   | No      | boolean | No         | -          | Enable local rate limiting                  |
| - [requests](#cronJobs_pattern1_gateway_rateLimit_requests ) | No      | integer | No         | -          | Allowed requests per unit                   |
| - [unit](#cronJobs_pattern1_gateway_rateLimit_unit )         | No      | string  | No         | -          | Rate limit unit (Second, Minute, Hour, Day) |

###### <a name="cronJobs_pattern1_gateway_rateLimit_enabled"></a>2.1.16.13.1. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable local rate limiting

###### <a name="cronJobs_pattern1_gateway_rateLimit_requests"></a>2.1.16.13.2. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > requests`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Allowed requests per unit

###### <a name="cronJobs_pattern1_gateway_rateLimit_unit"></a>2.1.16.13.3. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > unit`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Rate limit unit (Second, Minute, Hour, Day)

##### <a name="cronJobs_pattern1_gateway_redirect"></a>2.1.16.14. Property `stack > cronJobs > ^.*$ > gateway > redirect`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Whole-route redirect via an HTTPRoute RequestRedirect filter, replaces backend routing for the host

| Property                                                        | Pattern | Type    | Deprecated | Definition | Title/Description                                               |
| --------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | --------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_redirect_enabled )       | No      | boolean | No         | -          | Enable a redirect-only route                                    |
| - [hostname](#cronJobs_pattern1_gateway_redirect_hostname )     | No      | string  | No         | -          | Target hostname, empty keeps the request host                   |
| - [path](#cronJobs_pattern1_gateway_redirect_path )             | No      | string  | No         | -          | Replacement full path via ReplaceFullPath, empty keeps the path |
| - [scheme](#cronJobs_pattern1_gateway_redirect_scheme )         | No      | string  | No         | -          | Target scheme, e.g. https                                       |
| - [statusCode](#cronJobs_pattern1_gateway_redirect_statusCode ) | No      | integer | No         | -          | Redirect status code (301 or 302)                               |

###### <a name="cronJobs_pattern1_gateway_redirect_enabled"></a>2.1.16.14.1. Property `stack > cronJobs > ^.*$ > gateway > redirect > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable a redirect-only route

###### <a name="cronJobs_pattern1_gateway_redirect_hostname"></a>2.1.16.14.2. Property `stack > cronJobs > ^.*$ > gateway > redirect > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Target hostname, empty keeps the request host

###### <a name="cronJobs_pattern1_gateway_redirect_path"></a>2.1.16.14.3. Property `stack > cronJobs > ^.*$ > gateway > redirect > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Replacement full path via ReplaceFullPath, empty keeps the path

###### <a name="cronJobs_pattern1_gateway_redirect_scheme"></a>2.1.16.14.4. Property `stack > cronJobs > ^.*$ > gateway > redirect > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Target scheme, e.g. https

###### <a name="cronJobs_pattern1_gateway_redirect_statusCode"></a>2.1.16.14.5. Property `stack > cronJobs > ^.*$ > gateway > redirect > statusCode`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Redirect status code (301 or 302)

##### <a name="cronJobs_pattern1_gateway_requestHeaders"></a>2.1.16.15. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Request header modifications (HTTPRoute RequestHeaderModifier filter)

| Property                                                      | Pattern | Type  | Deprecated | Definition | Title/Description                    |
| ------------------------------------------------------------- | ------- | ----- | ---------- | ---------- | ------------------------------------ |
| - [add](#cronJobs_pattern1_gateway_requestHeaders_add )       | No      | array | No         | -          | Headers to add, list of {name,value} |
| - [remove](#cronJobs_pattern1_gateway_requestHeaders_remove ) | No      | array | No         | -          | Header names to remove               |
| - [set](#cronJobs_pattern1_gateway_requestHeaders_set )       | No      | array | No         | -          | Headers to set, list of {name,value} |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_add"></a>2.1.16.15.1. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > add`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to add, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_remove"></a>2.1.16.15.2. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > remove`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Header names to remove

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_set"></a>2.1.16.15.3. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > set`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to set, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_responseHeaders"></a>2.1.16.16. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Response header modifications (HTTPRoute ResponseHeaderModifier filter)

| Property                                                       | Pattern | Type  | Deprecated | Definition | Title/Description                    |
| -------------------------------------------------------------- | ------- | ----- | ---------- | ---------- | ------------------------------------ |
| - [add](#cronJobs_pattern1_gateway_responseHeaders_add )       | No      | array | No         | -          | Headers to add, list of {name,value} |
| - [remove](#cronJobs_pattern1_gateway_responseHeaders_remove ) | No      | array | No         | -          | Header names to remove               |
| - [set](#cronJobs_pattern1_gateway_responseHeaders_set )       | No      | array | No         | -          | Headers to set, list of {name,value} |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_add"></a>2.1.16.16.1. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > add`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to add, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_remove"></a>2.1.16.16.2. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > remove`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Header names to remove

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_set"></a>2.1.16.16.3. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > set`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to set, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_rules"></a>2.1.16.17. Property `stack > cronJobs > ^.*$ > gateway > rules`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of additional HTTPRoute rules with custom hosts. Each entry takes host, optional paths, and an optional vanity block (enabled, hostname, clusterIssuer) that renders a per-host ListenerSet so the extra host can be a vanity domain, mirroring gateway.vanity

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_sectionName"></a>2.1.16.18. Property `stack > cronJobs > ^.*$ > gateway > sectionName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional section name (listener name) on the Gateway

##### <a name="cronJobs_pattern1_gateway_sessionAffinity"></a>2.1.16.19. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Cookie-based sticky sessions via a BackendTrafficPolicy. Off by default (the ingress cookie-affinity default is not carried to the gateway)

| Property                                                               | Pattern | Type    | Deprecated | Definition | Title/Description                              |
| ---------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------------------------------- |
| - [cookieName](#cronJobs_pattern1_gateway_sessionAffinity_cookieName ) | No      | string  | No         | -          | Affinity cookie name                           |
| - [enabled](#cronJobs_pattern1_gateway_sessionAffinity_enabled )       | No      | boolean | No         | -          | Enable consistent-hash cookie session affinity |
| - [ttl](#cronJobs_pattern1_gateway_sessionAffinity_ttl )               | No      | string  | No         | -          | Affinity cookie TTL                            |

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_cookieName"></a>2.1.16.19.1. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > cookieName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Affinity cookie name

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_enabled"></a>2.1.16.19.2. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable consistent-hash cookie session affinity

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_ttl"></a>2.1.16.19.3. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Affinity cookie TTL

##### <a name="cronJobs_pattern1_gateway_timeouts"></a>2.1.16.20. Property `stack > cronJobs > ^.*$ > gateway > timeouts`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTPRoute timeouts. request maps to nginx proxy-read and send-timeout. connect (optional) renders a BackendTrafficPolicy

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description                                                                                                             |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------------------------------------------------------------------------------------------------- |
| - [backendRequest](#cronJobs_pattern1_gateway_timeouts_backendRequest ) | No      | string | No         | -          | Per-try backend request timeout (HTTPRoute rules[].timeouts.backendRequest). Must be <= request                               |
| - [connect](#cronJobs_pattern1_gateway_timeouts_connect )               | No      | string | No         | -          | Optional upstream TCP connect timeout (renders BackendTrafficPolicy timeout.tcp.connectTimeout), empty uses the Envoy default |
| - [request](#cronJobs_pattern1_gateway_timeouts_request )               | No      | string | No         | -          | Overall request timeout (HTTPRoute rules[].timeouts.request). Set "0s" to disable, e.g. for streaming or websockets           |

###### <a name="cronJobs_pattern1_gateway_timeouts_backendRequest"></a>2.1.16.20.1. Property `stack > cronJobs > ^.*$ > gateway > timeouts > backendRequest`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Per-try backend request timeout (HTTPRoute rules[].timeouts.backendRequest). Must be <= request

###### <a name="cronJobs_pattern1_gateway_timeouts_connect"></a>2.1.16.20.2. Property `stack > cronJobs > ^.*$ > gateway > timeouts > connect`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional upstream TCP connect timeout (renders BackendTrafficPolicy timeout.tcp.connectTimeout), empty uses the Envoy default

###### <a name="cronJobs_pattern1_gateway_timeouts_request"></a>2.1.16.20.3. Property `stack > cronJobs > ^.*$ > gateway > timeouts > request`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Overall request timeout (HTTPRoute rules[].timeouts.request). Set "0s" to disable, e.g. for streaming or websockets

##### <a name="cronJobs_pattern1_gateway_tlsPassthrough"></a>2.1.16.21. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** TLS passthrough via a TLSRoute (the Gateway does not terminate TLS). Mutually exclusive with the L7 gateway features, and requires a Passthrough listener on the shared Gateway

| Property                                                                | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                   |
| ----------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_tlsPassthrough_enabled )         | No      | boolean | No         | -          | Render a TLSRoute instead of an HTTPRoute and skip TLS termination for this service                                 |
| - [sectionName](#cronJobs_pattern1_gateway_tlsPassthrough_sectionName ) | No      | string  | No         | -          | Optional Passthrough listener name to pin to. Empty attaches by hostname plus TLS protocol, which is the usual case |

###### <a name="cronJobs_pattern1_gateway_tlsPassthrough_enabled"></a>2.1.16.21.1. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Render a TLSRoute instead of an HTTPRoute and skip TLS termination for this service

###### <a name="cronJobs_pattern1_gateway_tlsPassthrough_sectionName"></a>2.1.16.21.2. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough > sectionName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional Passthrough listener name to pin to. Empty attaches by hostname plus TLS protocol, which is the usual case

##### <a name="cronJobs_pattern1_gateway_vanity"></a>2.1.16.22. Property `stack > cronJobs > ^.*$ > gateway > vanity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Self-serve public/vanity-domain TLS via a tenant-owned Gateway API ListenerSet (requires Envoy Gateway >= v1.8 and cert-manager >= v1.20)

| Property                                                            | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                                                        |
| ------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [clusterIssuer](#cronJobs_pattern1_gateway_vanity_clusterIssuer ) | No      | string  | No         | -          | cert-manager ClusterIssuer used by the gateway-shim to issue the listener certificate                                                                    |
| - [enabled](#cronJobs_pattern1_gateway_vanity_enabled )             | No      | boolean | No         | -          | Render a ListenerSet attaching an HTTPS listener for this service's vanity domain to the shared Gateway                                                  |
| - [hostname](#cronJobs_pattern1_gateway_vanity_hostname )           | No      | string  | No         | -          | Listener SNI hostname (defaults to gateway.host). A wildcard such as *.parent requires a dns01-capable issuer because http01 cannot issue wildcard certs |

###### <a name="cronJobs_pattern1_gateway_vanity_clusterIssuer"></a>2.1.16.22.1. Property `stack > cronJobs > ^.*$ > gateway > vanity > clusterIssuer`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** cert-manager ClusterIssuer used by the gateway-shim to issue the listener certificate

###### <a name="cronJobs_pattern1_gateway_vanity_enabled"></a>2.1.16.22.2. Property `stack > cronJobs > ^.*$ > gateway > vanity > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Render a ListenerSet attaching an HTTPS listener for this service's vanity domain to the shared Gateway

###### <a name="cronJobs_pattern1_gateway_vanity_hostname"></a>2.1.16.22.3. Property `stack > cronJobs > ^.*$ > gateway > vanity > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Listener SNI hostname (defaults to gateway.host). A wildcard such as *.parent requires a dns01-capable issuer because http01 cannot issue wildcard certs

#### <a name="cronJobs_pattern1_grafanaDashboard"></a>2.1.17. Property `stack > cronJobs > ^.*$ > grafanaDashboard`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                    | Pattern | Type            | Deprecated | Definition | Title/Description                                                  |
| --------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ------------------------------------------------------------------ |
| - [datasources](#cronJobs_pattern1_grafanaDashboard_datasources )           | No      | object          | No         | -          | -                                                                  |
| - [enabled](#cronJobs_pattern1_grafanaDashboard_enabled )                   | No      | boolean         | No         | -          | Enable Grafana dashboard (globally, can be overridden per service) |
| - [extraPanels](#cronJobs_pattern1_grafanaDashboard_extraPanels )           | No      | array of object | No         | -          | Extra panels to add to the Grafana dashboard                       |
| - [instanceSelector](#cronJobs_pattern1_grafanaDashboard_instanceSelector ) | No      | object          | No         | -          | Instance selector for the Grafana dashboard                        |

##### <a name="cronJobs_pattern1_grafanaDashboard_datasources"></a>2.1.17.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                    | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [prometheus](#cronJobs_pattern1_grafanaDashboard_datasources_prometheus ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_datasources_prometheus"></a>2.1.17.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources > prometheus`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                 | Pattern | Type   | Deprecated | Definition | Title/Description         |
| ------------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ------------------------- |
| - [uid](#cronJobs_pattern1_grafanaDashboard_datasources_prometheus_uid ) | No      | string | No         | -          | Prometheus datasource UID |

###### <a name="cronJobs_pattern1_grafanaDashboard_datasources_prometheus_uid"></a>2.1.17.1.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources > prometheus > uid`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Prometheus datasource UID

##### <a name="cronJobs_pattern1_grafanaDashboard_enabled"></a>2.1.17.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable Grafana dashboard (globally, can be overridden per service)

##### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels"></a>2.1.17.3. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Extra panels to add to the Grafana dashboard

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                            | Description |
| -------------------------------------------------------------------------- | ----------- |
| [extraPanels items](#cronJobs_pattern1_grafanaDashboard_extraPanels_items) | -           |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items"></a>2.1.17.3.1. stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [datasource](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_datasource )       | No      | object | No         | -          | -                 |
| - [fieldConfig](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_fieldConfig )     | No      | object | No         | -          | -                 |
| - [gridPos](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos )             | No      | object | No         | -          | -                 |
| - [options](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_options )             | No      | object | No         | -          | -                 |
| - [pluginVersion](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_pluginVersion ) | No      | string | No         | -          | -                 |
| - [targets](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_targets )             | No      | array  | No         | -          | -                 |
| - [title](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_title )                 | No      | string | No         | -          | -                 |
| - [type](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_type )                   | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_datasource"></a>2.1.17.3.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > datasource`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_fieldConfig"></a>2.1.17.3.1.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > fieldConfig`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos"></a>2.1.17.3.1.3. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [h](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_h ) | No      | number | No         | -          | -                 |
| - [w](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_w ) | No      | number | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_h"></a>2.1.17.3.1.3.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos > h`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_w"></a>2.1.17.3.1.3.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos > w`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_options"></a>2.1.17.3.1.4. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > options`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_pluginVersion"></a>2.1.17.3.1.5. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > pluginVersion`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_targets"></a>2.1.17.3.1.6. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > targets`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_title"></a>2.1.17.3.1.7. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > title`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_type"></a>2.1.17.3.1.8. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > type`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector"></a>2.1.17.4. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Instance selector for the Grafana dashboard

| Property                                                                           | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [matchLabels](#cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels"></a>2.1.17.4.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector > matchLabels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                         | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels_name ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels_name"></a>2.1.17.4.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector > matchLabels > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_image"></a>2.1.18. Property `stack > cronJobs > ^.*$ > image`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                             | Pattern | Type             | Deprecated | Definition | Title/Description |
| ---------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [pullPolicy](#cronJobs_pattern1_image_pullPolicy ) | No      | enum (of string) | No         | -          | Image pull policy |
| - [repository](#cronJobs_pattern1_image_repository ) | No      | string           | No         | -          | Image repository  |
| - [tag](#cronJobs_pattern1_image_tag )               | No      | string           | No         | -          | Image tag         |

##### <a name="cronJobs_pattern1_image_pullPolicy"></a>2.1.18.1. Property `stack > cronJobs > ^.*$ > image > pullPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** Image pull policy

Must be one of:
* "Always"
* "IfNotPresent"
* "Never"

##### <a name="cronJobs_pattern1_image_repository"></a>2.1.18.2. Property `stack > cronJobs > ^.*$ > image > repository`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image repository

##### <a name="cronJobs_pattern1_image_tag"></a>2.1.18.3. Property `stack > cronJobs > ^.*$ > image > tag`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image tag

#### <a name="cronJobs_pattern1_imagePullSecrets"></a>2.1.19. Property `stack > cronJobs > ^.*$ > imagePullSecrets`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [imagePullSecrets items](#cronJobs_pattern1_imagePullSecrets_items) | -           |

##### <a name="cronJobs_pattern1_imagePullSecrets_items"></a>2.1.19.1. stack > cronJobs > ^.*$ > imagePullSecrets > imagePullSecrets items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_ingress"></a>2.1.20. Property `stack > cronJobs > ^.*$ > ingress`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Ingress configuration

| Property                                                     | Pattern | Type            | Deprecated | Definition | Title/Description                                                 |
| ------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_ingress_annotations )     | No      | object          | No         | -          | -                                                                 |
| - [className](#cronJobs_pattern1_ingress_className )         | No      | string          | No         | -          | Ingress class name                                                |
| - [enabled](#cronJobs_pattern1_ingress_enabled )             | No      | boolean         | No         | -          | Enable ingress                                                    |
| - [host](#cronJobs_pattern1_ingress_host )                   | No      | string          | No         | -          | Ingress host                                                      |
| - [oidcProtected](#cronJobs_pattern1_ingress_oidcProtected ) | No      | boolean         | No         | -          | Enable OIDC protection (route to oauth2-proxy when using Ingress) |
| - [paths](#cronJobs_pattern1_ingress_paths )                 | No      | array of object | No         | -          | List of ingress paths                                             |
| - [rules](#cronJobs_pattern1_ingress_rules )                 | No      | array           | No         | -          | List of ingress rules                                             |
| - [tls](#cronJobs_pattern1_ingress_tls )                     | No      | array           | No         | -          | List of ingress TLS configurations                                |

##### <a name="cronJobs_pattern1_ingress_annotations"></a>2.1.20.1. Property `stack > cronJobs > ^.*$ > ingress > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [external-dns.alpha.kubernetes.io/ttl](#cronJobs_pattern1_ingress_annotations_external-dnsalphakubernetesio/ttl )                             | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/affinity](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/affinity )                             | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-connect-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-connect-timeout )   | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-read-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-read-timeout )         | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-send-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-send-timeout )         | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/session-cookie-max-age](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-max-age ) | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/session-cookie-name](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-name )       | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_ingress_annotations_external-dnsalphakubernetesio/ttl"></a>2.1.20.1.1. Property `stack > cronJobs > ^.*$ > ingress > annotations > external-dns.alpha.kubernetes.io/ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/affinity"></a>2.1.20.1.2. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/affinity`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-connect-timeout"></a>2.1.20.1.3. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-connect-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-read-timeout"></a>2.1.20.1.4. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-read-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-send-timeout"></a>2.1.20.1.5. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-send-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-max-age"></a>2.1.20.1.6. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/session-cookie-max-age`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-name"></a>2.1.20.1.7. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/session-cookie-name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_ingress_className"></a>2.1.20.2. Property `stack > cronJobs > ^.*$ > ingress > className`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress class name

##### <a name="cronJobs_pattern1_ingress_enabled"></a>2.1.20.3. Property `stack > cronJobs > ^.*$ > ingress > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable ingress

##### <a name="cronJobs_pattern1_ingress_host"></a>2.1.20.4. Property `stack > cronJobs > ^.*$ > ingress > host`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress host

##### <a name="cronJobs_pattern1_ingress_oidcProtected"></a>2.1.20.5. Property `stack > cronJobs > ^.*$ > ingress > oidcProtected`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC protection (route to oauth2-proxy when using Ingress)

##### <a name="cronJobs_pattern1_ingress_paths"></a>2.1.20.6. Property `stack > cronJobs > ^.*$ > ingress > paths`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of ingress paths

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                       | Description |
| ----------------------------------------------------- | ----------- |
| [paths items](#cronJobs_pattern1_ingress_paths_items) | -           |

###### <a name="cronJobs_pattern1_ingress_paths_items"></a>2.1.20.6.1. stack > cronJobs > ^.*$ > ingress > paths > paths items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_ingress_paths_items_path )         | No      | string | No         | -          | Ingress path      |
| - [pathType](#cronJobs_pattern1_ingress_paths_items_pathType ) | No      | string | No         | -          | Ingress path type |

###### <a name="cronJobs_pattern1_ingress_paths_items_path"></a>2.1.20.6.1.1. Property `stack > cronJobs > ^.*$ > ingress > paths > paths items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress path

###### <a name="cronJobs_pattern1_ingress_paths_items_pathType"></a>2.1.20.6.1.2. Property `stack > cronJobs > ^.*$ > ingress > paths > paths items > pathType`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress path type

##### <a name="cronJobs_pattern1_ingress_rules"></a>2.1.20.7. Property `stack > cronJobs > ^.*$ > ingress > rules`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of ingress rules

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_ingress_tls"></a>2.1.20.8. Property `stack > cronJobs > ^.*$ > ingress > tls`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of ingress TLS configurations

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_initContainers"></a>2.1.21. Property `stack > cronJobs > ^.*$ > initContainers`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of init containers

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_kedaAutoscaling"></a>2.1.22. Property `stack > cronJobs > ^.*$ > kedaAutoscaling`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** KEDA autoscaling configuration (creates a ScaledObject instead of HPA)

| Property                                                                 | Pattern | Type            | Deprecated | Definition | Title/Description                                                                         |
| ------------------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------------------------- |
| - [advanced](#cronJobs_pattern1_kedaAutoscaling_advanced )               | No      | object          | No         | -          | Advanced KEDA ScaledObject configuration                                                  |
| - [cooldownPeriod](#cronJobs_pattern1_kedaAutoscaling_cooldownPeriod )   | No      | integer         | No         | -          | Period in seconds to wait after the last trigger fires before scaling back to minReplicas |
| - [enabled](#cronJobs_pattern1_kedaAutoscaling_enabled )                 | No      | boolean         | No         | -          | Enable KEDA autoscaling                                                                   |
| - [maxReplicas](#cronJobs_pattern1_kedaAutoscaling_maxReplicas )         | No      | integer         | No         | -          | Maximum number of replicas                                                                |
| - [minReplicas](#cronJobs_pattern1_kedaAutoscaling_minReplicas )         | No      | integer         | No         | -          | Minimum number of replicas                                                                |
| - [pollingInterval](#cronJobs_pattern1_kedaAutoscaling_pollingInterval ) | No      | integer         | No         | -          | Interval in seconds to check each trigger                                                 |
| - [triggers](#cronJobs_pattern1_kedaAutoscaling_triggers )               | No      | array of object | No         | -          | List of KEDA triggers (e.g. prometheus, cpu, memory, cron)                                |

##### <a name="cronJobs_pattern1_kedaAutoscaling_advanced"></a>2.1.22.1. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > advanced`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Advanced KEDA ScaledObject configuration

##### <a name="cronJobs_pattern1_kedaAutoscaling_cooldownPeriod"></a>2.1.22.2. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > cooldownPeriod`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Period in seconds to wait after the last trigger fires before scaling back to minReplicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_enabled"></a>2.1.22.3. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable KEDA autoscaling

##### <a name="cronJobs_pattern1_kedaAutoscaling_maxReplicas"></a>2.1.22.4. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > maxReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Maximum number of replicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_minReplicas"></a>2.1.22.5. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > minReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Minimum number of replicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_pollingInterval"></a>2.1.22.6. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > pollingInterval`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Interval in seconds to check each trigger

##### <a name="cronJobs_pattern1_kedaAutoscaling_triggers"></a>2.1.22.7. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > triggers`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of KEDA triggers (e.g. prometheus, cpu, memory, cron)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [triggers items](#cronJobs_pattern1_kedaAutoscaling_triggers_items) | -           |

###### <a name="cronJobs_pattern1_kedaAutoscaling_triggers_items"></a>2.1.22.7.1. stack > cronJobs > ^.*$ > kedaAutoscaling > triggers > triggers items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

#### <a name="cronJobs_pattern1_livenessProbe"></a>2.1.23. Property `stack > cronJobs > ^.*$ > livenessProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Liveness probe configuration

| Property                                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                                                                     |
| ------------------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [failureThreshold](#cronJobs_pattern1_livenessProbe_failureThreshold )       | No      | number | No         | -          | Number of failures before the probe is considered failed                              |
| - [httpGet](#cronJobs_pattern1_livenessProbe_httpGet )                         | No      | object | No         | -          | HTTP probe configuration (exec & tcpSocket are also available)                        |
| - [initialDelaySeconds](#cronJobs_pattern1_livenessProbe_initialDelaySeconds ) | No      | number | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_livenessProbe_periodSeconds )             | No      | number | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_livenessProbe_successThreshold )       | No      | number | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_livenessProbe_timeoutSeconds )           | No      | number | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_livenessProbe_failureThreshold"></a>2.1.23.1. Property `stack > cronJobs > ^.*$ > livenessProbe > failureThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_livenessProbe_httpGet"></a>2.1.23.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP probe configuration (exec & tcpSocket are also available)

| Property                                                     | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------ | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_livenessProbe_httpGet_path )     | No      | string      | No         | -          | Path to probe     |
| - [port](#cronJobs_pattern1_livenessProbe_httpGet_port )     | No      | Combination | No         | -          | Port to probe     |
| - [scheme](#cronJobs_pattern1_livenessProbe_httpGet_scheme ) | No      | string      | No         | -          | Scheme to use     |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_path"></a>2.1.23.2.1. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path to probe

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port"></a>2.1.23.2.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Port to probe

| One of(Option)                                                   |
| ---------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i0) |
| [item 1](#cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i1) |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i0"></a>2.1.23.2.2.1. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i1"></a>2.1.23.2.2.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_scheme"></a>2.1.23.2.3. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Scheme to use

##### <a name="cronJobs_pattern1_livenessProbe_initialDelaySeconds"></a>2.1.23.3. Property `stack > cronJobs > ^.*$ > livenessProbe > initialDelaySeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_livenessProbe_periodSeconds"></a>2.1.23.4. Property `stack > cronJobs > ^.*$ > livenessProbe > periodSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_livenessProbe_successThreshold"></a>2.1.23.5. Property `stack > cronJobs > ^.*$ > livenessProbe > successThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_livenessProbe_timeoutSeconds"></a>2.1.23.6. Property `stack > cronJobs > ^.*$ > livenessProbe > timeoutSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_nameOverride"></a>2.1.24. Property `stack > cronJobs > ^.*$ > nameOverride`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name to prefix the K8s resources with, combined with the stack name prefix

#### <a name="cronJobs_pattern1_nodeSelector"></a>2.1.25. Property `stack > cronJobs > ^.*$ > nodeSelector`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description              |
| -------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------ |
| - [kubernetes.io/arch](#cronJobs_pattern1_nodeSelector_kubernetesio/arch ) | No      | string | No         | -          | Node selector for architecture |

##### <a name="cronJobs_pattern1_nodeSelector_kubernetesio/arch"></a>2.1.25.1. Property `stack > cronJobs > ^.*$ > nodeSelector > kubernetes.io/arch`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Node selector for architecture

#### <a name="cronJobs_pattern1_oidcProxy"></a>2.1.26. Property `stack > cronJobs > ^.*$ > oidcProxy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                               | Pattern | Type            | Deprecated | Definition | Title/Description                            |
| ---------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | -------------------------------------------- |
| - [additionalHeaders](#cronJobs_pattern1_oidcProxy_additionalHeaders ) | No      | array           | No         | -          | Additional headers to add                    |
| - [additionalSecrets](#cronJobs_pattern1_oidcProxy_additionalSecrets ) | No      | array           | No         | -          | Additional secrets to mount                  |
| - [annotations](#cronJobs_pattern1_oidcProxy_annotations )             | No      | object          | No         | -          | Annotations to add to the OIDC proxy         |
| - [cookieRefresh](#cronJobs_pattern1_oidcProxy_cookieRefresh )         | No      | string          | No         | -          | Refresh tokens and cookies after this period |
| - [enabled](#cronJobs_pattern1_oidcProxy_enabled )                     | No      | boolean         | No         | -          | Enable OIDC proxy                            |
| - [extraArgs](#cronJobs_pattern1_oidcProxy_extraArgs )                 | No      | array of string | No         | -          | Extra arguments to pass to the OIDC proxy    |
| - [image](#cronJobs_pattern1_oidcProxy_image )                         | No      | object          | No         | -          | -                                            |
| - [replicaCount](#cronJobs_pattern1_oidcProxy_replicaCount )           | No      | integer         | No         | -          | Number of replicas                           |
| - [resources](#cronJobs_pattern1_oidcProxy_resources )                 | No      | object          | No         | -          | -                                            |
| - [skipAuth](#cronJobs_pattern1_oidcProxy_skipAuth )                   | No      | array of object | No         | -          | Paths to skip authentication                 |
| - [volumeMounts](#cronJobs_pattern1_oidcProxy_volumeMounts )           | No      | array           | No         | -          | Volume mounts for the OIDC proxy             |

##### <a name="cronJobs_pattern1_oidcProxy_additionalHeaders"></a>2.1.26.1. Property `stack > cronJobs > ^.*$ > oidcProxy > additionalHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional headers to add

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxy_additionalSecrets"></a>2.1.26.2. Property `stack > cronJobs > ^.*$ > oidcProxy > additionalSecrets`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional secrets to mount

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxy_annotations"></a>2.1.26.3. Property `stack > cronJobs > ^.*$ > oidcProxy > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to the OIDC proxy

##### <a name="cronJobs_pattern1_oidcProxy_cookieRefresh"></a>2.1.26.4. Property `stack > cronJobs > ^.*$ > oidcProxy > cookieRefresh`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Refresh tokens and cookies after this period

##### <a name="cronJobs_pattern1_oidcProxy_enabled"></a>2.1.26.5. Property `stack > cronJobs > ^.*$ > oidcProxy > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC proxy

##### <a name="cronJobs_pattern1_oidcProxy_extraArgs"></a>2.1.26.6. Property `stack > cronJobs > ^.*$ > oidcProxy > extraArgs`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Extra arguments to pass to the OIDC proxy

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                 | Description |
| --------------------------------------------------------------- | ----------- |
| [extraArgs items](#cronJobs_pattern1_oidcProxy_extraArgs_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxy_extraArgs_items"></a>2.1.26.6.1. stack > cronJobs > ^.*$ > oidcProxy > extraArgs > extraArgs items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxy_image"></a>2.1.26.7. Property `stack > cronJobs > ^.*$ > oidcProxy > image`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [repository](#cronJobs_pattern1_oidcProxy_image_repository ) | No      | string | No         | -          | Image repository  |
| - [tag](#cronJobs_pattern1_oidcProxy_image_tag )               | No      | string | No         | -          | Image tag         |

###### <a name="cronJobs_pattern1_oidcProxy_image_repository"></a>2.1.26.7.1. Property `stack > cronJobs > ^.*$ > oidcProxy > image > repository`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image repository

###### <a name="cronJobs_pattern1_oidcProxy_image_tag"></a>2.1.26.7.2. Property `stack > cronJobs > ^.*$ > oidcProxy > image > tag`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image tag

##### <a name="cronJobs_pattern1_oidcProxy_replicaCount"></a>2.1.26.8. Property `stack > cronJobs > ^.*$ > oidcProxy > replicaCount`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of replicas

##### <a name="cronJobs_pattern1_oidcProxy_resources"></a>2.1.26.9. Property `stack > cronJobs > ^.*$ > oidcProxy > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [limits](#cronJobs_pattern1_oidcProxy_resources_limits )     | No      | object | No         | -          | -                 |
| - [requests](#cronJobs_pattern1_oidcProxy_resources_requests ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits"></a>2.1.26.9.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                          | Pattern | Type        | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_oidcProxy_resources_limits_cpu )       | No      | Combination | No         | -          | CPU limit         |
| - [memory](#cronJobs_pattern1_oidcProxy_resources_limits_memory ) | No      | string      | No         | -          | Memory limit      |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu"></a>2.1.26.9.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU limit

| One of(Option)                                                       |
| -------------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i0"></a>2.1.26.9.1.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i1"></a>2.1.26.9.1.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_memory"></a>2.1.26.9.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory limit

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests"></a>2.1.26.9.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                            | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_oidcProxy_resources_requests_cpu )       | No      | Combination | No         | -          | CPU request       |
| - [memory](#cronJobs_pattern1_oidcProxy_resources_requests_memory ) | No      | string      | No         | -          | Memory request    |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu"></a>2.1.26.9.2.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU request

| One of(Option)                                                         |
| ---------------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i0"></a>2.1.26.9.2.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i1"></a>2.1.26.9.2.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_memory"></a>2.1.26.9.2.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory request

##### <a name="cronJobs_pattern1_oidcProxy_skipAuth"></a>2.1.26.10. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Paths to skip authentication

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                               | Description |
| ------------------------------------------------------------- | ----------- |
| [skipAuth items](#cronJobs_pattern1_oidcProxy_skipAuth_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items"></a>2.1.26.10.1. stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [method](#cronJobs_pattern1_oidcProxy_skipAuth_items_method ) | No      | string | No         | -          | -                 |
| - [path](#cronJobs_pattern1_oidcProxy_skipAuth_items_path )     | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items_method"></a>2.1.26.10.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items > method`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items_path"></a>2.1.26.10.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxy_volumeMounts"></a>2.1.26.11. Property `stack > cronJobs > ^.*$ > oidcProxy > volumeMounts`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Volume mounts for the OIDC proxy

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_oidcProxyGateway"></a>2.1.27. Property `stack > cronJobs > ^.*$ > oidcProxyGateway`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Native Envoy Gateway OIDC authentication configuration (used when gateway.oidcProtected is true). Requires explicit clientID and issuer configuration. clientSecret is auto-referenced from appSecrets. redirectURL is auto-generated as https://<gateway.host>/oauth2/callback.

| Property                                                                        | Pattern | Type            | Deprecated | Definition | Title/Description                                                                      |
| ------------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | -------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_oidcProxyGateway_annotations )               | No      | object          | No         | -          | Annotations to add to SecurityPolicy resources                                         |
| - [clientID](#cronJobs_pattern1_oidcProxyGateway_clientID )                     | No      | string          | No         | -          | OIDC client ID (required when gateway.oidcProtected is enabled)                        |
| - [cookieDomain](#cronJobs_pattern1_oidcProxyGateway_cookieDomain )             | No      | string          | No         | -          | Optional root domain for sharing tokens across subdomains (e.g., cluster.dev.czi.team) |
| - [cookieNames](#cronJobs_pattern1_oidcProxyGateway_cookieNames )               | No      | object          | No         | -          | Customize cookie names                                                                 |
| - [forwardAccessToken](#cronJobs_pattern1_oidcProxyGateway_forwardAccessToken ) | No      | boolean         | No         | -          | Forward access token to backend service                                                |
| - [logoutPath](#cronJobs_pattern1_oidcProxyGateway_logoutPath )                 | No      | string          | No         | -          | Path for logout operations                                                             |
| - [provider](#cronJobs_pattern1_oidcProxyGateway_provider )                     | No      | object          | No         | -          | OIDC provider configuration                                                            |
| - [refreshToken](#cronJobs_pattern1_oidcProxyGateway_refreshToken )             | No      | boolean         | No         | -          | Use refresh tokens to refresh access tokens (default true in Envoy Gateway v1.6.0+)    |
| - [resources](#cronJobs_pattern1_oidcProxyGateway_resources )                   | No      | array           | No         | -          | Optional OAuth2 resources parameter                                                    |
| - [scopes](#cronJobs_pattern1_oidcProxyGateway_scopes )                         | No      | array of string | No         | -          | OIDC scopes to request                                                                 |
| - [skipAuth](#cronJobs_pattern1_oidcProxyGateway_skipAuth )                     | No      | array of object | No         | -          | Paths to skip authentication (creates separate public HTTPRoute)                       |

##### <a name="cronJobs_pattern1_oidcProxyGateway_annotations"></a>2.1.27.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to SecurityPolicy resources

##### <a name="cronJobs_pattern1_oidcProxyGateway_clientID"></a>2.1.27.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > clientID`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** OIDC client ID (required when gateway.oidcProtected is enabled)

##### <a name="cronJobs_pattern1_oidcProxyGateway_cookieDomain"></a>2.1.27.3. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieDomain`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional root domain for sharing tokens across subdomains (e.g., cluster.dev.czi.team)

##### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames"></a>2.1.27.4. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Customize cookie names

| Property                                                                      | Pattern | Type   | Deprecated | Definition | Title/Description                   |
| ----------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------- |
| - [accessToken](#cronJobs_pattern1_oidcProxyGateway_cookieNames_accessToken ) | No      | string | No         | -          | Custom name for access token cookie |
| - [idToken](#cronJobs_pattern1_oidcProxyGateway_cookieNames_idToken )         | No      | string | No         | -          | Custom name for ID token cookie     |

###### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames_accessToken"></a>2.1.27.4.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames > accessToken`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom name for access token cookie

###### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames_idToken"></a>2.1.27.4.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames > idToken`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom name for ID token cookie

##### <a name="cronJobs_pattern1_oidcProxyGateway_forwardAccessToken"></a>2.1.27.5. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > forwardAccessToken`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Forward access token to backend service

##### <a name="cronJobs_pattern1_oidcProxyGateway_logoutPath"></a>2.1.27.6. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > logoutPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path for logout operations

##### <a name="cronJobs_pattern1_oidcProxyGateway_provider"></a>2.1.27.7. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** OIDC provider configuration

| Property                                                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                                                         |
| ---------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [authorizationEndpoint](#cronJobs_pattern1_oidcProxyGateway_provider_authorizationEndpoint ) | No      | string | No         | -          | Optional authorization endpoint (auto-discovered by provider if empty)    |
| - [issuer](#cronJobs_pattern1_oidcProxyGateway_provider_issuer )                               | No      | string | No         | -          | OIDC provider issuer URL (required when gateway.oidcProtected is enabled) |
| - [tokenEndpoint](#cronJobs_pattern1_oidcProxyGateway_provider_tokenEndpoint )                 | No      | string | No         | -          | Optional token endpoint (auto-discovered by provider if empty)            |

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_authorizationEndpoint"></a>2.1.27.7.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > authorizationEndpoint`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional authorization endpoint (auto-discovered by provider if empty)

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_issuer"></a>2.1.27.7.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > issuer`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** OIDC provider issuer URL (required when gateway.oidcProtected is enabled)

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_tokenEndpoint"></a>2.1.27.7.3. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > tokenEndpoint`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional token endpoint (auto-discovered by provider if empty)

##### <a name="cronJobs_pattern1_oidcProxyGateway_refreshToken"></a>2.1.27.8. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > refreshToken`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Use refresh tokens to refresh access tokens (default true in Envoy Gateway v1.6.0+)

##### <a name="cronJobs_pattern1_oidcProxyGateway_resources"></a>2.1.27.9. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > resources`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Optional OAuth2 resources parameter

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxyGateway_scopes"></a>2.1.27.10. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > scopes`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** OIDC scopes to request

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                  | Description |
| ---------------------------------------------------------------- | ----------- |
| [scopes items](#cronJobs_pattern1_oidcProxyGateway_scopes_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxyGateway_scopes_items"></a>2.1.27.10.1. stack > cronJobs > ^.*$ > oidcProxyGateway > scopes > scopes items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth"></a>2.1.27.11. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Paths to skip authentication (creates separate public HTTPRoute)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                      | Description |
| -------------------------------------------------------------------- | ----------- |
| [skipAuth items](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items"></a>2.1.27.11.1. stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                               | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [method](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items_method ) | No      | string | No         | -          | -                 |
| - [path](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items_path )     | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items_method"></a>2.1.27.11.1.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items > method`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items_path"></a>2.1.27.11.1.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_persistence"></a>2.1.28. Property `stack > cronJobs > ^.*$ > persistence`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type    | Deprecated | Definition | Title/Description      |
| ---------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------- |
| - [enabled](#cronJobs_pattern1_persistence_enabled )             | No      | boolean | No         | -          | Enable persistence     |
| - [existingClaim](#cronJobs_pattern1_persistence_existingClaim ) | No      | string  | No         | -          | Existing PVC name      |
| - [mountPath](#cronJobs_pattern1_persistence_mountPath )         | No      | string  | No         | -          | Mount path for the PVC |
| - [pvc](#cronJobs_pattern1_persistence_pvc )                     | No      | object  | No         | -          | -                      |

##### <a name="cronJobs_pattern1_persistence_enabled"></a>2.1.28.1. Property `stack > cronJobs > ^.*$ > persistence > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable persistence

##### <a name="cronJobs_pattern1_persistence_existingClaim"></a>2.1.28.2. Property `stack > cronJobs > ^.*$ > persistence > existingClaim`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Existing PVC name

##### <a name="cronJobs_pattern1_persistence_mountPath"></a>2.1.28.3. Property `stack > cronJobs > ^.*$ > persistence > mountPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Mount path for the PVC

##### <a name="cronJobs_pattern1_persistence_pvc"></a>2.1.28.4. Property `stack > cronJobs > ^.*$ > persistence > pvc`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                   | Pattern | Type                      | Deprecated | Definition | Title/Description        |
| -------------------------------------------------------------------------- | ------- | ------------------------- | ---------- | ---------- | ------------------------ |
| - [accessModes](#cronJobs_pattern1_persistence_pvc_accessModes )           | No      | array of enum (of string) | No         | -          | Access modes for the PVC |
| - [dataSource](#cronJobs_pattern1_persistence_pvc_dataSource )             | No      | object                    | No         | -          | -                        |
| - [resources](#cronJobs_pattern1_persistence_pvc_resources )               | No      | object                    | No         | -          | -                        |
| - [storageClassName](#cronJobs_pattern1_persistence_pvc_storageClassName ) | No      | string                    | No         | -          | Storage class name       |

###### <a name="cronJobs_pattern1_persistence_pvc_accessModes"></a>2.1.28.4.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > accessModes`

|              |                             |
| ------------ | --------------------------- |
| **Type**     | `array of enum (of string)` |
| **Required** | No                          |

**Description:** Access modes for the PVC

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                           | Description |
| ------------------------------------------------------------------------- | ----------- |
| [accessModes items](#cronJobs_pattern1_persistence_pvc_accessModes_items) | -           |

###### <a name="cronJobs_pattern1_persistence_pvc_accessModes_items"></a>2.1.28.4.1.1. stack > cronJobs > ^.*$ > persistence > pvc > accessModes > accessModes items

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "ReadWriteOnce"
* "ReadOnlyMany"
* "ReadWriteMany"
* "ReadWriteOncePod"

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource"></a>2.1.28.4.2. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                              | Pattern | Type   | Deprecated | Definition | Title/Description                                               |
| --------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | --------------------------------------------------------------- |
| - [apiGroup](#cronJobs_pattern1_persistence_pvc_dataSource_apiGroup ) | No      | string | No         | -          | API version of the data source                                  |
| - [kind](#cronJobs_pattern1_persistence_pvc_dataSource_kind )         | No      | string | No         | -          | Kind of the data source [VolumeSnapshot, PersistentVolumeClaim] |
| - [name](#cronJobs_pattern1_persistence_pvc_dataSource_name )         | No      | string | No         | -          | Name of the data source                                         |

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_apiGroup"></a>2.1.28.4.2.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > apiGroup`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** API version of the data source

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_kind"></a>2.1.28.4.2.2. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > kind`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Kind of the data source [VolumeSnapshot, PersistentVolumeClaim]

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_name"></a>2.1.28.4.2.3. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the data source

###### <a name="cronJobs_pattern1_persistence_pvc_resources"></a>2.1.28.4.3. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                             | Pattern | Type   | Deprecated | Definition | Title/Description     |
| -------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | --------------------- |
| - [requests](#cronJobs_pattern1_persistence_pvc_resources_requests ) | No      | object | No         | -          | PVC resource requests |

###### <a name="cronJobs_pattern1_persistence_pvc_resources_requests"></a>2.1.28.4.3.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** PVC resource requests

| Property                                                                    | Pattern | Type   | Deprecated | Definition | Title/Description        |
| --------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------ |
| - [storage](#cronJobs_pattern1_persistence_pvc_resources_requests_storage ) | No      | string | No         | -          | Storage resource request |

###### <a name="cronJobs_pattern1_persistence_pvc_resources_requests_storage"></a>2.1.28.4.3.1.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources > requests > storage`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage resource request

###### <a name="cronJobs_pattern1_persistence_pvc_storageClassName"></a>2.1.28.4.4. Property `stack > cronJobs > ^.*$ > persistence > pvc > storageClassName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage class name

#### <a name="cronJobs_pattern1_podAnnotations"></a>2.1.29. Property `stack > cronJobs > ^.*$ > podAnnotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to pods

#### <a name="cronJobs_pattern1_podLabels"></a>2.1.30. Property `stack > cronJobs > ^.*$ > podLabels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global labels to add to all pods

#### <a name="cronJobs_pattern1_podSecurityContext"></a>2.1.31. Property `stack > cronJobs > ^.*$ > podSecurityContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Pod security context

#### <a name="cronJobs_pattern1_progressDeadlineSeconds"></a>2.1.32. Property `stack > cronJobs > ^.*$ > progressDeadlineSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** the number of seconds the Deployment controller waits before indicating (in the Deployment status) that the Deployment progress has stalled

#### <a name="cronJobs_pattern1_readinessProbe"></a>2.1.33. Property `stack > cronJobs > ^.*$ > readinessProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Readiness probe configuration

| Property                                                                        | Pattern | Type   | Deprecated | Definition | Title/Description                                                                     |
| ------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [failureThreshold](#cronJobs_pattern1_readinessProbe_failureThreshold )       | No      | number | No         | -          | Number of failures before the probe is considered failed                              |
| - [httpGet](#cronJobs_pattern1_readinessProbe_httpGet )                         | No      | object | No         | -          | HTTP probe configuration (exec & tcpSocket are also available)                        |
| - [initialDelaySeconds](#cronJobs_pattern1_readinessProbe_initialDelaySeconds ) | No      | number | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_readinessProbe_periodSeconds )             | No      | number | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_readinessProbe_successThreshold )       | No      | number | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_readinessProbe_timeoutSeconds )           | No      | number | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_readinessProbe_failureThreshold"></a>2.1.33.1. Property `stack > cronJobs > ^.*$ > readinessProbe > failureThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_readinessProbe_httpGet"></a>2.1.33.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP probe configuration (exec & tcpSocket are also available)

| Property                                                      | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_readinessProbe_httpGet_path )     | No      | string      | No         | -          | Path to probe     |
| - [port](#cronJobs_pattern1_readinessProbe_httpGet_port )     | No      | Combination | No         | -          | Port to probe     |
| - [scheme](#cronJobs_pattern1_readinessProbe_httpGet_scheme ) | No      | string      | No         | -          | Scheme to use     |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_path"></a>2.1.33.2.1. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path to probe

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port"></a>2.1.33.2.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Port to probe

| One of(Option)                                                    |
| ----------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i0) |
| [item 1](#cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i1) |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i0"></a>2.1.33.2.2.1. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i1"></a>2.1.33.2.2.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_scheme"></a>2.1.33.2.3. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Scheme to use

##### <a name="cronJobs_pattern1_readinessProbe_initialDelaySeconds"></a>2.1.33.3. Property `stack > cronJobs > ^.*$ > readinessProbe > initialDelaySeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_readinessProbe_periodSeconds"></a>2.1.33.4. Property `stack > cronJobs > ^.*$ > readinessProbe > periodSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_readinessProbe_successThreshold"></a>2.1.33.5. Property `stack > cronJobs > ^.*$ > readinessProbe > successThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_readinessProbe_timeoutSeconds"></a>2.1.33.6. Property `stack > cronJobs > ^.*$ > readinessProbe > timeoutSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_replicaCount"></a>2.1.34. Property `stack > cronJobs > ^.*$ > replicaCount`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of replicas

#### <a name="cronJobs_pattern1_resources"></a>2.1.35. Property `stack > cronJobs > ^.*$ > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource requests and limits for the primary container

| Property                                             | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [limits](#cronJobs_pattern1_resources_limits )     | No      | object | No         | -          | Resource limits   |
| - [requests](#cronJobs_pattern1_resources_requests ) | No      | object | No         | -          | Resource requests |

##### <a name="cronJobs_pattern1_resources_limits"></a>2.1.35.1. Property `stack > cronJobs > ^.*$ > resources > limits`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource limits

| Property                                                | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_resources_limits_cpu )       | No      | Combination | No         | -          | CPU limit         |
| - [memory](#cronJobs_pattern1_resources_limits_memory ) | No      | string      | No         | -          | Memory limit      |

###### <a name="cronJobs_pattern1_resources_limits_cpu"></a>2.1.35.1.1. Property `stack > cronJobs > ^.*$ > resources > limits > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU limit

| One of(Option)                                             |
| ---------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_resources_limits_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_resources_limits_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_resources_limits_cpu_oneOf_i0"></a>2.1.35.1.1.1. Property `stack > cronJobs > ^.*$ > resources > limits > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_limits_cpu_oneOf_i1"></a>2.1.35.1.1.2. Property `stack > cronJobs > ^.*$ > resources > limits > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_limits_memory"></a>2.1.35.1.2. Property `stack > cronJobs > ^.*$ > resources > limits > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory limit

##### <a name="cronJobs_pattern1_resources_requests"></a>2.1.35.2. Property `stack > cronJobs > ^.*$ > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource requests

| Property                                                  | Pattern | Type        | Deprecated | Definition | Title/Description |
| --------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_resources_requests_cpu )       | No      | Combination | No         | -          | CPU request       |
| - [memory](#cronJobs_pattern1_resources_requests_memory ) | No      | string      | No         | -          | Memory request    |

###### <a name="cronJobs_pattern1_resources_requests_cpu"></a>2.1.35.2.1. Property `stack > cronJobs > ^.*$ > resources > requests > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU request

| One of(Option)                                               |
| ------------------------------------------------------------ |
| [item 0](#cronJobs_pattern1_resources_requests_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_resources_requests_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_resources_requests_cpu_oneOf_i0"></a>2.1.35.2.1.1. Property `stack > cronJobs > ^.*$ > resources > requests > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_requests_cpu_oneOf_i1"></a>2.1.35.2.1.2. Property `stack > cronJobs > ^.*$ > resources > requests > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_requests_memory"></a>2.1.35.2.2. Property `stack > cronJobs > ^.*$ > resources > requests > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory request

#### <a name="cronJobs_pattern1_restartPolicy"></a>2.1.36. Property `stack > cronJobs > ^.*$ > restartPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** Restart policy for the pod

Must be one of:
* "Always"
* "OnFailure"
* "Never"

#### <a name="cronJobs_pattern1_rollout"></a>2.1.37. Property `stack > cronJobs > ^.*$ > rollout`

|                           |                      |
| ------------------------- | -------------------- |
| **Type**                  | `object`             |
| **Required**              | No                   |
| **Additional properties** | Any type allowed     |
| **Defined in**            | #/properties/rollout |

| Property                                               | Pattern | Type   | Deprecated | Definition | Title/Description                                   |
| ------------------------------------------------------ | ------- | ------ | ---------- | ---------- | --------------------------------------------------- |
| - [strategy](#cronJobs_pattern1_rollout_strategy )     | No      | object | No         | -          | Specifies the rollout strategy for the application. |
| - [](#cronJobs_pattern1_rollout_additionalProperties ) | No      | object | No         | -          | -                                                   |

##### <a name="cronJobs_pattern1_rollout_strategy"></a>2.1.37.1. Property `stack > cronJobs > ^.*$ > rollout > strategy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

**Description:** Specifies the rollout strategy for the application.

| Property                                                      | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [blueGreen](#cronJobs_pattern1_rollout_strategy_blueGreen ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen"></a>2.1.37.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

| Property                                                                                      | Pattern | Type    | Deprecated | Definition                      | Title/Description                                                                                                       |
| --------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| - [activeService](#cronJobs_pattern1_rollout_strategy_blueGreen_activeService )               | No      | string  | No         | -                               | Name of the service that the rollout modifies as the active service.                                                    |
| - [autoPromotionEnabled](#cronJobs_pattern1_rollout_strategy_blueGreen_autoPromotionEnabled ) | No      | boolean | No         | -                               | indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state. |
| - [prePromotionAnalysis](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis ) | No      | object  | No         | In #/properties/rolloutAnalysis | configuration to run analysis before a selector switch                                                                  |
| - [previewService](#cronJobs_pattern1_rollout_strategy_blueGreen_previewService )             | No      | string  | No         | -                               | Name of the service that the rollout modifies as the preview service.                                                   |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_activeService"></a>2.1.37.1.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > activeService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the active service.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_autoPromotionEnabled"></a>2.1.37.1.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > autoPromotionEnabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis"></a>2.1.37.1.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis`

|                           |                              |
| ------------------------- | ---------------------------- |
| **Type**                  | `object`                     |
| **Required**              | No                           |
| **Additional properties** | Any type allowed             |
| **Defined in**            | #/properties/rolloutAnalysis |

**Description:** configuration to run analysis before a selector switch

| Property                                                                                                         | Pattern | Type            | Deprecated | Definition | Title/Description                                                       |
| ---------------------------------------------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------- |
| - [analysisRunMetadata](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata ) | No      | object          | No         | -          | extra labels to add to the AnalysisRun                                  |
| - [args](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args )                               | No      | array of object | No         | -          | the arguments that will be added to the AnalysisRuns                    |
| - [templates](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates )                     | No      | array of object | No         | -          | reference to a list of analysis templates to combine for an AnalysisRun |
| - [](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_additionalProperties )                   | No      | object          | No         | -          | -                                                                       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata"></a>2.1.37.1.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** extra labels to add to the AnalysisRun

| Property                                                                                                             | Pattern | Type   | Deprecated | Definition | Title/Description                                |
| -------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------ |
| - [annotations](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations ) | No      | object | No         | -          | additional annotations to add to the AnalysisRun |
| - [labels](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels )           | No      | object | No         | -          | additional labels to add to the AnalysisRun      |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations"></a>2.1.37.1.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional annotations to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels"></a>2.1.37.1.1.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional labels to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args"></a>2.1.37.1.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** the arguments that will be added to the AnalysisRuns

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                             | Description |
| ------------------------------------------------------------------------------------------- | ----------- |
| [args items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items"></a>2.1.37.1.1.3.2.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name )           | No      | string | No         | -          | -                 |
| - [value](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value )         | No      | string | No         | -          | -                 |
| - [valueFrom](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name"></a>2.1.37.1.1.3.2.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value"></a>2.1.37.1.1.3.2.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom"></a>2.1.37.1.1.3.2.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                                | Pattern | Type             | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [fieldRef](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef )                         | No      | object           | No         | -          | -                 |
| - [podTemplateHashValue](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue ) | No      | enum (of string) | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef"></a>2.1.37.1.1.3.2.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [fieldPath](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath"></a>2.1.37.1.1.3.2.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef > fieldPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue"></a>2.1.37.1.1.3.2.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > podTemplateHashValue`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "Latest"
* "Stable"

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates"></a>2.1.37.1.1.3.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** reference to a list of analysis templates to combine for an AnalysisRun

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                                       | Description |
| ----------------------------------------------------------------------------------------------------- | ----------- |
| [templates items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items"></a>2.1.37.1.1.3.3.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                           | Pattern | Type    | Deprecated | Definition | Title/Description                                                         |
| ------------------------------------------------------------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [clusterScope](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope ) | No      | boolean | No         | -          | Whether to look for the templateName at cluster scope or namespace scope. |
| - [templateName](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName ) | No      | string  | No         | -          |  name of the AnalysisTemplate to use for the rollout analysis             |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope"></a>2.1.37.1.1.3.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > clusterScope`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Whether to look for the templateName at cluster scope or namespace scope.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName"></a>2.1.37.1.1.3.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > templateName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:**  name of the AnalysisTemplate to use for the rollout analysis

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_previewService"></a>2.1.37.1.1.4. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > previewService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the preview service.

#### <a name="cronJobs_pattern1_s3Storage"></a>2.1.38. Property `stack > cronJobs > ^.*$ > s3Storage`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                             | Pattern | Type                      | Deprecated | Definition | Title/Description                           |
| -------------------------------------------------------------------- | ------- | ------------------------- | ---------- | ---------- | ------------------------------------------- |
| - [accessModes](#cronJobs_pattern1_s3Storage_accessModes )           | No      | array of enum (of string) | No         | -          | Access modes for the S3 storage             |
| - [annotations](#cronJobs_pattern1_s3Storage_annotations )           | No      | object                    | No         | -          | Additional annotations for PV/PVC           |
| - [bucketName](#cronJobs_pattern1_s3Storage_bucketName )             | No      | string                    | No         | -          | S3 bucket name                              |
| - [capacity](#cronJobs_pattern1_s3Storage_capacity )                 | No      | string                    | No         | -          | Storage capacity                            |
| - [enabled](#cronJobs_pattern1_s3Storage_enabled )                   | No      | boolean                   | No         | -          | Enable S3 CSI storage                       |
| - [labels](#cronJobs_pattern1_s3Storage_labels )                     | No      | object                    | No         | -          | Additional labels for PV/PVC                |
| - [pvName](#cronJobs_pattern1_s3Storage_pvName )                     | No      | string                    | No         | -          | Custom PV name (auto-generated if empty)    |
| - [pvcName](#cronJobs_pattern1_s3Storage_pvcName )                   | No      | string                    | No         | -          | Custom PVC name (auto-generated if empty)   |
| - [reclaimPolicy](#cronJobs_pattern1_s3Storage_reclaimPolicy )       | No      | string                    | No         | -          | Reclaim policy for the PV                   |
| - [region](#cronJobs_pattern1_s3Storage_region )                     | No      | string                    | No         | -          | AWS region                                  |
| - [volumeAttributes](#cronJobs_pattern1_s3Storage_volumeAttributes ) | No      | object                    | No         | -          | Additional CSI volume attributes            |
| - [volumeHandle](#cronJobs_pattern1_s3Storage_volumeHandle )         | No      | string                    | No         | -          | CSI volume handle (auto-generated if empty) |

##### <a name="cronJobs_pattern1_s3Storage_accessModes"></a>2.1.38.1. Property `stack > cronJobs > ^.*$ > s3Storage > accessModes`

|              |                             |
| ------------ | --------------------------- |
| **Type**     | `array of enum (of string)` |
| **Required** | No                          |

**Description:** Access modes for the S3 storage

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [accessModes items](#cronJobs_pattern1_s3Storage_accessModes_items) | -           |

###### <a name="cronJobs_pattern1_s3Storage_accessModes_items"></a>2.1.38.1.1. stack > cronJobs > ^.*$ > s3Storage > accessModes > accessModes items

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "ReadWriteOnce"
* "ReadOnlyMany"
* "ReadWriteMany"
* "ReadWriteOncePod"

##### <a name="cronJobs_pattern1_s3Storage_annotations"></a>2.1.38.2. Property `stack > cronJobs > ^.*$ > s3Storage > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional annotations for PV/PVC

##### <a name="cronJobs_pattern1_s3Storage_bucketName"></a>2.1.38.3. Property `stack > cronJobs > ^.*$ > s3Storage > bucketName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** S3 bucket name

##### <a name="cronJobs_pattern1_s3Storage_capacity"></a>2.1.38.4. Property `stack > cronJobs > ^.*$ > s3Storage > capacity`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage capacity

##### <a name="cronJobs_pattern1_s3Storage_enabled"></a>2.1.38.5. Property `stack > cronJobs > ^.*$ > s3Storage > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable S3 CSI storage

##### <a name="cronJobs_pattern1_s3Storage_labels"></a>2.1.38.6. Property `stack > cronJobs > ^.*$ > s3Storage > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional labels for PV/PVC

##### <a name="cronJobs_pattern1_s3Storage_pvName"></a>2.1.38.7. Property `stack > cronJobs > ^.*$ > s3Storage > pvName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom PV name (auto-generated if empty)

##### <a name="cronJobs_pattern1_s3Storage_pvcName"></a>2.1.38.8. Property `stack > cronJobs > ^.*$ > s3Storage > pvcName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom PVC name (auto-generated if empty)

##### <a name="cronJobs_pattern1_s3Storage_reclaimPolicy"></a>2.1.38.9. Property `stack > cronJobs > ^.*$ > s3Storage > reclaimPolicy`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Reclaim policy for the PV

##### <a name="cronJobs_pattern1_s3Storage_region"></a>2.1.38.10. Property `stack > cronJobs > ^.*$ > s3Storage > region`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** AWS region

##### <a name="cronJobs_pattern1_s3Storage_volumeAttributes"></a>2.1.38.11. Property `stack > cronJobs > ^.*$ > s3Storage > volumeAttributes`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional CSI volume attributes

##### <a name="cronJobs_pattern1_s3Storage_volumeHandle"></a>2.1.38.12. Property `stack > cronJobs > ^.*$ > s3Storage > volumeHandle`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** CSI volume handle (auto-generated if empty)

#### <a name="cronJobs_pattern1_securityContext"></a>2.1.39. Property `stack > cronJobs > ^.*$ > securityContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Security context

#### <a name="cronJobs_pattern1_service"></a>2.1.40. Property `stack > cronJobs > ^.*$ > service`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Service configuration

| Property                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------- |
| - [port](#cronJobs_pattern1_service_port ) | No      | number | No         | -          | Service port      |
| - [type](#cronJobs_pattern1_service_type ) | No      | string | No         | -          | Service type      |

##### <a name="cronJobs_pattern1_service_port"></a>2.1.40.1. Property `stack > cronJobs > ^.*$ > service > port`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Service port

##### <a name="cronJobs_pattern1_service_type"></a>2.1.40.2. Property `stack > cronJobs > ^.*$ > service > type`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Service type

#### <a name="cronJobs_pattern1_serviceAccount"></a>2.1.41. Property `stack > cronJobs > ^.*$ > serviceAccount`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Service account configuration

| Property                                                        | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                   |
| --------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_serviceAccount_annotations ) | No      | object  | No         | -          | Annotations to add to the service account                                                                           |
| - [automount](#cronJobs_pattern1_serviceAccount_automount )     | No      | boolean | No         | -          | Specifies whether to automatically mount a ServiceAccount's API credentials                                         |
| - [create](#cronJobs_pattern1_serviceAccount_create )           | No      | boolean | No         | -          | Specifies whether a service account should be created                                                               |
| - [name](#cronJobs_pattern1_serviceAccount_name )               | No      | string  | No         | -          | Name of the service account to use (if not set and create is true, a name is generated using the fullname template) |

##### <a name="cronJobs_pattern1_serviceAccount_annotations"></a>2.1.41.1. Property `stack > cronJobs > ^.*$ > serviceAccount > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to the service account

##### <a name="cronJobs_pattern1_serviceAccount_automount"></a>2.1.41.2. Property `stack > cronJobs > ^.*$ > serviceAccount > automount`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Specifies whether to automatically mount a ServiceAccount's API credentials

##### <a name="cronJobs_pattern1_serviceAccount_create"></a>2.1.41.3. Property `stack > cronJobs > ^.*$ > serviceAccount > create`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Specifies whether a service account should be created

##### <a name="cronJobs_pattern1_serviceAccount_name"></a>2.1.41.4. Property `stack > cronJobs > ^.*$ > serviceAccount > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service account to use (if not set and create is true, a name is generated using the fullname template)

#### <a name="cronJobs_pattern1_shareProcessNamespace"></a>2.1.42. Property `stack > cronJobs > ^.*$ > shareProcessNamespace`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Share process namespace

#### <a name="cronJobs_pattern1_sidecars"></a>2.1.43. Property `stack > cronJobs > ^.*$ > sidecars`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of sidecars

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_startupProbe"></a>2.1.44. Property `stack > cronJobs > ^.*$ > startupProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Startup probe configuration

| Property                                                                      | Pattern | Type    | Deprecated | Definition | Title/Description                                                                     |
| ----------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_startupProbe_enabled )                         | No      | boolean | No         | -          | Enable the startup probe                                                              |
| - [exec](#cronJobs_pattern1_startupProbe_exec )                               | No      | object  | No         | -          | Exec probe configuration                                                              |
| - [failureThreshold](#cronJobs_pattern1_startupProbe_failureThreshold )       | No      | integer | No         | -          | Number of failures before the probe is considered failed                              |
| - [initialDelaySeconds](#cronJobs_pattern1_startupProbe_initialDelaySeconds ) | No      | integer | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_startupProbe_periodSeconds )             | No      | integer | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_startupProbe_successThreshold )       | No      | integer | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_startupProbe_timeoutSeconds )           | No      | integer | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_startupProbe_enabled"></a>2.1.44.1. Property `stack > cronJobs > ^.*$ > startupProbe > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable the startup probe

##### <a name="cronJobs_pattern1_startupProbe_exec"></a>2.1.44.2. Property `stack > cronJobs > ^.*$ > startupProbe > exec`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Exec probe configuration

| Property                                                   | Pattern | Type            | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------- |
| - [command](#cronJobs_pattern1_startupProbe_exec_command ) | No      | array of string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_startupProbe_exec_command"></a>2.1.44.2.1. Property `stack > cronJobs > ^.*$ > startupProbe > exec > command`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [command items](#cronJobs_pattern1_startupProbe_exec_command_items) | -           |

###### <a name="cronJobs_pattern1_startupProbe_exec_command_items"></a>2.1.44.2.1.1. stack > cronJobs > ^.*$ > startupProbe > exec > command > command items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_startupProbe_failureThreshold"></a>2.1.44.3. Property `stack > cronJobs > ^.*$ > startupProbe > failureThreshold`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_startupProbe_initialDelaySeconds"></a>2.1.44.4. Property `stack > cronJobs > ^.*$ > startupProbe > initialDelaySeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_startupProbe_periodSeconds"></a>2.1.44.5. Property `stack > cronJobs > ^.*$ > startupProbe > periodSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_startupProbe_successThreshold"></a>2.1.44.6. Property `stack > cronJobs > ^.*$ > startupProbe > successThreshold`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_startupProbe_timeoutSeconds"></a>2.1.44.7. Property `stack > cronJobs > ^.*$ > startupProbe > timeoutSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_tolerations"></a>2.1.45. Property `stack > cronJobs > ^.*$ > tolerations`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Tolerations for the pod

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_topologySpreadConstraints"></a>2.1.46. Property `stack > cronJobs > ^.*$ > topologySpreadConstraints`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Topology spread constraints for the pod

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_volumeMounts"></a>2.1.47. Property `stack > cronJobs > ^.*$ > volumeMounts`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional volume mounts on the output Deployment definition

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_volumes"></a>2.1.48. Property `stack > cronJobs > ^.*$ > volumes`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional volumes on the output Deployment definition

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

## <a name="global"></a>3. Property `stack > global`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global configuration for the stack - this serves as the default configuration for all services/jobs/cronjobs

| Property                                                          | Pattern | Type             | Deprecated | Definition              | Title/Description                                                                                                                                                                                                                                                                |
| ----------------------------------------------------------------- | ------- | ---------------- | ---------- | ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [affinity](#global_affinity )                                   | No      | object           | No         | -                       | Affinity for the pod                                                                                                                                                                                                                                                             |
| - [annotations](#global_annotations )                             | No      | object           | No         | -                       | Global annotations to add to all resources                                                                                                                                                                                                                                       |
| - [appContext](#global_appContext )                               | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [appSecrets](#global_appSecrets )                               | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [argoBuildEnv](#global_argoBuildEnv )                           | No      | object           | No         | -                       | Argo built-in environment parameters (provided by Argus API)                                                                                                                                                                                                                     |
| - [args](#global_args )                                           | No      | array of string  | No         | -                       | Arguments to pass to the command in the primary container                                                                                                                                                                                                                        |
| - [argusMetadata](#global_argusMetadata )                         | No      | object           | No         | -                       | Argus metadata (provided by Argus API)                                                                                                                                                                                                                                           |
| - [autoscaling](#global_autoscaling )                             | No      | object           | No         | -                       | Autoscaling configuration                                                                                                                                                                                                                                                        |
| - [command](#global_command )                                     | No      | array of string  | No         | -                       | Command to run in the primary container                                                                                                                                                                                                                                          |
| - [deploymentKind](#global_deploymentKind )                       | No      | enum (of string) | No         | -                       | Specifies the Kubernetes Kind for the main application workload controller (Deployment or Rollout).                                                                                                                                                                              |
| - [deploymentStage](#global_deploymentStage )                     | No      | string           | No         | -                       | Deployment stage                                                                                                                                                                                                                                                                 |
| - [dnsPolicy](#global_dnsPolicy )                                 | No      | enum (of string) | No         | -                       | DNS policy for the pod                                                                                                                                                                                                                                                           |
| - [env](#global_env )                                             | No      | array of object  | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [envFrom](#global_envFrom )                                     | No      | array of object  | No         | -                       | Environment variables from configmaps or secrets                                                                                                                                                                                                                                 |
| - [fullnameOverride](#global_fullnameOverride )                   | No      | string           | No         | -                       | Name to prefix the K8s resources with, replaces the stack name prefix                                                                                                                                                                                                            |
| - [gateway](#global_gateway )                                     | No      | object           | No         | -                       | Gateway API HTTPRoute configuration                                                                                                                                                                                                                                              |
| - [grafanaDashboard](#global_grafanaDashboard )                   | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [image](#global_image )                                         | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [imagePullSecrets](#global_imagePullSecrets )                   | No      | array of string  | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [ingress](#global_ingress )                                     | No      | object           | No         | -                       | Ingress configuration                                                                                                                                                                                                                                                            |
| - [initContainers](#global_initContainers )                       | No      | array            | No         | -                       | List of init containers                                                                                                                                                                                                                                                          |
| - [kedaAutoscaling](#global_kedaAutoscaling )                     | No      | object           | No         | -                       | KEDA autoscaling configuration (creates a ScaledObject instead of HPA)                                                                                                                                                                                                           |
| - [livenessProbe](#global_livenessProbe )                         | No      | object           | No         | -                       | Liveness probe configuration                                                                                                                                                                                                                                                     |
| - [nameOverride](#global_nameOverride )                           | No      | string           | No         | -                       | Name to prefix the K8s resources with, combined with the stack name prefix                                                                                                                                                                                                       |
| - [nodeSelector](#global_nodeSelector )                           | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [oidcProxy](#global_oidcProxy )                                 | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [oidcProxyGateway](#global_oidcProxyGateway )                   | No      | object           | No         | -                       | Native Envoy Gateway OIDC authentication configuration (used when gateway.oidcProtected is true). Requires explicit clientID and issuer configuration. clientSecret is auto-referenced from appSecrets. redirectURL is auto-generated as https://<gateway.host>/oauth2/callback. |
| - [persistence](#global_persistence )                             | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [podAnnotations](#global_podAnnotations )                       | No      | object           | No         | -                       | Annotations to add to pods                                                                                                                                                                                                                                                       |
| - [podLabels](#global_podLabels )                                 | No      | object           | No         | -                       | Global labels to add to all pods                                                                                                                                                                                                                                                 |
| - [podSecurityContext](#global_podSecurityContext )               | No      | object           | No         | -                       | Pod security context                                                                                                                                                                                                                                                             |
| - [progressDeadlineSeconds](#global_progressDeadlineSeconds )     | No      | integer          | No         | -                       | the number of seconds the Deployment controller waits before indicating (in the Deployment status) that the Deployment progress has stalled                                                                                                                                      |
| - [readinessProbe](#global_readinessProbe )                       | No      | object           | No         | -                       | Readiness probe configuration                                                                                                                                                                                                                                                    |
| - [replicaCount](#global_replicaCount )                           | No      | integer          | No         | -                       | Number of replicas                                                                                                                                                                                                                                                               |
| - [resources](#global_resources )                                 | No      | object           | No         | -                       | Resource requests and limits for the primary container                                                                                                                                                                                                                           |
| - [restartPolicy](#global_restartPolicy )                         | No      | enum (of string) | No         | -                       | Restart policy for the pod                                                                                                                                                                                                                                                       |
| - [rollout](#global_rollout )                                     | No      | object           | No         | In #/properties/rollout | -                                                                                                                                                                                                                                                                                |
| - [s3Storage](#global_s3Storage )                                 | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [securityContext](#global_securityContext )                     | No      | object           | No         | -                       | Security context                                                                                                                                                                                                                                                                 |
| - [service](#global_service )                                     | No      | object           | No         | -                       | Service configuration                                                                                                                                                                                                                                                            |
| - [serviceAccount](#global_serviceAccount )                       | No      | object           | No         | -                       | Service account configuration                                                                                                                                                                                                                                                    |
| - [shareProcessNamespace](#global_shareProcessNamespace )         | No      | boolean          | No         | -                       | Share process namespace                                                                                                                                                                                                                                                          |
| - [sidecars](#global_sidecars )                                   | No      | array            | No         | -                       | List of sidecars                                                                                                                                                                                                                                                                 |
| - [startupProbe](#global_startupProbe )                           | No      | object           | No         | -                       | Startup probe configuration                                                                                                                                                                                                                                                      |
| - [tolerations](#global_tolerations )                             | No      | array            | No         | -                       | Tolerations for the pod                                                                                                                                                                                                                                                          |
| - [topologySpreadConstraints](#global_topologySpreadConstraints ) | No      | array            | No         | -                       | Topology spread constraints for the pod                                                                                                                                                                                                                                          |
| - [volumeMounts](#global_volumeMounts )                           | No      | array            | No         | -                       | Additional volume mounts on the output Deployment definition                                                                                                                                                                                                                     |
| - [volumes](#global_volumes )                                     | No      | array            | No         | -                       | Additional volumes on the output Deployment definition                                                                                                                                                                                                                           |

### <a name="global_affinity"></a>3.1. Property `stack > global > affinity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Affinity for the pod

### <a name="global_annotations"></a>3.2. Property `stack > global > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global annotations to add to all resources

### <a name="global_appContext"></a>3.3. Property `stack > global > appContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                     | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [envContextConfigMapName](#global_appContext_envContextConfigMapName )     | No      | string | No         | -          | -                 |
| - [stackContextConfigMapName](#global_appContext_stackContextConfigMapName ) | No      | string | No         | -          | -                 |

#### <a name="global_appContext_envContextConfigMapName"></a>3.3.1. Property `stack > global > appContext > envContextConfigMapName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_appContext_stackContextConfigMapName"></a>3.3.2. Property `stack > global > appContext > stackContextConfigMapName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

### <a name="global_appSecrets"></a>3.4. Property `stack > global > appSecrets`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                             | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [clusterSecret](#global_appSecrets_clusterSecret ) | No      | object | No         | -          | -                 |
| - [envSecret](#global_appSecrets_envSecret )         | No      | object | No         | -          | -                 |
| - [stackSecret](#global_appSecrets_stackSecret )     | No      | object | No         | -          | -                 |

#### <a name="global_appSecrets_clusterSecret"></a>3.4.1. Property `stack > global > appSecrets > clusterSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                     | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#global_appSecrets_clusterSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#global_appSecrets_clusterSecret_secretName ) | No      | string | No         | -          | -                 |

##### <a name="global_appSecrets_clusterSecret_secretKey"></a>3.4.1.1. Property `stack > global > appSecrets > clusterSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_appSecrets_clusterSecret_secretName"></a>3.4.1.2. Property `stack > global > appSecrets > clusterSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_appSecrets_envSecret"></a>3.4.2. Property `stack > global > appSecrets > envSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                 | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#global_appSecrets_envSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#global_appSecrets_envSecret_secretName ) | No      | string | No         | -          | -                 |

##### <a name="global_appSecrets_envSecret_secretKey"></a>3.4.2.1. Property `stack > global > appSecrets > envSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_appSecrets_envSecret_secretName"></a>3.4.2.2. Property `stack > global > appSecrets > envSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_appSecrets_stackSecret"></a>3.4.3. Property `stack > global > appSecrets > stackSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#global_appSecrets_stackSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#global_appSecrets_stackSecret_secretName ) | No      | string | No         | -          | -                 |

##### <a name="global_appSecrets_stackSecret_secretKey"></a>3.4.3.1. Property `stack > global > appSecrets > stackSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_appSecrets_stackSecret_secretName"></a>3.4.3.2. Property `stack > global > appSecrets > stackSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

### <a name="global_argoBuildEnv"></a>3.5. Property `stack > global > argoBuildEnv`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Argo built-in environment parameters (provided by Argus API)

| Property                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description                                                                         |
| -------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------------------------------------------------------------- |
| - [appName](#global_argoBuildEnv_appName )                                 | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_NAME (this is the ArgoCD app name, not the Argus app name) |
| - [appNamespace](#global_argoBuildEnv_appNamespace )                       | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_NAMESPACE                                                  |
| - [appRevision](#global_argoBuildEnv_appRevision )                         | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION                                                   |
| - [appRevisionShort](#global_argoBuildEnv_appRevisionShort )               | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION_SHORT                                             |
| - [appRevisionShort8](#global_argoBuildEnv_appRevisionShort8 )             | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION_SHORT_8                                           |
| - [appSourcePath](#global_argoBuildEnv_appSourcePath )                     | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_PATH                                                |
| - [appSourceRepoUrl](#global_argoBuildEnv_appSourceRepoUrl )               | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL                                            |
| - [appSourceTargetRevision](#global_argoBuildEnv_appSourceTargetRevision ) | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL                                            |

#### <a name="global_argoBuildEnv_appName"></a>3.5.1. Property `stack > global > argoBuildEnv > appName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_NAME (this is the ArgoCD app name, not the Argus app name)

#### <a name="global_argoBuildEnv_appNamespace"></a>3.5.2. Property `stack > global > argoBuildEnv > appNamespace`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_NAMESPACE

#### <a name="global_argoBuildEnv_appRevision"></a>3.5.3. Property `stack > global > argoBuildEnv > appRevision`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION

#### <a name="global_argoBuildEnv_appRevisionShort"></a>3.5.4. Property `stack > global > argoBuildEnv > appRevisionShort`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION_SHORT

#### <a name="global_argoBuildEnv_appRevisionShort8"></a>3.5.5. Property `stack > global > argoBuildEnv > appRevisionShort8`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION_SHORT_8

#### <a name="global_argoBuildEnv_appSourcePath"></a>3.5.6. Property `stack > global > argoBuildEnv > appSourcePath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_PATH

#### <a name="global_argoBuildEnv_appSourceRepoUrl"></a>3.5.7. Property `stack > global > argoBuildEnv > appSourceRepoUrl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL

#### <a name="global_argoBuildEnv_appSourceTargetRevision"></a>3.5.8. Property `stack > global > argoBuildEnv > appSourceTargetRevision`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL

### <a name="global_args"></a>3.6. Property `stack > global > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Arguments to pass to the command in the primary container

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be  | Description |
| -------------------------------- | ----------- |
| [args items](#global_args_items) | -           |

#### <a name="global_args_items"></a>3.6.1. stack > global > args > args items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

### <a name="global_argusMetadata"></a>3.7. Property `stack > global > argusMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Argus metadata (provided by Argus API)

| Property                                        | Pattern | Type   | Deprecated | Definition | Title/Description                          |
| ----------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------ |
| - [appName](#global_argusMetadata_appName )     | No      | string | No         | -          | Set by Argus API to Argus app name         |
| - [envName](#global_argusMetadata_envName )     | No      | string | No         | -          | Set by Argus API to Argus environment name |
| - [repoName](#global_argusMetadata_repoName )   | No      | string | No         | -          | Set by Argus API to Argus repository name  |
| - [repoOwner](#global_argusMetadata_repoOwner ) | No      | string | No         | -          | Set by Argus API to Argus repository owner |
| - [stackName](#global_argusMetadata_stackName ) | No      | string | No         | -          | Set by Argus API to Argus stack name       |

#### <a name="global_argusMetadata_appName"></a>3.7.1. Property `stack > global > argusMetadata > appName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus app name

#### <a name="global_argusMetadata_envName"></a>3.7.2. Property `stack > global > argusMetadata > envName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus environment name

#### <a name="global_argusMetadata_repoName"></a>3.7.3. Property `stack > global > argusMetadata > repoName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus repository name

#### <a name="global_argusMetadata_repoOwner"></a>3.7.4. Property `stack > global > argusMetadata > repoOwner`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus repository owner

#### <a name="global_argusMetadata_stackName"></a>3.7.5. Property `stack > global > argusMetadata > stackName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus stack name

### <a name="global_autoscaling"></a>3.8. Property `stack > global > autoscaling`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Autoscaling configuration

| Property                                                                                      | Pattern | Type    | Deprecated | Definition | Title/Description                    |
| --------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------ |
| - [enabled](#global_autoscaling_enabled )                                                     | No      | boolean | No         | -          | Enable autoscaling                   |
| - [maxReplicas](#global_autoscaling_maxReplicas )                                             | No      | integer | No         | -          | Maximum number of replicas           |
| - [minReplicas](#global_autoscaling_minReplicas )                                             | No      | integer | No         | -          | Minimum number of replicas           |
| - [targetCPUUtilizationPercentage](#global_autoscaling_targetCPUUtilizationPercentage )       | No      | integer | No         | -          | Target CPU utilization percentage    |
| - [targetMemoryUtilizationPercentage](#global_autoscaling_targetMemoryUtilizationPercentage ) | No      | integer | No         | -          | Target memory utilization percentage |

#### <a name="global_autoscaling_enabled"></a>3.8.1. Property `stack > global > autoscaling > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable autoscaling

#### <a name="global_autoscaling_maxReplicas"></a>3.8.2. Property `stack > global > autoscaling > maxReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Maximum number of replicas

#### <a name="global_autoscaling_minReplicas"></a>3.8.3. Property `stack > global > autoscaling > minReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Minimum number of replicas

#### <a name="global_autoscaling_targetCPUUtilizationPercentage"></a>3.8.4. Property `stack > global > autoscaling > targetCPUUtilizationPercentage`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Target CPU utilization percentage

#### <a name="global_autoscaling_targetMemoryUtilizationPercentage"></a>3.8.5. Property `stack > global > autoscaling > targetMemoryUtilizationPercentage`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Target memory utilization percentage

### <a name="global_command"></a>3.9. Property `stack > global > command`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Command to run in the primary container

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be        | Description |
| -------------------------------------- | ----------- |
| [command items](#global_command_items) | -           |

#### <a name="global_command_items"></a>3.9.1. stack > global > command > command items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

### <a name="global_deploymentKind"></a>3.10. Property `stack > global > deploymentKind`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |
| **Default**  | `"Deployment"`     |

**Description:** Specifies the Kubernetes Kind for the main application workload controller (Deployment or Rollout).

Must be one of:
* "Deployment"
* "Rollout"

### <a name="global_deploymentStage"></a>3.11. Property `stack > global > deploymentStage`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Deployment stage

### <a name="global_dnsPolicy"></a>3.12. Property `stack > global > dnsPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** DNS policy for the pod

Must be one of:
* "ClusterFirst"
* "Default"
* "None"

### <a name="global_env"></a>3.13. Property `stack > global > env`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be | Description |
| ------------------------------- | ----------- |
| [env items](#global_env_items)  | -           |

#### <a name="global_env_items"></a>3.13.1. stack > global > env > env items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#global_env_items_name )   | No      | string | No         | -          | -                 |
| - [value](#global_env_items_value ) | No      | string | No         | -          | -                 |

##### <a name="global_env_items_name"></a>3.13.1.1. Property `stack > global > env > env items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_env_items_value"></a>3.13.1.2. Property `stack > global > env > env items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

### <a name="global_envFrom"></a>3.14. Property `stack > global > envFrom`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Environment variables from configmaps or secrets

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be        | Description |
| -------------------------------------- | ----------- |
| [envFrom items](#global_envFrom_items) | -           |

#### <a name="global_envFrom_items"></a>3.14.1. stack > global > envFrom > envFrom items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                              | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [configMapRef](#global_envFrom_items_configMapRef ) | No      | object | No         | -          | -                 |
| - [prefix](#global_envFrom_items_prefix )             | No      | string | No         | -          | -                 |
| - [secretRef](#global_envFrom_items_secretRef )       | No      | object | No         | -          | -                 |

##### <a name="global_envFrom_items_configMapRef"></a>3.14.1.1. Property `stack > global > envFrom > envFrom items > configMapRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

##### <a name="global_envFrom_items_prefix"></a>3.14.1.2. Property `stack > global > envFrom > envFrom items > prefix`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_envFrom_items_secretRef"></a>3.14.1.3. Property `stack > global > envFrom > envFrom items > secretRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

### <a name="global_fullnameOverride"></a>3.15. Property `stack > global > fullnameOverride`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name to prefix the K8s resources with, replaces the stack name prefix

### <a name="global_gateway"></a>3.16. Property `stack > global > gateway`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Gateway API HTTPRoute configuration

| Property                                                | Pattern | Type            | Deprecated | Definition | Title/Description                                                                                                                                                                                                                                                   |
| ------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [annotations](#global_gateway_annotations )           | No      | object          | No         | -          | Annotations to add to HTTPRoute resources                                                                                                                                                                                                                           |
| - [backendTLS](#global_gateway_backendTLS )             | No      | object          | No         | -          | TLS to the upstream Service via a BackendTLSPolicy (gateway.networking.k8s.io/v1)                                                                                                                                                                                   |
| - [basicAuth](#global_gateway_basicAuth )               | No      | object          | No         | -          | HTTP basic auth via a SecurityPolicy. Mutually exclusive with gateway.oidcProtected                                                                                                                                                                                 |
| - [cors](#global_gateway_cors )                         | No      | object          | No         | -          | CORS via a SecurityPolicy                                                                                                                                                                                                                                           |
| - [enabled](#global_gateway_enabled )                   | No      | boolean         | No         | -          | Enable Gateway API HTTPRoute (alternative to Ingress)                                                                                                                                                                                                               |
| - [gatewayName](#global_gateway_gatewayName )           | No      | string          | No         | -          | Name of the Gateway resource to attach to                                                                                                                                                                                                                           |
| - [gatewayNamespace](#global_gateway_gatewayNamespace ) | No      | string          | No         | -          | Namespace of the Gateway resource                                                                                                                                                                                                                                   |
| - [host](#global_gateway_host )                         | No      | string          | No         | -          | Hostname for HTTPRoute                                                                                                                                                                                                                                              |
| - [hostRewrite](#global_gateway_hostRewrite )           | No      | string          | No         | -          | Rewrite the Host header sent upstream via an HTTPRoute URLRewrite filter, empty disables it                                                                                                                                                                         |
| - [ipAllowList](#global_gateway_ipAllowList )           | No      | array           | No         | -          | Client IP allowlist of CIDRs that renders a SecurityPolicy authorization rule (defaultAction Deny). Empty disables it                                                                                                                                               |
| - [oidcProtected](#global_gateway_oidcProtected )       | No      | boolean         | No         | -          | Enable OIDC protection via Envoy Gateway SecurityPolicy (requires oidcProxyGateway configuration)                                                                                                                                                                   |
| - [paths](#global_gateway_paths )                       | No      | array of object | No         | -          | List of HTTPRoute paths                                                                                                                                                                                                                                             |
| - [rateLimit](#global_gateway_rateLimit )               | No      | object          | No         | -          | Local rate limit via a BackendTrafficPolicy (Envoy local token bucket, no burst concept)                                                                                                                                                                            |
| - [redirect](#global_gateway_redirect )                 | No      | object          | No         | -          | Whole-route redirect via an HTTPRoute RequestRedirect filter, replaces backend routing for the host                                                                                                                                                                 |
| - [requestHeaders](#global_gateway_requestHeaders )     | No      | object          | No         | -          | Request header modifications (HTTPRoute RequestHeaderModifier filter)                                                                                                                                                                                               |
| - [responseHeaders](#global_gateway_responseHeaders )   | No      | object          | No         | -          | Response header modifications (HTTPRoute ResponseHeaderModifier filter)                                                                                                                                                                                             |
| - [rules](#global_gateway_rules )                       | No      | array           | No         | -          | List of additional HTTPRoute rules with custom hosts. Each entry takes host, optional paths, and an optional vanity block (enabled, hostname, clusterIssuer) that renders a per-host ListenerSet so the extra host can be a vanity domain, mirroring gateway.vanity |
| - [sectionName](#global_gateway_sectionName )           | No      | string          | No         | -          | Optional section name (listener name) on the Gateway                                                                                                                                                                                                                |
| - [sessionAffinity](#global_gateway_sessionAffinity )   | No      | object          | No         | -          | Cookie-based sticky sessions via a BackendTrafficPolicy. Off by default (the ingress cookie-affinity default is not carried to the gateway)                                                                                                                         |
| - [timeouts](#global_gateway_timeouts )                 | No      | object          | No         | -          | HTTPRoute timeouts. request maps to nginx proxy-read and send-timeout. connect (optional) renders a BackendTrafficPolicy                                                                                                                                            |
| - [tlsPassthrough](#global_gateway_tlsPassthrough )     | No      | object          | No         | -          | TLS passthrough via a TLSRoute (the Gateway does not terminate TLS). Mutually exclusive with the L7 gateway features, and requires a Passthrough listener on the shared Gateway                                                                                     |
| - [vanity](#global_gateway_vanity )                     | No      | object          | No         | -          | Self-serve public/vanity-domain TLS via a tenant-owned Gateway API ListenerSet (requires Envoy Gateway >= v1.8 and cert-manager >= v1.20)                                                                                                                           |

#### <a name="global_gateway_annotations"></a>3.16.1. Property `stack > global > gateway > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to HTTPRoute resources

| Property                                                                                                 | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [external-dns.alpha.kubernetes.io/ttl](#global_gateway_annotations_external-dnsalphakubernetesio/ttl ) | No      | string | No         | -          | -                 |

##### <a name="global_gateway_annotations_external-dnsalphakubernetesio/ttl"></a>3.16.1.1. Property `stack > global > gateway > annotations > external-dns.alpha.kubernetes.io/ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_gateway_backendTLS"></a>3.16.2. Property `stack > global > gateway > backendTLS`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** TLS to the upstream Service via a BackendTLSPolicy (gateway.networking.k8s.io/v1)

| Property                                                                         | Pattern | Type    | Deprecated | Definition | Title/Description                                                                |
| -------------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | -------------------------------------------------------------------------------- |
| - [caCertificateRefs](#global_gateway_backendTLS_caCertificateRefs )             | No      | array   | No         | -          | ConfigMap refs holding the CA bundle for self-signed/internal upstreams          |
| - [enabled](#global_gateway_backendTLS_enabled )                                 | No      | boolean | No         | -          | Enable upstream TLS                                                              |
| - [hostname](#global_gateway_backendTLS_hostname )                               | No      | string  | No         | -          | SNI/validation hostname presented by the upstream (required when enabled)        |
| - [wellKnownCACertificates](#global_gateway_backendTLS_wellKnownCACertificates ) | No      | string  | No         | -          | Use the System trust store, or set "" and use caCertificateRefs for a private CA |

##### <a name="global_gateway_backendTLS_caCertificateRefs"></a>3.16.2.1. Property `stack > global > gateway > backendTLS > caCertificateRefs`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** ConfigMap refs holding the CA bundle for self-signed/internal upstreams

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_backendTLS_enabled"></a>3.16.2.2. Property `stack > global > gateway > backendTLS > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable upstream TLS

##### <a name="global_gateway_backendTLS_hostname"></a>3.16.2.3. Property `stack > global > gateway > backendTLS > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** SNI/validation hostname presented by the upstream (required when enabled)

##### <a name="global_gateway_backendTLS_wellKnownCACertificates"></a>3.16.2.4. Property `stack > global > gateway > backendTLS > wellKnownCACertificates`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Use the System trust store, or set "" and use caCertificateRefs for a private CA

#### <a name="global_gateway_basicAuth"></a>3.16.3. Property `stack > global > gateway > basicAuth`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP basic auth via a SecurityPolicy. Mutually exclusive with gateway.oidcProtected

| Property                                              | Pattern | Type    | Deprecated | Definition | Title/Description                             |
| ----------------------------------------------------- | ------- | ------- | ---------- | ---------- | --------------------------------------------- |
| - [enabled](#global_gateway_basicAuth_enabled )       | No      | boolean | No         | -          | Enable basic auth                             |
| - [secretName](#global_gateway_basicAuth_secretName ) | No      | string  | No         | -          | Name of an Opaque Secret with a .htpasswd key |

##### <a name="global_gateway_basicAuth_enabled"></a>3.16.3.1. Property `stack > global > gateway > basicAuth > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable basic auth

##### <a name="global_gateway_basicAuth_secretName"></a>3.16.3.2. Property `stack > global > gateway > basicAuth > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of an Opaque Secret with a .htpasswd key

#### <a name="global_gateway_cors"></a>3.16.4. Property `stack > global > gateway > cors`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CORS via a SecurityPolicy

| Property                                                     | Pattern | Type    | Deprecated | Definition | Title/Description                                    |
| ------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ---------------------------------------------------- |
| - [allowCredentials](#global_gateway_cors_allowCredentials ) | No      | boolean | No         | -          | Allow credentials                                    |
| - [allowHeaders](#global_gateway_cors_allowHeaders )         | No      | array   | No         | -          | Allowed request headers                              |
| - [allowMethods](#global_gateway_cors_allowMethods )         | No      | array   | No         | -          | Allowed methods                                      |
| - [allowOrigins](#global_gateway_cors_allowOrigins )         | No      | array   | No         | -          | Allowed origins (string patterns)                    |
| - [enabled](#global_gateway_cors_enabled )                   | No      | boolean | No         | -          | Enable CORS                                          |
| - [exposeHeaders](#global_gateway_cors_exposeHeaders )       | No      | array   | No         | -          | Response headers exposed to the browser              |
| - [maxAge](#global_gateway_cors_maxAge )                     | No      | string  | No         | -          | Preflight cache duration (e.g. "1h"), empty omits it |

##### <a name="global_gateway_cors_allowCredentials"></a>3.16.4.1. Property `stack > global > gateway > cors > allowCredentials`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Allow credentials

##### <a name="global_gateway_cors_allowHeaders"></a>3.16.4.2. Property `stack > global > gateway > cors > allowHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed request headers

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_cors_allowMethods"></a>3.16.4.3. Property `stack > global > gateway > cors > allowMethods`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed methods

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_cors_allowOrigins"></a>3.16.4.4. Property `stack > global > gateway > cors > allowOrigins`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed origins (string patterns)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_cors_enabled"></a>3.16.4.5. Property `stack > global > gateway > cors > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable CORS

##### <a name="global_gateway_cors_exposeHeaders"></a>3.16.4.6. Property `stack > global > gateway > cors > exposeHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Response headers exposed to the browser

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_cors_maxAge"></a>3.16.4.7. Property `stack > global > gateway > cors > maxAge`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Preflight cache duration (e.g. "1h"), empty omits it

#### <a name="global_gateway_enabled"></a>3.16.5. Property `stack > global > gateway > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable Gateway API HTTPRoute (alternative to Ingress)

#### <a name="global_gateway_gatewayName"></a>3.16.6. Property `stack > global > gateway > gatewayName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the Gateway resource to attach to

#### <a name="global_gateway_gatewayNamespace"></a>3.16.7. Property `stack > global > gateway > gatewayNamespace`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Namespace of the Gateway resource

#### <a name="global_gateway_host"></a>3.16.8. Property `stack > global > gateway > host`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Hostname for HTTPRoute

#### <a name="global_gateway_hostRewrite"></a>3.16.9. Property `stack > global > gateway > hostRewrite`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Rewrite the Host header sent upstream via an HTTPRoute URLRewrite filter, empty disables it

#### <a name="global_gateway_ipAllowList"></a>3.16.10. Property `stack > global > gateway > ipAllowList`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Client IP allowlist of CIDRs that renders a SecurityPolicy authorization rule (defaultAction Deny). Empty disables it

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="global_gateway_oidcProtected"></a>3.16.11. Property `stack > global > gateway > oidcProtected`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC protection via Envoy Gateway SecurityPolicy (requires oidcProxyGateway configuration)

#### <a name="global_gateway_paths"></a>3.16.12. Property `stack > global > gateway > paths`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of HTTPRoute paths

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be            | Description |
| ------------------------------------------ | ----------- |
| [paths items](#global_gateway_paths_items) | -           |

##### <a name="global_gateway_paths_items"></a>3.16.12.1. stack > global > gateway > paths > paths items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                            | Pattern | Type   | Deprecated | Definition | Title/Description                     |
| --------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------- |
| - [path](#global_gateway_paths_items_path )         | No      | string | No         | -          | HTTPRoute path                        |
| - [pathType](#global_gateway_paths_items_pathType ) | No      | string | No         | -          | HTTPRoute path type (Exact or Prefix) |

###### <a name="global_gateway_paths_items_path"></a>3.16.12.1.1. Property `stack > global > gateway > paths > paths items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** HTTPRoute path

###### <a name="global_gateway_paths_items_pathType"></a>3.16.12.1.2. Property `stack > global > gateway > paths > paths items > pathType`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** HTTPRoute path type (Exact or Prefix)

#### <a name="global_gateway_rateLimit"></a>3.16.13. Property `stack > global > gateway > rateLimit`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Local rate limit via a BackendTrafficPolicy (Envoy local token bucket, no burst concept)

| Property                                          | Pattern | Type    | Deprecated | Definition | Title/Description                           |
| ------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------- |
| - [enabled](#global_gateway_rateLimit_enabled )   | No      | boolean | No         | -          | Enable local rate limiting                  |
| - [requests](#global_gateway_rateLimit_requests ) | No      | integer | No         | -          | Allowed requests per unit                   |
| - [unit](#global_gateway_rateLimit_unit )         | No      | string  | No         | -          | Rate limit unit (Second, Minute, Hour, Day) |

##### <a name="global_gateway_rateLimit_enabled"></a>3.16.13.1. Property `stack > global > gateway > rateLimit > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable local rate limiting

##### <a name="global_gateway_rateLimit_requests"></a>3.16.13.2. Property `stack > global > gateway > rateLimit > requests`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Allowed requests per unit

##### <a name="global_gateway_rateLimit_unit"></a>3.16.13.3. Property `stack > global > gateway > rateLimit > unit`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Rate limit unit (Second, Minute, Hour, Day)

#### <a name="global_gateway_redirect"></a>3.16.14. Property `stack > global > gateway > redirect`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Whole-route redirect via an HTTPRoute RequestRedirect filter, replaces backend routing for the host

| Property                                             | Pattern | Type    | Deprecated | Definition | Title/Description                                               |
| ---------------------------------------------------- | ------- | ------- | ---------- | ---------- | --------------------------------------------------------------- |
| - [enabled](#global_gateway_redirect_enabled )       | No      | boolean | No         | -          | Enable a redirect-only route                                    |
| - [hostname](#global_gateway_redirect_hostname )     | No      | string  | No         | -          | Target hostname, empty keeps the request host                   |
| - [path](#global_gateway_redirect_path )             | No      | string  | No         | -          | Replacement full path via ReplaceFullPath, empty keeps the path |
| - [scheme](#global_gateway_redirect_scheme )         | No      | string  | No         | -          | Target scheme, e.g. https                                       |
| - [statusCode](#global_gateway_redirect_statusCode ) | No      | integer | No         | -          | Redirect status code (301 or 302)                               |

##### <a name="global_gateway_redirect_enabled"></a>3.16.14.1. Property `stack > global > gateway > redirect > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable a redirect-only route

##### <a name="global_gateway_redirect_hostname"></a>3.16.14.2. Property `stack > global > gateway > redirect > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Target hostname, empty keeps the request host

##### <a name="global_gateway_redirect_path"></a>3.16.14.3. Property `stack > global > gateway > redirect > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Replacement full path via ReplaceFullPath, empty keeps the path

##### <a name="global_gateway_redirect_scheme"></a>3.16.14.4. Property `stack > global > gateway > redirect > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Target scheme, e.g. https

##### <a name="global_gateway_redirect_statusCode"></a>3.16.14.5. Property `stack > global > gateway > redirect > statusCode`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Redirect status code (301 or 302)

#### <a name="global_gateway_requestHeaders"></a>3.16.15. Property `stack > global > gateway > requestHeaders`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Request header modifications (HTTPRoute RequestHeaderModifier filter)

| Property                                           | Pattern | Type  | Deprecated | Definition | Title/Description                    |
| -------------------------------------------------- | ------- | ----- | ---------- | ---------- | ------------------------------------ |
| - [add](#global_gateway_requestHeaders_add )       | No      | array | No         | -          | Headers to add, list of {name,value} |
| - [remove](#global_gateway_requestHeaders_remove ) | No      | array | No         | -          | Header names to remove               |
| - [set](#global_gateway_requestHeaders_set )       | No      | array | No         | -          | Headers to set, list of {name,value} |

##### <a name="global_gateway_requestHeaders_add"></a>3.16.15.1. Property `stack > global > gateway > requestHeaders > add`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to add, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_requestHeaders_remove"></a>3.16.15.2. Property `stack > global > gateway > requestHeaders > remove`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Header names to remove

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_requestHeaders_set"></a>3.16.15.3. Property `stack > global > gateway > requestHeaders > set`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to set, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="global_gateway_responseHeaders"></a>3.16.16. Property `stack > global > gateway > responseHeaders`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Response header modifications (HTTPRoute ResponseHeaderModifier filter)

| Property                                            | Pattern | Type  | Deprecated | Definition | Title/Description                    |
| --------------------------------------------------- | ------- | ----- | ---------- | ---------- | ------------------------------------ |
| - [add](#global_gateway_responseHeaders_add )       | No      | array | No         | -          | Headers to add, list of {name,value} |
| - [remove](#global_gateway_responseHeaders_remove ) | No      | array | No         | -          | Header names to remove               |
| - [set](#global_gateway_responseHeaders_set )       | No      | array | No         | -          | Headers to set, list of {name,value} |

##### <a name="global_gateway_responseHeaders_add"></a>3.16.16.1. Property `stack > global > gateway > responseHeaders > add`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to add, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_responseHeaders_remove"></a>3.16.16.2. Property `stack > global > gateway > responseHeaders > remove`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Header names to remove

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="global_gateway_responseHeaders_set"></a>3.16.16.3. Property `stack > global > gateway > responseHeaders > set`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to set, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="global_gateway_rules"></a>3.16.17. Property `stack > global > gateway > rules`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of additional HTTPRoute rules with custom hosts. Each entry takes host, optional paths, and an optional vanity block (enabled, hostname, clusterIssuer) that renders a per-host ListenerSet so the extra host can be a vanity domain, mirroring gateway.vanity

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="global_gateway_sectionName"></a>3.16.18. Property `stack > global > gateway > sectionName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional section name (listener name) on the Gateway

#### <a name="global_gateway_sessionAffinity"></a>3.16.19. Property `stack > global > gateway > sessionAffinity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Cookie-based sticky sessions via a BackendTrafficPolicy. Off by default (the ingress cookie-affinity default is not carried to the gateway)

| Property                                                    | Pattern | Type    | Deprecated | Definition | Title/Description                              |
| ----------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------------------------------- |
| - [cookieName](#global_gateway_sessionAffinity_cookieName ) | No      | string  | No         | -          | Affinity cookie name                           |
| - [enabled](#global_gateway_sessionAffinity_enabled )       | No      | boolean | No         | -          | Enable consistent-hash cookie session affinity |
| - [ttl](#global_gateway_sessionAffinity_ttl )               | No      | string  | No         | -          | Affinity cookie TTL                            |

##### <a name="global_gateway_sessionAffinity_cookieName"></a>3.16.19.1. Property `stack > global > gateway > sessionAffinity > cookieName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Affinity cookie name

##### <a name="global_gateway_sessionAffinity_enabled"></a>3.16.19.2. Property `stack > global > gateway > sessionAffinity > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable consistent-hash cookie session affinity

##### <a name="global_gateway_sessionAffinity_ttl"></a>3.16.19.3. Property `stack > global > gateway > sessionAffinity > ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Affinity cookie TTL

#### <a name="global_gateway_timeouts"></a>3.16.20. Property `stack > global > gateway > timeouts`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTPRoute timeouts. request maps to nginx proxy-read and send-timeout. connect (optional) renders a BackendTrafficPolicy

| Property                                                     | Pattern | Type   | Deprecated | Definition | Title/Description                                                                                                             |
| ------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------------------------------------------------------------------------------------------------------------------- |
| - [backendRequest](#global_gateway_timeouts_backendRequest ) | No      | string | No         | -          | Per-try backend request timeout (HTTPRoute rules[].timeouts.backendRequest). Must be <= request                               |
| - [connect](#global_gateway_timeouts_connect )               | No      | string | No         | -          | Optional upstream TCP connect timeout (renders BackendTrafficPolicy timeout.tcp.connectTimeout), empty uses the Envoy default |
| - [request](#global_gateway_timeouts_request )               | No      | string | No         | -          | Overall request timeout (HTTPRoute rules[].timeouts.request). Set "0s" to disable, e.g. for streaming or websockets           |

##### <a name="global_gateway_timeouts_backendRequest"></a>3.16.20.1. Property `stack > global > gateway > timeouts > backendRequest`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Per-try backend request timeout (HTTPRoute rules[].timeouts.backendRequest). Must be <= request

##### <a name="global_gateway_timeouts_connect"></a>3.16.20.2. Property `stack > global > gateway > timeouts > connect`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional upstream TCP connect timeout (renders BackendTrafficPolicy timeout.tcp.connectTimeout), empty uses the Envoy default

##### <a name="global_gateway_timeouts_request"></a>3.16.20.3. Property `stack > global > gateway > timeouts > request`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Overall request timeout (HTTPRoute rules[].timeouts.request). Set "0s" to disable, e.g. for streaming or websockets

#### <a name="global_gateway_tlsPassthrough"></a>3.16.21. Property `stack > global > gateway > tlsPassthrough`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** TLS passthrough via a TLSRoute (the Gateway does not terminate TLS). Mutually exclusive with the L7 gateway features, and requires a Passthrough listener on the shared Gateway

| Property                                                     | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                   |
| ------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------- |
| - [enabled](#global_gateway_tlsPassthrough_enabled )         | No      | boolean | No         | -          | Render a TLSRoute instead of an HTTPRoute and skip TLS termination for this service                                 |
| - [sectionName](#global_gateway_tlsPassthrough_sectionName ) | No      | string  | No         | -          | Optional Passthrough listener name to pin to. Empty attaches by hostname plus TLS protocol, which is the usual case |

##### <a name="global_gateway_tlsPassthrough_enabled"></a>3.16.21.1. Property `stack > global > gateway > tlsPassthrough > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Render a TLSRoute instead of an HTTPRoute and skip TLS termination for this service

##### <a name="global_gateway_tlsPassthrough_sectionName"></a>3.16.21.2. Property `stack > global > gateway > tlsPassthrough > sectionName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional Passthrough listener name to pin to. Empty attaches by hostname plus TLS protocol, which is the usual case

#### <a name="global_gateway_vanity"></a>3.16.22. Property `stack > global > gateway > vanity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Self-serve public/vanity-domain TLS via a tenant-owned Gateway API ListenerSet (requires Envoy Gateway >= v1.8 and cert-manager >= v1.20)

| Property                                                 | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                                                        |
| -------------------------------------------------------- | ------- | ------- | ---------- | ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [clusterIssuer](#global_gateway_vanity_clusterIssuer ) | No      | string  | No         | -          | cert-manager ClusterIssuer used by the gateway-shim to issue the listener certificate                                                                    |
| - [enabled](#global_gateway_vanity_enabled )             | No      | boolean | No         | -          | Render a ListenerSet attaching an HTTPS listener for this service's vanity domain to the shared Gateway                                                  |
| - [hostname](#global_gateway_vanity_hostname )           | No      | string  | No         | -          | Listener SNI hostname (defaults to gateway.host). A wildcard such as *.parent requires a dns01-capable issuer because http01 cannot issue wildcard certs |

##### <a name="global_gateway_vanity_clusterIssuer"></a>3.16.22.1. Property `stack > global > gateway > vanity > clusterIssuer`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** cert-manager ClusterIssuer used by the gateway-shim to issue the listener certificate

##### <a name="global_gateway_vanity_enabled"></a>3.16.22.2. Property `stack > global > gateway > vanity > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Render a ListenerSet attaching an HTTPS listener for this service's vanity domain to the shared Gateway

##### <a name="global_gateway_vanity_hostname"></a>3.16.22.3. Property `stack > global > gateway > vanity > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Listener SNI hostname (defaults to gateway.host). A wildcard such as *.parent requires a dns01-capable issuer because http01 cannot issue wildcard certs

### <a name="global_grafanaDashboard"></a>3.17. Property `stack > global > grafanaDashboard`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type            | Deprecated | Definition | Title/Description                                                  |
| ---------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ------------------------------------------------------------------ |
| - [datasources](#global_grafanaDashboard_datasources )           | No      | object          | No         | -          | -                                                                  |
| - [enabled](#global_grafanaDashboard_enabled )                   | No      | boolean         | No         | -          | Enable Grafana dashboard (globally, can be overridden per service) |
| - [extraPanels](#global_grafanaDashboard_extraPanels )           | No      | array of object | No         | -          | Extra panels to add to the Grafana dashboard                       |
| - [instanceSelector](#global_grafanaDashboard_instanceSelector ) | No      | object          | No         | -          | Instance selector for the Grafana dashboard                        |

#### <a name="global_grafanaDashboard_datasources"></a>3.17.1. Property `stack > global > grafanaDashboard > datasources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [prometheus](#global_grafanaDashboard_datasources_prometheus ) | No      | object | No         | -          | -                 |

##### <a name="global_grafanaDashboard_datasources_prometheus"></a>3.17.1.1. Property `stack > global > grafanaDashboard > datasources > prometheus`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                      | Pattern | Type   | Deprecated | Definition | Title/Description         |
| ------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------- |
| - [uid](#global_grafanaDashboard_datasources_prometheus_uid ) | No      | string | No         | -          | Prometheus datasource UID |

###### <a name="global_grafanaDashboard_datasources_prometheus_uid"></a>3.17.1.1.1. Property `stack > global > grafanaDashboard > datasources > prometheus > uid`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Prometheus datasource UID

#### <a name="global_grafanaDashboard_enabled"></a>3.17.2. Property `stack > global > grafanaDashboard > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable Grafana dashboard (globally, can be overridden per service)

#### <a name="global_grafanaDashboard_extraPanels"></a>3.17.3. Property `stack > global > grafanaDashboard > extraPanels`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Extra panels to add to the Grafana dashboard

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                 | Description |
| --------------------------------------------------------------- | ----------- |
| [extraPanels items](#global_grafanaDashboard_extraPanels_items) | -           |

##### <a name="global_grafanaDashboard_extraPanels_items"></a>3.17.3.1. stack > global > grafanaDashboard > extraPanels > extraPanels items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                     | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [datasource](#global_grafanaDashboard_extraPanels_items_datasource )       | No      | object | No         | -          | -                 |
| - [fieldConfig](#global_grafanaDashboard_extraPanels_items_fieldConfig )     | No      | object | No         | -          | -                 |
| - [gridPos](#global_grafanaDashboard_extraPanels_items_gridPos )             | No      | object | No         | -          | -                 |
| - [options](#global_grafanaDashboard_extraPanels_items_options )             | No      | object | No         | -          | -                 |
| - [pluginVersion](#global_grafanaDashboard_extraPanels_items_pluginVersion ) | No      | string | No         | -          | -                 |
| - [targets](#global_grafanaDashboard_extraPanels_items_targets )             | No      | array  | No         | -          | -                 |
| - [title](#global_grafanaDashboard_extraPanels_items_title )                 | No      | string | No         | -          | -                 |
| - [type](#global_grafanaDashboard_extraPanels_items_type )                   | No      | string | No         | -          | -                 |

###### <a name="global_grafanaDashboard_extraPanels_items_datasource"></a>3.17.3.1.1. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > datasource`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="global_grafanaDashboard_extraPanels_items_fieldConfig"></a>3.17.3.1.2. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > fieldConfig`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="global_grafanaDashboard_extraPanels_items_gridPos"></a>3.17.3.1.3. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > gridPos`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                     | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------- |
| - [h](#global_grafanaDashboard_extraPanels_items_gridPos_h ) | No      | number | No         | -          | -                 |
| - [w](#global_grafanaDashboard_extraPanels_items_gridPos_w ) | No      | number | No         | -          | -                 |

###### <a name="global_grafanaDashboard_extraPanels_items_gridPos_h"></a>3.17.3.1.3.1. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > gridPos > h`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="global_grafanaDashboard_extraPanels_items_gridPos_w"></a>3.17.3.1.3.2. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > gridPos > w`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="global_grafanaDashboard_extraPanels_items_options"></a>3.17.3.1.4. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > options`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="global_grafanaDashboard_extraPanels_items_pluginVersion"></a>3.17.3.1.5. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > pluginVersion`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_grafanaDashboard_extraPanels_items_targets"></a>3.17.3.1.6. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > targets`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="global_grafanaDashboard_extraPanels_items_title"></a>3.17.3.1.7. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > title`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_grafanaDashboard_extraPanels_items_type"></a>3.17.3.1.8. Property `stack > global > grafanaDashboard > extraPanels > extraPanels items > type`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_grafanaDashboard_instanceSelector"></a>3.17.4. Property `stack > global > grafanaDashboard > instanceSelector`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Instance selector for the Grafana dashboard

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [matchLabels](#global_grafanaDashboard_instanceSelector_matchLabels ) | No      | object | No         | -          | -                 |

##### <a name="global_grafanaDashboard_instanceSelector_matchLabels"></a>3.17.4.1. Property `stack > global > grafanaDashboard > instanceSelector > matchLabels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                              | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#global_grafanaDashboard_instanceSelector_matchLabels_name ) | No      | string | No         | -          | -                 |

###### <a name="global_grafanaDashboard_instanceSelector_matchLabels_name"></a>3.17.4.1.1. Property `stack > global > grafanaDashboard > instanceSelector > matchLabels > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

### <a name="global_image"></a>3.18. Property `stack > global > image`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                  | Pattern | Type             | Deprecated | Definition | Title/Description |
| ----------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [pullPolicy](#global_image_pullPolicy ) | No      | enum (of string) | No         | -          | Image pull policy |
| - [repository](#global_image_repository ) | No      | string           | No         | -          | Image repository  |
| - [tag](#global_image_tag )               | No      | string           | No         | -          | Image tag         |

#### <a name="global_image_pullPolicy"></a>3.18.1. Property `stack > global > image > pullPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** Image pull policy

Must be one of:
* "Always"
* "IfNotPresent"
* "Never"

#### <a name="global_image_repository"></a>3.18.2. Property `stack > global > image > repository`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image repository

#### <a name="global_image_tag"></a>3.18.3. Property `stack > global > image > tag`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image tag

### <a name="global_imagePullSecrets"></a>3.19. Property `stack > global > imagePullSecrets`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                          | Description |
| -------------------------------------------------------- | ----------- |
| [imagePullSecrets items](#global_imagePullSecrets_items) | -           |

#### <a name="global_imagePullSecrets_items"></a>3.19.1. stack > global > imagePullSecrets > imagePullSecrets items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

### <a name="global_ingress"></a>3.20. Property `stack > global > ingress`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Ingress configuration

| Property                                          | Pattern | Type            | Deprecated | Definition | Title/Description                                                 |
| ------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------- |
| - [annotations](#global_ingress_annotations )     | No      | object          | No         | -          | -                                                                 |
| - [className](#global_ingress_className )         | No      | string          | No         | -          | Ingress class name                                                |
| - [enabled](#global_ingress_enabled )             | No      | boolean         | No         | -          | Enable ingress                                                    |
| - [host](#global_ingress_host )                   | No      | string          | No         | -          | Ingress host                                                      |
| - [oidcProtected](#global_ingress_oidcProtected ) | No      | boolean         | No         | -          | Enable OIDC protection (route to oauth2-proxy when using Ingress) |
| - [paths](#global_ingress_paths )                 | No      | array of object | No         | -          | List of ingress paths                                             |
| - [rules](#global_ingress_rules )                 | No      | array           | No         | -          | List of ingress rules                                             |
| - [tls](#global_ingress_tls )                     | No      | array           | No         | -          | List of ingress TLS configurations                                |

#### <a name="global_ingress_annotations"></a>3.20.1. Property `stack > global > ingress > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                             | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------- |
| - [external-dns.alpha.kubernetes.io/ttl](#global_ingress_annotations_external-dnsalphakubernetesio/ttl )                             | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/affinity](#global_ingress_annotations_nginxingresskubernetesio/affinity )                             | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-connect-timeout](#global_ingress_annotations_nginxingresskubernetesio/proxy-connect-timeout )   | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-read-timeout](#global_ingress_annotations_nginxingresskubernetesio/proxy-read-timeout )         | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-send-timeout](#global_ingress_annotations_nginxingresskubernetesio/proxy-send-timeout )         | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/session-cookie-max-age](#global_ingress_annotations_nginxingresskubernetesio/session-cookie-max-age ) | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/session-cookie-name](#global_ingress_annotations_nginxingresskubernetesio/session-cookie-name )       | No      | string | No         | -          | -                 |

##### <a name="global_ingress_annotations_external-dnsalphakubernetesio/ttl"></a>3.20.1.1. Property `stack > global > ingress > annotations > external-dns.alpha.kubernetes.io/ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_ingress_annotations_nginxingresskubernetesio/affinity"></a>3.20.1.2. Property `stack > global > ingress > annotations > nginx.ingress.kubernetes.io/affinity`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_ingress_annotations_nginxingresskubernetesio/proxy-connect-timeout"></a>3.20.1.3. Property `stack > global > ingress > annotations > nginx.ingress.kubernetes.io/proxy-connect-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_ingress_annotations_nginxingresskubernetesio/proxy-read-timeout"></a>3.20.1.4. Property `stack > global > ingress > annotations > nginx.ingress.kubernetes.io/proxy-read-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_ingress_annotations_nginxingresskubernetesio/proxy-send-timeout"></a>3.20.1.5. Property `stack > global > ingress > annotations > nginx.ingress.kubernetes.io/proxy-send-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_ingress_annotations_nginxingresskubernetesio/session-cookie-max-age"></a>3.20.1.6. Property `stack > global > ingress > annotations > nginx.ingress.kubernetes.io/session-cookie-max-age`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="global_ingress_annotations_nginxingresskubernetesio/session-cookie-name"></a>3.20.1.7. Property `stack > global > ingress > annotations > nginx.ingress.kubernetes.io/session-cookie-name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_ingress_className"></a>3.20.2. Property `stack > global > ingress > className`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress class name

#### <a name="global_ingress_enabled"></a>3.20.3. Property `stack > global > ingress > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable ingress

#### <a name="global_ingress_host"></a>3.20.4. Property `stack > global > ingress > host`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress host

#### <a name="global_ingress_oidcProtected"></a>3.20.5. Property `stack > global > ingress > oidcProtected`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC protection (route to oauth2-proxy when using Ingress)

#### <a name="global_ingress_paths"></a>3.20.6. Property `stack > global > ingress > paths`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of ingress paths

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be            | Description |
| ------------------------------------------ | ----------- |
| [paths items](#global_ingress_paths_items) | -           |

##### <a name="global_ingress_paths_items"></a>3.20.6.1. stack > global > ingress > paths > paths items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [path](#global_ingress_paths_items_path )         | No      | string | No         | -          | Ingress path      |
| - [pathType](#global_ingress_paths_items_pathType ) | No      | string | No         | -          | Ingress path type |

###### <a name="global_ingress_paths_items_path"></a>3.20.6.1.1. Property `stack > global > ingress > paths > paths items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress path

###### <a name="global_ingress_paths_items_pathType"></a>3.20.6.1.2. Property `stack > global > ingress > paths > paths items > pathType`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress path type

#### <a name="global_ingress_rules"></a>3.20.7. Property `stack > global > ingress > rules`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of ingress rules

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="global_ingress_tls"></a>3.20.8. Property `stack > global > ingress > tls`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of ingress TLS configurations

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

### <a name="global_initContainers"></a>3.21. Property `stack > global > initContainers`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of init containers

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

### <a name="global_kedaAutoscaling"></a>3.22. Property `stack > global > kedaAutoscaling`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** KEDA autoscaling configuration (creates a ScaledObject instead of HPA)

| Property                                                      | Pattern | Type            | Deprecated | Definition | Title/Description                                                                         |
| ------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------------------------- |
| - [advanced](#global_kedaAutoscaling_advanced )               | No      | object          | No         | -          | Advanced KEDA ScaledObject configuration                                                  |
| - [cooldownPeriod](#global_kedaAutoscaling_cooldownPeriod )   | No      | integer         | No         | -          | Period in seconds to wait after the last trigger fires before scaling back to minReplicas |
| - [enabled](#global_kedaAutoscaling_enabled )                 | No      | boolean         | No         | -          | Enable KEDA autoscaling                                                                   |
| - [maxReplicas](#global_kedaAutoscaling_maxReplicas )         | No      | integer         | No         | -          | Maximum number of replicas                                                                |
| - [minReplicas](#global_kedaAutoscaling_minReplicas )         | No      | integer         | No         | -          | Minimum number of replicas                                                                |
| - [pollingInterval](#global_kedaAutoscaling_pollingInterval ) | No      | integer         | No         | -          | Interval in seconds to check each trigger                                                 |
| - [triggers](#global_kedaAutoscaling_triggers )               | No      | array of object | No         | -          | List of KEDA triggers (e.g. prometheus, cpu, memory, cron)                                |

#### <a name="global_kedaAutoscaling_advanced"></a>3.22.1. Property `stack > global > kedaAutoscaling > advanced`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Advanced KEDA ScaledObject configuration

#### <a name="global_kedaAutoscaling_cooldownPeriod"></a>3.22.2. Property `stack > global > kedaAutoscaling > cooldownPeriod`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Period in seconds to wait after the last trigger fires before scaling back to minReplicas

#### <a name="global_kedaAutoscaling_enabled"></a>3.22.3. Property `stack > global > kedaAutoscaling > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable KEDA autoscaling

#### <a name="global_kedaAutoscaling_maxReplicas"></a>3.22.4. Property `stack > global > kedaAutoscaling > maxReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Maximum number of replicas

#### <a name="global_kedaAutoscaling_minReplicas"></a>3.22.5. Property `stack > global > kedaAutoscaling > minReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Minimum number of replicas

#### <a name="global_kedaAutoscaling_pollingInterval"></a>3.22.6. Property `stack > global > kedaAutoscaling > pollingInterval`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Interval in seconds to check each trigger

#### <a name="global_kedaAutoscaling_triggers"></a>3.22.7. Property `stack > global > kedaAutoscaling > triggers`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of KEDA triggers (e.g. prometheus, cpu, memory, cron)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                          | Description |
| -------------------------------------------------------- | ----------- |
| [triggers items](#global_kedaAutoscaling_triggers_items) | -           |

##### <a name="global_kedaAutoscaling_triggers_items"></a>3.22.7.1. stack > global > kedaAutoscaling > triggers > triggers items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

### <a name="global_livenessProbe"></a>3.23. Property `stack > global > livenessProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Liveness probe configuration

| Property                                                            | Pattern | Type   | Deprecated | Definition | Title/Description                                                                     |
| ------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [failureThreshold](#global_livenessProbe_failureThreshold )       | No      | number | No         | -          | Number of failures before the probe is considered failed                              |
| - [httpGet](#global_livenessProbe_httpGet )                         | No      | object | No         | -          | HTTP probe configuration (exec & tcpSocket are also available)                        |
| - [initialDelaySeconds](#global_livenessProbe_initialDelaySeconds ) | No      | number | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#global_livenessProbe_periodSeconds )             | No      | number | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#global_livenessProbe_successThreshold )       | No      | number | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#global_livenessProbe_timeoutSeconds )           | No      | number | No         | -          | Timeout for the probe                                                                 |

#### <a name="global_livenessProbe_failureThreshold"></a>3.23.1. Property `stack > global > livenessProbe > failureThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of failures before the probe is considered failed

#### <a name="global_livenessProbe_httpGet"></a>3.23.2. Property `stack > global > livenessProbe > httpGet`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP probe configuration (exec & tcpSocket are also available)

| Property                                          | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [path](#global_livenessProbe_httpGet_path )     | No      | string      | No         | -          | Path to probe     |
| - [port](#global_livenessProbe_httpGet_port )     | No      | Combination | No         | -          | Port to probe     |
| - [scheme](#global_livenessProbe_httpGet_scheme ) | No      | string      | No         | -          | Scheme to use     |

##### <a name="global_livenessProbe_httpGet_path"></a>3.23.2.1. Property `stack > global > livenessProbe > httpGet > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path to probe

##### <a name="global_livenessProbe_httpGet_port"></a>3.23.2.2. Property `stack > global > livenessProbe > httpGet > port`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Port to probe

| One of(Option)                                        |
| ----------------------------------------------------- |
| [item 0](#global_livenessProbe_httpGet_port_oneOf_i0) |
| [item 1](#global_livenessProbe_httpGet_port_oneOf_i1) |

###### <a name="global_livenessProbe_httpGet_port_oneOf_i0"></a>3.23.2.2.1. Property `stack > global > livenessProbe > httpGet > port > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_livenessProbe_httpGet_port_oneOf_i1"></a>3.23.2.2.2. Property `stack > global > livenessProbe > httpGet > port > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

##### <a name="global_livenessProbe_httpGet_scheme"></a>3.23.2.3. Property `stack > global > livenessProbe > httpGet > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Scheme to use

#### <a name="global_livenessProbe_initialDelaySeconds"></a>3.23.3. Property `stack > global > livenessProbe > initialDelaySeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of seconds after the container has started before the probe is first initiated

#### <a name="global_livenessProbe_periodSeconds"></a>3.23.4. Property `stack > global > livenessProbe > periodSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** How often to perform the probe

#### <a name="global_livenessProbe_successThreshold"></a>3.23.5. Property `stack > global > livenessProbe > successThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of successes before the probe is considered successful

#### <a name="global_livenessProbe_timeoutSeconds"></a>3.23.6. Property `stack > global > livenessProbe > timeoutSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Timeout for the probe

### <a name="global_nameOverride"></a>3.24. Property `stack > global > nameOverride`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name to prefix the K8s resources with, combined with the stack name prefix

### <a name="global_nodeSelector"></a>3.25. Property `stack > global > nodeSelector`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                        | Pattern | Type   | Deprecated | Definition | Title/Description              |
| --------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------ |
| - [kubernetes.io/arch](#global_nodeSelector_kubernetesio/arch ) | No      | string | No         | -          | Node selector for architecture |

#### <a name="global_nodeSelector_kubernetesio/arch"></a>3.25.1. Property `stack > global > nodeSelector > kubernetes.io/arch`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Node selector for architecture

### <a name="global_oidcProxy"></a>3.26. Property `stack > global > oidcProxy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                    | Pattern | Type            | Deprecated | Definition | Title/Description                            |
| ----------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | -------------------------------------------- |
| - [additionalHeaders](#global_oidcProxy_additionalHeaders ) | No      | array           | No         | -          | Additional headers to add                    |
| - [additionalSecrets](#global_oidcProxy_additionalSecrets ) | No      | array           | No         | -          | Additional secrets to mount                  |
| - [annotations](#global_oidcProxy_annotations )             | No      | object          | No         | -          | Annotations to add to the OIDC proxy         |
| - [cookieRefresh](#global_oidcProxy_cookieRefresh )         | No      | string          | No         | -          | Refresh tokens and cookies after this period |
| - [enabled](#global_oidcProxy_enabled )                     | No      | boolean         | No         | -          | Enable OIDC proxy                            |
| - [extraArgs](#global_oidcProxy_extraArgs )                 | No      | array of string | No         | -          | Extra arguments to pass to the OIDC proxy    |
| - [image](#global_oidcProxy_image )                         | No      | object          | No         | -          | -                                            |
| - [replicaCount](#global_oidcProxy_replicaCount )           | No      | integer         | No         | -          | Number of replicas                           |
| - [resources](#global_oidcProxy_resources )                 | No      | object          | No         | -          | -                                            |
| - [skipAuth](#global_oidcProxy_skipAuth )                   | No      | array of object | No         | -          | Paths to skip authentication                 |
| - [volumeMounts](#global_oidcProxy_volumeMounts )           | No      | array           | No         | -          | Volume mounts for the OIDC proxy             |

#### <a name="global_oidcProxy_additionalHeaders"></a>3.26.1. Property `stack > global > oidcProxy > additionalHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional headers to add

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="global_oidcProxy_additionalSecrets"></a>3.26.2. Property `stack > global > oidcProxy > additionalSecrets`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional secrets to mount

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="global_oidcProxy_annotations"></a>3.26.3. Property `stack > global > oidcProxy > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to the OIDC proxy

#### <a name="global_oidcProxy_cookieRefresh"></a>3.26.4. Property `stack > global > oidcProxy > cookieRefresh`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Refresh tokens and cookies after this period

#### <a name="global_oidcProxy_enabled"></a>3.26.5. Property `stack > global > oidcProxy > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC proxy

#### <a name="global_oidcProxy_extraArgs"></a>3.26.6. Property `stack > global > oidcProxy > extraArgs`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Extra arguments to pass to the OIDC proxy

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                      | Description |
| ---------------------------------------------------- | ----------- |
| [extraArgs items](#global_oidcProxy_extraArgs_items) | -           |

##### <a name="global_oidcProxy_extraArgs_items"></a>3.26.6.1. stack > global > oidcProxy > extraArgs > extraArgs items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_oidcProxy_image"></a>3.26.7. Property `stack > global > oidcProxy > image`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [repository](#global_oidcProxy_image_repository ) | No      | string | No         | -          | Image repository  |
| - [tag](#global_oidcProxy_image_tag )               | No      | string | No         | -          | Image tag         |

##### <a name="global_oidcProxy_image_repository"></a>3.26.7.1. Property `stack > global > oidcProxy > image > repository`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image repository

##### <a name="global_oidcProxy_image_tag"></a>3.26.7.2. Property `stack > global > oidcProxy > image > tag`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image tag

#### <a name="global_oidcProxy_replicaCount"></a>3.26.8. Property `stack > global > oidcProxy > replicaCount`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of replicas

#### <a name="global_oidcProxy_resources"></a>3.26.9. Property `stack > global > oidcProxy > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [limits](#global_oidcProxy_resources_limits )     | No      | object | No         | -          | -                 |
| - [requests](#global_oidcProxy_resources_requests ) | No      | object | No         | -          | -                 |

##### <a name="global_oidcProxy_resources_limits"></a>3.26.9.1. Property `stack > global > oidcProxy > resources > limits`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                               | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------ | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#global_oidcProxy_resources_limits_cpu )       | No      | Combination | No         | -          | CPU limit         |
| - [memory](#global_oidcProxy_resources_limits_memory ) | No      | string      | No         | -          | Memory limit      |

###### <a name="global_oidcProxy_resources_limits_cpu"></a>3.26.9.1.1. Property `stack > global > oidcProxy > resources > limits > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU limit

| One of(Option)                                            |
| --------------------------------------------------------- |
| [item 0](#global_oidcProxy_resources_limits_cpu_oneOf_i0) |
| [item 1](#global_oidcProxy_resources_limits_cpu_oneOf_i1) |

###### <a name="global_oidcProxy_resources_limits_cpu_oneOf_i0"></a>3.26.9.1.1.1. Property `stack > global > oidcProxy > resources > limits > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_oidcProxy_resources_limits_cpu_oneOf_i1"></a>3.26.9.1.1.2. Property `stack > global > oidcProxy > resources > limits > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="global_oidcProxy_resources_limits_memory"></a>3.26.9.1.2. Property `stack > global > oidcProxy > resources > limits > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory limit

##### <a name="global_oidcProxy_resources_requests"></a>3.26.9.2. Property `stack > global > oidcProxy > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                 | Pattern | Type        | Deprecated | Definition | Title/Description |
| -------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#global_oidcProxy_resources_requests_cpu )       | No      | Combination | No         | -          | CPU request       |
| - [memory](#global_oidcProxy_resources_requests_memory ) | No      | string      | No         | -          | Memory request    |

###### <a name="global_oidcProxy_resources_requests_cpu"></a>3.26.9.2.1. Property `stack > global > oidcProxy > resources > requests > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU request

| One of(Option)                                              |
| ----------------------------------------------------------- |
| [item 0](#global_oidcProxy_resources_requests_cpu_oneOf_i0) |
| [item 1](#global_oidcProxy_resources_requests_cpu_oneOf_i1) |

###### <a name="global_oidcProxy_resources_requests_cpu_oneOf_i0"></a>3.26.9.2.1.1. Property `stack > global > oidcProxy > resources > requests > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_oidcProxy_resources_requests_cpu_oneOf_i1"></a>3.26.9.2.1.2. Property `stack > global > oidcProxy > resources > requests > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="global_oidcProxy_resources_requests_memory"></a>3.26.9.2.2. Property `stack > global > oidcProxy > resources > requests > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory request

#### <a name="global_oidcProxy_skipAuth"></a>3.26.10. Property `stack > global > oidcProxy > skipAuth`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Paths to skip authentication

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                    | Description |
| -------------------------------------------------- | ----------- |
| [skipAuth items](#global_oidcProxy_skipAuth_items) | -           |

##### <a name="global_oidcProxy_skipAuth_items"></a>3.26.10.1. stack > global > oidcProxy > skipAuth > skipAuth items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                             | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [method](#global_oidcProxy_skipAuth_items_method ) | No      | string | No         | -          | -                 |
| - [path](#global_oidcProxy_skipAuth_items_path )     | No      | string | No         | -          | -                 |

###### <a name="global_oidcProxy_skipAuth_items_method"></a>3.26.10.1.1. Property `stack > global > oidcProxy > skipAuth > skipAuth items > method`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_oidcProxy_skipAuth_items_path"></a>3.26.10.1.2. Property `stack > global > oidcProxy > skipAuth > skipAuth items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_oidcProxy_volumeMounts"></a>3.26.11. Property `stack > global > oidcProxy > volumeMounts`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Volume mounts for the OIDC proxy

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

### <a name="global_oidcProxyGateway"></a>3.27. Property `stack > global > oidcProxyGateway`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Native Envoy Gateway OIDC authentication configuration (used when gateway.oidcProtected is true). Requires explicit clientID and issuer configuration. clientSecret is auto-referenced from appSecrets. redirectURL is auto-generated as https://<gateway.host>/oauth2/callback.

| Property                                                             | Pattern | Type            | Deprecated | Definition | Title/Description                                                                      |
| -------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | -------------------------------------------------------------------------------------- |
| - [annotations](#global_oidcProxyGateway_annotations )               | No      | object          | No         | -          | Annotations to add to SecurityPolicy resources                                         |
| - [clientID](#global_oidcProxyGateway_clientID )                     | No      | string          | No         | -          | OIDC client ID (required when gateway.oidcProtected is enabled)                        |
| - [cookieDomain](#global_oidcProxyGateway_cookieDomain )             | No      | string          | No         | -          | Optional root domain for sharing tokens across subdomains (e.g., cluster.dev.czi.team) |
| - [cookieNames](#global_oidcProxyGateway_cookieNames )               | No      | object          | No         | -          | Customize cookie names                                                                 |
| - [forwardAccessToken](#global_oidcProxyGateway_forwardAccessToken ) | No      | boolean         | No         | -          | Forward access token to backend service                                                |
| - [logoutPath](#global_oidcProxyGateway_logoutPath )                 | No      | string          | No         | -          | Path for logout operations                                                             |
| - [provider](#global_oidcProxyGateway_provider )                     | No      | object          | No         | -          | OIDC provider configuration                                                            |
| - [refreshToken](#global_oidcProxyGateway_refreshToken )             | No      | boolean         | No         | -          | Use refresh tokens to refresh access tokens (default true in Envoy Gateway v1.6.0+)    |
| - [resources](#global_oidcProxyGateway_resources )                   | No      | array           | No         | -          | Optional OAuth2 resources parameter                                                    |
| - [scopes](#global_oidcProxyGateway_scopes )                         | No      | array of string | No         | -          | OIDC scopes to request                                                                 |
| - [skipAuth](#global_oidcProxyGateway_skipAuth )                     | No      | array of object | No         | -          | Paths to skip authentication (creates separate public HTTPRoute)                       |

#### <a name="global_oidcProxyGateway_annotations"></a>3.27.1. Property `stack > global > oidcProxyGateway > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to SecurityPolicy resources

#### <a name="global_oidcProxyGateway_clientID"></a>3.27.2. Property `stack > global > oidcProxyGateway > clientID`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** OIDC client ID (required when gateway.oidcProtected is enabled)

#### <a name="global_oidcProxyGateway_cookieDomain"></a>3.27.3. Property `stack > global > oidcProxyGateway > cookieDomain`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional root domain for sharing tokens across subdomains (e.g., cluster.dev.czi.team)

#### <a name="global_oidcProxyGateway_cookieNames"></a>3.27.4. Property `stack > global > oidcProxyGateway > cookieNames`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Customize cookie names

| Property                                                           | Pattern | Type   | Deprecated | Definition | Title/Description                   |
| ------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------------------------- |
| - [accessToken](#global_oidcProxyGateway_cookieNames_accessToken ) | No      | string | No         | -          | Custom name for access token cookie |
| - [idToken](#global_oidcProxyGateway_cookieNames_idToken )         | No      | string | No         | -          | Custom name for ID token cookie     |

##### <a name="global_oidcProxyGateway_cookieNames_accessToken"></a>3.27.4.1. Property `stack > global > oidcProxyGateway > cookieNames > accessToken`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom name for access token cookie

##### <a name="global_oidcProxyGateway_cookieNames_idToken"></a>3.27.4.2. Property `stack > global > oidcProxyGateway > cookieNames > idToken`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom name for ID token cookie

#### <a name="global_oidcProxyGateway_forwardAccessToken"></a>3.27.5. Property `stack > global > oidcProxyGateway > forwardAccessToken`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Forward access token to backend service

#### <a name="global_oidcProxyGateway_logoutPath"></a>3.27.6. Property `stack > global > oidcProxyGateway > logoutPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path for logout operations

#### <a name="global_oidcProxyGateway_provider"></a>3.27.7. Property `stack > global > oidcProxyGateway > provider`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** OIDC provider configuration

| Property                                                                            | Pattern | Type   | Deprecated | Definition | Title/Description                                                         |
| ----------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [authorizationEndpoint](#global_oidcProxyGateway_provider_authorizationEndpoint ) | No      | string | No         | -          | Optional authorization endpoint (auto-discovered by provider if empty)    |
| - [issuer](#global_oidcProxyGateway_provider_issuer )                               | No      | string | No         | -          | OIDC provider issuer URL (required when gateway.oidcProtected is enabled) |
| - [tokenEndpoint](#global_oidcProxyGateway_provider_tokenEndpoint )                 | No      | string | No         | -          | Optional token endpoint (auto-discovered by provider if empty)            |

##### <a name="global_oidcProxyGateway_provider_authorizationEndpoint"></a>3.27.7.1. Property `stack > global > oidcProxyGateway > provider > authorizationEndpoint`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional authorization endpoint (auto-discovered by provider if empty)

##### <a name="global_oidcProxyGateway_provider_issuer"></a>3.27.7.2. Property `stack > global > oidcProxyGateway > provider > issuer`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** OIDC provider issuer URL (required when gateway.oidcProtected is enabled)

##### <a name="global_oidcProxyGateway_provider_tokenEndpoint"></a>3.27.7.3. Property `stack > global > oidcProxyGateway > provider > tokenEndpoint`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional token endpoint (auto-discovered by provider if empty)

#### <a name="global_oidcProxyGateway_refreshToken"></a>3.27.8. Property `stack > global > oidcProxyGateway > refreshToken`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Use refresh tokens to refresh access tokens (default true in Envoy Gateway v1.6.0+)

#### <a name="global_oidcProxyGateway_resources"></a>3.27.9. Property `stack > global > oidcProxyGateway > resources`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Optional OAuth2 resources parameter

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="global_oidcProxyGateway_scopes"></a>3.27.10. Property `stack > global > oidcProxyGateway > scopes`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** OIDC scopes to request

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                       | Description |
| ----------------------------------------------------- | ----------- |
| [scopes items](#global_oidcProxyGateway_scopes_items) | -           |

##### <a name="global_oidcProxyGateway_scopes_items"></a>3.27.10.1. stack > global > oidcProxyGateway > scopes > scopes items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_oidcProxyGateway_skipAuth"></a>3.27.11. Property `stack > global > oidcProxyGateway > skipAuth`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Paths to skip authentication (creates separate public HTTPRoute)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                           | Description |
| --------------------------------------------------------- | ----------- |
| [skipAuth items](#global_oidcProxyGateway_skipAuth_items) | -           |

##### <a name="global_oidcProxyGateway_skipAuth_items"></a>3.27.11.1. stack > global > oidcProxyGateway > skipAuth > skipAuth items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                    | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [method](#global_oidcProxyGateway_skipAuth_items_method ) | No      | string | No         | -          | -                 |
| - [path](#global_oidcProxyGateway_skipAuth_items_path )     | No      | string | No         | -          | -                 |

###### <a name="global_oidcProxyGateway_skipAuth_items_method"></a>3.27.11.1.1. Property `stack > global > oidcProxyGateway > skipAuth > skipAuth items > method`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_oidcProxyGateway_skipAuth_items_path"></a>3.27.11.1.2. Property `stack > global > oidcProxyGateway > skipAuth > skipAuth items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

### <a name="global_persistence"></a>3.28. Property `stack > global > persistence`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                              | Pattern | Type    | Deprecated | Definition | Title/Description      |
| ----------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------- |
| - [enabled](#global_persistence_enabled )             | No      | boolean | No         | -          | Enable persistence     |
| - [existingClaim](#global_persistence_existingClaim ) | No      | string  | No         | -          | Existing PVC name      |
| - [mountPath](#global_persistence_mountPath )         | No      | string  | No         | -          | Mount path for the PVC |
| - [pvc](#global_persistence_pvc )                     | No      | object  | No         | -          | -                      |

#### <a name="global_persistence_enabled"></a>3.28.1. Property `stack > global > persistence > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable persistence

#### <a name="global_persistence_existingClaim"></a>3.28.2. Property `stack > global > persistence > existingClaim`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Existing PVC name

#### <a name="global_persistence_mountPath"></a>3.28.3. Property `stack > global > persistence > mountPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Mount path for the PVC

#### <a name="global_persistence_pvc"></a>3.28.4. Property `stack > global > persistence > pvc`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                        | Pattern | Type                      | Deprecated | Definition | Title/Description        |
| --------------------------------------------------------------- | ------- | ------------------------- | ---------- | ---------- | ------------------------ |
| - [accessModes](#global_persistence_pvc_accessModes )           | No      | array of enum (of string) | No         | -          | Access modes for the PVC |
| - [dataSource](#global_persistence_pvc_dataSource )             | No      | object                    | No         | -          | -                        |
| - [resources](#global_persistence_pvc_resources )               | No      | object                    | No         | -          | -                        |
| - [storageClassName](#global_persistence_pvc_storageClassName ) | No      | string                    | No         | -          | Storage class name       |

##### <a name="global_persistence_pvc_accessModes"></a>3.28.4.1. Property `stack > global > persistence > pvc > accessModes`

|              |                             |
| ------------ | --------------------------- |
| **Type**     | `array of enum (of string)` |
| **Required** | No                          |

**Description:** Access modes for the PVC

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                | Description |
| -------------------------------------------------------------- | ----------- |
| [accessModes items](#global_persistence_pvc_accessModes_items) | -           |

###### <a name="global_persistence_pvc_accessModes_items"></a>3.28.4.1.1. stack > global > persistence > pvc > accessModes > accessModes items

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "ReadWriteOnce"
* "ReadOnlyMany"
* "ReadWriteMany"
* "ReadWriteOncePod"

##### <a name="global_persistence_pvc_dataSource"></a>3.28.4.2. Property `stack > global > persistence > pvc > dataSource`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                   | Pattern | Type   | Deprecated | Definition | Title/Description                                               |
| ---------------------------------------------------------- | ------- | ------ | ---------- | ---------- | --------------------------------------------------------------- |
| - [apiGroup](#global_persistence_pvc_dataSource_apiGroup ) | No      | string | No         | -          | API version of the data source                                  |
| - [kind](#global_persistence_pvc_dataSource_kind )         | No      | string | No         | -          | Kind of the data source [VolumeSnapshot, PersistentVolumeClaim] |
| - [name](#global_persistence_pvc_dataSource_name )         | No      | string | No         | -          | Name of the data source                                         |

###### <a name="global_persistence_pvc_dataSource_apiGroup"></a>3.28.4.2.1. Property `stack > global > persistence > pvc > dataSource > apiGroup`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** API version of the data source

###### <a name="global_persistence_pvc_dataSource_kind"></a>3.28.4.2.2. Property `stack > global > persistence > pvc > dataSource > kind`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Kind of the data source [VolumeSnapshot, PersistentVolumeClaim]

###### <a name="global_persistence_pvc_dataSource_name"></a>3.28.4.2.3. Property `stack > global > persistence > pvc > dataSource > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the data source

##### <a name="global_persistence_pvc_resources"></a>3.28.4.3. Property `stack > global > persistence > pvc > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                  | Pattern | Type   | Deprecated | Definition | Title/Description     |
| --------------------------------------------------------- | ------- | ------ | ---------- | ---------- | --------------------- |
| - [requests](#global_persistence_pvc_resources_requests ) | No      | object | No         | -          | PVC resource requests |

###### <a name="global_persistence_pvc_resources_requests"></a>3.28.4.3.1. Property `stack > global > persistence > pvc > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** PVC resource requests

| Property                                                         | Pattern | Type   | Deprecated | Definition | Title/Description        |
| ---------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------ |
| - [storage](#global_persistence_pvc_resources_requests_storage ) | No      | string | No         | -          | Storage resource request |

###### <a name="global_persistence_pvc_resources_requests_storage"></a>3.28.4.3.1.1. Property `stack > global > persistence > pvc > resources > requests > storage`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage resource request

##### <a name="global_persistence_pvc_storageClassName"></a>3.28.4.4. Property `stack > global > persistence > pvc > storageClassName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage class name

### <a name="global_podAnnotations"></a>3.29. Property `stack > global > podAnnotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to pods

### <a name="global_podLabels"></a>3.30. Property `stack > global > podLabels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global labels to add to all pods

### <a name="global_podSecurityContext"></a>3.31. Property `stack > global > podSecurityContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Pod security context

### <a name="global_progressDeadlineSeconds"></a>3.32. Property `stack > global > progressDeadlineSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** the number of seconds the Deployment controller waits before indicating (in the Deployment status) that the Deployment progress has stalled

### <a name="global_readinessProbe"></a>3.33. Property `stack > global > readinessProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Readiness probe configuration

| Property                                                             | Pattern | Type   | Deprecated | Definition | Title/Description                                                                     |
| -------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [failureThreshold](#global_readinessProbe_failureThreshold )       | No      | number | No         | -          | Number of failures before the probe is considered failed                              |
| - [httpGet](#global_readinessProbe_httpGet )                         | No      | object | No         | -          | HTTP probe configuration (exec & tcpSocket are also available)                        |
| - [initialDelaySeconds](#global_readinessProbe_initialDelaySeconds ) | No      | number | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#global_readinessProbe_periodSeconds )             | No      | number | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#global_readinessProbe_successThreshold )       | No      | number | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#global_readinessProbe_timeoutSeconds )           | No      | number | No         | -          | Timeout for the probe                                                                 |

#### <a name="global_readinessProbe_failureThreshold"></a>3.33.1. Property `stack > global > readinessProbe > failureThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of failures before the probe is considered failed

#### <a name="global_readinessProbe_httpGet"></a>3.33.2. Property `stack > global > readinessProbe > httpGet`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP probe configuration (exec & tcpSocket are also available)

| Property                                           | Pattern | Type        | Deprecated | Definition | Title/Description |
| -------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [path](#global_readinessProbe_httpGet_path )     | No      | string      | No         | -          | Path to probe     |
| - [port](#global_readinessProbe_httpGet_port )     | No      | Combination | No         | -          | Port to probe     |
| - [scheme](#global_readinessProbe_httpGet_scheme ) | No      | string      | No         | -          | Scheme to use     |

##### <a name="global_readinessProbe_httpGet_path"></a>3.33.2.1. Property `stack > global > readinessProbe > httpGet > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path to probe

##### <a name="global_readinessProbe_httpGet_port"></a>3.33.2.2. Property `stack > global > readinessProbe > httpGet > port`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Port to probe

| One of(Option)                                         |
| ------------------------------------------------------ |
| [item 0](#global_readinessProbe_httpGet_port_oneOf_i0) |
| [item 1](#global_readinessProbe_httpGet_port_oneOf_i1) |

###### <a name="global_readinessProbe_httpGet_port_oneOf_i0"></a>3.33.2.2.1. Property `stack > global > readinessProbe > httpGet > port > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_readinessProbe_httpGet_port_oneOf_i1"></a>3.33.2.2.2. Property `stack > global > readinessProbe > httpGet > port > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

##### <a name="global_readinessProbe_httpGet_scheme"></a>3.33.2.3. Property `stack > global > readinessProbe > httpGet > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Scheme to use

#### <a name="global_readinessProbe_initialDelaySeconds"></a>3.33.3. Property `stack > global > readinessProbe > initialDelaySeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of seconds after the container has started before the probe is first initiated

#### <a name="global_readinessProbe_periodSeconds"></a>3.33.4. Property `stack > global > readinessProbe > periodSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** How often to perform the probe

#### <a name="global_readinessProbe_successThreshold"></a>3.33.5. Property `stack > global > readinessProbe > successThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of successes before the probe is considered successful

#### <a name="global_readinessProbe_timeoutSeconds"></a>3.33.6. Property `stack > global > readinessProbe > timeoutSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Timeout for the probe

### <a name="global_replicaCount"></a>3.34. Property `stack > global > replicaCount`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of replicas

### <a name="global_resources"></a>3.35. Property `stack > global > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource requests and limits for the primary container

| Property                                  | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [limits](#global_resources_limits )     | No      | object | No         | -          | Resource limits   |
| - [requests](#global_resources_requests ) | No      | object | No         | -          | Resource requests |

#### <a name="global_resources_limits"></a>3.35.1. Property `stack > global > resources > limits`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource limits

| Property                                     | Pattern | Type        | Deprecated | Definition | Title/Description |
| -------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#global_resources_limits_cpu )       | No      | Combination | No         | -          | CPU limit         |
| - [memory](#global_resources_limits_memory ) | No      | string      | No         | -          | Memory limit      |

##### <a name="global_resources_limits_cpu"></a>3.35.1.1. Property `stack > global > resources > limits > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU limit

| One of(Option)                                  |
| ----------------------------------------------- |
| [item 0](#global_resources_limits_cpu_oneOf_i0) |
| [item 1](#global_resources_limits_cpu_oneOf_i1) |

###### <a name="global_resources_limits_cpu_oneOf_i0"></a>3.35.1.1.1. Property `stack > global > resources > limits > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_resources_limits_cpu_oneOf_i1"></a>3.35.1.1.2. Property `stack > global > resources > limits > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

##### <a name="global_resources_limits_memory"></a>3.35.1.2. Property `stack > global > resources > limits > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory limit

#### <a name="global_resources_requests"></a>3.35.2. Property `stack > global > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource requests

| Property                                       | Pattern | Type        | Deprecated | Definition | Title/Description |
| ---------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#global_resources_requests_cpu )       | No      | Combination | No         | -          | CPU request       |
| - [memory](#global_resources_requests_memory ) | No      | string      | No         | -          | Memory request    |

##### <a name="global_resources_requests_cpu"></a>3.35.2.1. Property `stack > global > resources > requests > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU request

| One of(Option)                                    |
| ------------------------------------------------- |
| [item 0](#global_resources_requests_cpu_oneOf_i0) |
| [item 1](#global_resources_requests_cpu_oneOf_i1) |

###### <a name="global_resources_requests_cpu_oneOf_i0"></a>3.35.2.1.1. Property `stack > global > resources > requests > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="global_resources_requests_cpu_oneOf_i1"></a>3.35.2.1.2. Property `stack > global > resources > requests > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

##### <a name="global_resources_requests_memory"></a>3.35.2.2. Property `stack > global > resources > requests > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory request

### <a name="global_restartPolicy"></a>3.36. Property `stack > global > restartPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** Restart policy for the pod

Must be one of:
* "Always"
* "OnFailure"
* "Never"

### <a name="global_rollout"></a>3.37. Property `stack > global > rollout`

|                           |                      |
| ------------------------- | -------------------- |
| **Type**                  | `object`             |
| **Required**              | No                   |
| **Additional properties** | Any type allowed     |
| **Defined in**            | #/properties/rollout |

| Property                                               | Pattern | Type   | Deprecated | Definition | Title/Description                                   |
| ------------------------------------------------------ | ------- | ------ | ---------- | ---------- | --------------------------------------------------- |
| - [strategy](#cronJobs_pattern1_rollout_strategy )     | No      | object | No         | -          | Specifies the rollout strategy for the application. |
| - [](#cronJobs_pattern1_rollout_additionalProperties ) | No      | object | No         | -          | -                                                   |

#### <a name="cronJobs_pattern1_rollout_strategy"></a>3.37.1. Property `stack > cronJobs > ^.*$ > rollout > strategy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

**Description:** Specifies the rollout strategy for the application.

| Property                                                      | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [blueGreen](#cronJobs_pattern1_rollout_strategy_blueGreen ) | No      | object | No         | -          | -                 |

##### <a name="cronJobs_pattern1_rollout_strategy_blueGreen"></a>3.37.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

| Property                                                                                      | Pattern | Type    | Deprecated | Definition                      | Title/Description                                                                                                       |
| --------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| - [activeService](#cronJobs_pattern1_rollout_strategy_blueGreen_activeService )               | No      | string  | No         | -                               | Name of the service that the rollout modifies as the active service.                                                    |
| - [autoPromotionEnabled](#cronJobs_pattern1_rollout_strategy_blueGreen_autoPromotionEnabled ) | No      | boolean | No         | -                               | indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state. |
| - [prePromotionAnalysis](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis ) | No      | object  | No         | In #/properties/rolloutAnalysis | configuration to run analysis before a selector switch                                                                  |
| - [previewService](#cronJobs_pattern1_rollout_strategy_blueGreen_previewService )             | No      | string  | No         | -                               | Name of the service that the rollout modifies as the preview service.                                                   |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_activeService"></a>3.37.1.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > activeService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the active service.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_autoPromotionEnabled"></a>3.37.1.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > autoPromotionEnabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis"></a>3.37.1.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis`

|                           |                              |
| ------------------------- | ---------------------------- |
| **Type**                  | `object`                     |
| **Required**              | No                           |
| **Additional properties** | Any type allowed             |
| **Defined in**            | #/properties/rolloutAnalysis |

**Description:** configuration to run analysis before a selector switch

| Property                                                                                                         | Pattern | Type            | Deprecated | Definition | Title/Description                                                       |
| ---------------------------------------------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------- |
| - [analysisRunMetadata](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata ) | No      | object          | No         | -          | extra labels to add to the AnalysisRun                                  |
| - [args](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args )                               | No      | array of object | No         | -          | the arguments that will be added to the AnalysisRuns                    |
| - [templates](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates )                     | No      | array of object | No         | -          | reference to a list of analysis templates to combine for an AnalysisRun |
| - [](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_additionalProperties )                   | No      | object          | No         | -          | -                                                                       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata"></a>3.37.1.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** extra labels to add to the AnalysisRun

| Property                                                                                                             | Pattern | Type   | Deprecated | Definition | Title/Description                                |
| -------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------ |
| - [annotations](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations ) | No      | object | No         | -          | additional annotations to add to the AnalysisRun |
| - [labels](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels )           | No      | object | No         | -          | additional labels to add to the AnalysisRun      |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations"></a>3.37.1.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional annotations to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels"></a>3.37.1.1.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional labels to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args"></a>3.37.1.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** the arguments that will be added to the AnalysisRuns

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                             | Description |
| ------------------------------------------------------------------------------------------- | ----------- |
| [args items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items"></a>3.37.1.1.3.2.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name )           | No      | string | No         | -          | -                 |
| - [value](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value )         | No      | string | No         | -          | -                 |
| - [valueFrom](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name"></a>3.37.1.1.3.2.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value"></a>3.37.1.1.3.2.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom"></a>3.37.1.1.3.2.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                                | Pattern | Type             | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [fieldRef](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef )                         | No      | object           | No         | -          | -                 |
| - [podTemplateHashValue](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue ) | No      | enum (of string) | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef"></a>3.37.1.1.3.2.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [fieldPath](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath"></a>3.37.1.1.3.2.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef > fieldPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue"></a>3.37.1.1.3.2.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > podTemplateHashValue`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "Latest"
* "Stable"

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates"></a>3.37.1.1.3.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** reference to a list of analysis templates to combine for an AnalysisRun

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                                       | Description |
| ----------------------------------------------------------------------------------------------------- | ----------- |
| [templates items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items"></a>3.37.1.1.3.3.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                           | Pattern | Type    | Deprecated | Definition | Title/Description                                                         |
| ------------------------------------------------------------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [clusterScope](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope ) | No      | boolean | No         | -          | Whether to look for the templateName at cluster scope or namespace scope. |
| - [templateName](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName ) | No      | string  | No         | -          |  name of the AnalysisTemplate to use for the rollout analysis             |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope"></a>3.37.1.1.3.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > clusterScope`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Whether to look for the templateName at cluster scope or namespace scope.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName"></a>3.37.1.1.3.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > templateName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:**  name of the AnalysisTemplate to use for the rollout analysis

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_previewService"></a>3.37.1.1.4. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > previewService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the preview service.

### <a name="global_s3Storage"></a>3.38. Property `stack > global > s3Storage`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                  | Pattern | Type                      | Deprecated | Definition | Title/Description                           |
| --------------------------------------------------------- | ------- | ------------------------- | ---------- | ---------- | ------------------------------------------- |
| - [accessModes](#global_s3Storage_accessModes )           | No      | array of enum (of string) | No         | -          | Access modes for the S3 storage             |
| - [annotations](#global_s3Storage_annotations )           | No      | object                    | No         | -          | Additional annotations for PV/PVC           |
| - [bucketName](#global_s3Storage_bucketName )             | No      | string                    | No         | -          | S3 bucket name                              |
| - [capacity](#global_s3Storage_capacity )                 | No      | string                    | No         | -          | Storage capacity                            |
| - [enabled](#global_s3Storage_enabled )                   | No      | boolean                   | No         | -          | Enable S3 CSI storage                       |
| - [labels](#global_s3Storage_labels )                     | No      | object                    | No         | -          | Additional labels for PV/PVC                |
| - [pvName](#global_s3Storage_pvName )                     | No      | string                    | No         | -          | Custom PV name (auto-generated if empty)    |
| - [pvcName](#global_s3Storage_pvcName )                   | No      | string                    | No         | -          | Custom PVC name (auto-generated if empty)   |
| - [reclaimPolicy](#global_s3Storage_reclaimPolicy )       | No      | string                    | No         | -          | Reclaim policy for the PV                   |
| - [region](#global_s3Storage_region )                     | No      | string                    | No         | -          | AWS region                                  |
| - [volumeAttributes](#global_s3Storage_volumeAttributes ) | No      | object                    | No         | -          | Additional CSI volume attributes            |
| - [volumeHandle](#global_s3Storage_volumeHandle )         | No      | string                    | No         | -          | CSI volume handle (auto-generated if empty) |

#### <a name="global_s3Storage_accessModes"></a>3.38.1. Property `stack > global > s3Storage > accessModes`

|              |                             |
| ------------ | --------------------------- |
| **Type**     | `array of enum (of string)` |
| **Required** | No                          |

**Description:** Access modes for the S3 storage

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                          | Description |
| -------------------------------------------------------- | ----------- |
| [accessModes items](#global_s3Storage_accessModes_items) | -           |

##### <a name="global_s3Storage_accessModes_items"></a>3.38.1.1. stack > global > s3Storage > accessModes > accessModes items

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "ReadWriteOnce"
* "ReadOnlyMany"
* "ReadWriteMany"
* "ReadWriteOncePod"

#### <a name="global_s3Storage_annotations"></a>3.38.2. Property `stack > global > s3Storage > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional annotations for PV/PVC

#### <a name="global_s3Storage_bucketName"></a>3.38.3. Property `stack > global > s3Storage > bucketName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** S3 bucket name

#### <a name="global_s3Storage_capacity"></a>3.38.4. Property `stack > global > s3Storage > capacity`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage capacity

#### <a name="global_s3Storage_enabled"></a>3.38.5. Property `stack > global > s3Storage > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable S3 CSI storage

#### <a name="global_s3Storage_labels"></a>3.38.6. Property `stack > global > s3Storage > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional labels for PV/PVC

#### <a name="global_s3Storage_pvName"></a>3.38.7. Property `stack > global > s3Storage > pvName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom PV name (auto-generated if empty)

#### <a name="global_s3Storage_pvcName"></a>3.38.8. Property `stack > global > s3Storage > pvcName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom PVC name (auto-generated if empty)

#### <a name="global_s3Storage_reclaimPolicy"></a>3.38.9. Property `stack > global > s3Storage > reclaimPolicy`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Reclaim policy for the PV

#### <a name="global_s3Storage_region"></a>3.38.10. Property `stack > global > s3Storage > region`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** AWS region

#### <a name="global_s3Storage_volumeAttributes"></a>3.38.11. Property `stack > global > s3Storage > volumeAttributes`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional CSI volume attributes

#### <a name="global_s3Storage_volumeHandle"></a>3.38.12. Property `stack > global > s3Storage > volumeHandle`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** CSI volume handle (auto-generated if empty)

### <a name="global_securityContext"></a>3.39. Property `stack > global > securityContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Security context

### <a name="global_service"></a>3.40. Property `stack > global > service`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Service configuration

| Property                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [port](#global_service_port ) | No      | number | No         | -          | Service port      |
| - [type](#global_service_type ) | No      | string | No         | -          | Service type      |

#### <a name="global_service_port"></a>3.40.1. Property `stack > global > service > port`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Service port

#### <a name="global_service_type"></a>3.40.2. Property `stack > global > service > type`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Service type

### <a name="global_serviceAccount"></a>3.41. Property `stack > global > serviceAccount`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Service account configuration

| Property                                             | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                   |
| ---------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------- |
| - [annotations](#global_serviceAccount_annotations ) | No      | object  | No         | -          | Annotations to add to the service account                                                                           |
| - [automount](#global_serviceAccount_automount )     | No      | boolean | No         | -          | Specifies whether to automatically mount a ServiceAccount's API credentials                                         |
| - [create](#global_serviceAccount_create )           | No      | boolean | No         | -          | Specifies whether a service account should be created                                                               |
| - [name](#global_serviceAccount_name )               | No      | string  | No         | -          | Name of the service account to use (if not set and create is true, a name is generated using the fullname template) |

#### <a name="global_serviceAccount_annotations"></a>3.41.1. Property `stack > global > serviceAccount > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to the service account

#### <a name="global_serviceAccount_automount"></a>3.41.2. Property `stack > global > serviceAccount > automount`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Specifies whether to automatically mount a ServiceAccount's API credentials

#### <a name="global_serviceAccount_create"></a>3.41.3. Property `stack > global > serviceAccount > create`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Specifies whether a service account should be created

#### <a name="global_serviceAccount_name"></a>3.41.4. Property `stack > global > serviceAccount > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service account to use (if not set and create is true, a name is generated using the fullname template)

### <a name="global_shareProcessNamespace"></a>3.42. Property `stack > global > shareProcessNamespace`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Share process namespace

### <a name="global_sidecars"></a>3.43. Property `stack > global > sidecars`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of sidecars

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

### <a name="global_startupProbe"></a>3.44. Property `stack > global > startupProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Startup probe configuration

| Property                                                           | Pattern | Type    | Deprecated | Definition | Title/Description                                                                     |
| ------------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [enabled](#global_startupProbe_enabled )                         | No      | boolean | No         | -          | Enable the startup probe                                                              |
| - [exec](#global_startupProbe_exec )                               | No      | object  | No         | -          | Exec probe configuration                                                              |
| - [failureThreshold](#global_startupProbe_failureThreshold )       | No      | integer | No         | -          | Number of failures before the probe is considered failed                              |
| - [initialDelaySeconds](#global_startupProbe_initialDelaySeconds ) | No      | integer | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#global_startupProbe_periodSeconds )             | No      | integer | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#global_startupProbe_successThreshold )       | No      | integer | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#global_startupProbe_timeoutSeconds )           | No      | integer | No         | -          | Timeout for the probe                                                                 |

#### <a name="global_startupProbe_enabled"></a>3.44.1. Property `stack > global > startupProbe > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable the startup probe

#### <a name="global_startupProbe_exec"></a>3.44.2. Property `stack > global > startupProbe > exec`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Exec probe configuration

| Property                                        | Pattern | Type            | Deprecated | Definition | Title/Description |
| ----------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------- |
| - [command](#global_startupProbe_exec_command ) | No      | array of string | No         | -          | -                 |

##### <a name="global_startupProbe_exec_command"></a>3.44.2.1. Property `stack > global > startupProbe > exec > command`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                          | Description |
| -------------------------------------------------------- | ----------- |
| [command items](#global_startupProbe_exec_command_items) | -           |

###### <a name="global_startupProbe_exec_command_items"></a>3.44.2.1.1. stack > global > startupProbe > exec > command > command items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="global_startupProbe_failureThreshold"></a>3.44.3. Property `stack > global > startupProbe > failureThreshold`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of failures before the probe is considered failed

#### <a name="global_startupProbe_initialDelaySeconds"></a>3.44.4. Property `stack > global > startupProbe > initialDelaySeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of seconds after the container has started before the probe is first initiated

#### <a name="global_startupProbe_periodSeconds"></a>3.44.5. Property `stack > global > startupProbe > periodSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** How often to perform the probe

#### <a name="global_startupProbe_successThreshold"></a>3.44.6. Property `stack > global > startupProbe > successThreshold`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of successes before the probe is considered successful

#### <a name="global_startupProbe_timeoutSeconds"></a>3.44.7. Property `stack > global > startupProbe > timeoutSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Timeout for the probe

### <a name="global_tolerations"></a>3.45. Property `stack > global > tolerations`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Tolerations for the pod

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

### <a name="global_topologySpreadConstraints"></a>3.46. Property `stack > global > topologySpreadConstraints`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Topology spread constraints for the pod

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

### <a name="global_volumeMounts"></a>3.47. Property `stack > global > volumeMounts`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional volume mounts on the output Deployment definition

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

### <a name="global_volumes"></a>3.48. Property `stack > global > volumes`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional volumes on the output Deployment definition

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

## <a name="jobs"></a>4. Property `stack > jobs`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Jobs to deploy

| Property                  | Pattern | Type   | Deprecated | Definition             | Title/Description                                                                                            |
| ------------------------- | ------- | ------ | ---------- | ---------------------- | ------------------------------------------------------------------------------------------------------------ |
| - [^.*$](#jobs_pattern1 ) | Yes     | object | No         | In #/properties/global | Global configuration for the stack - this serves as the default configuration for all services/jobs/cronjobs |

### <a name="jobs_pattern1"></a>4.1. Pattern Property `stack > jobs > global`
> All properties whose name matches the regular expression
```^.*$``` ([Test](https://regex101.com/?regex=%5E.%2A%24))
must respect the following conditions

|                           |                     |
| ------------------------- | ------------------- |
| **Type**                  | `object`            |
| **Required**              | No                  |
| **Additional properties** | Any type allowed    |
| **Defined in**            | #/properties/global |

**Description:** Global configuration for the stack - this serves as the default configuration for all services/jobs/cronjobs

| Property                                                                     | Pattern | Type             | Deprecated | Definition              | Title/Description                                                                                                                                                                                                                                                                |
| ---------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [affinity](#cronJobs_pattern1_affinity )                                   | No      | object           | No         | -                       | Affinity for the pod                                                                                                                                                                                                                                                             |
| - [annotations](#cronJobs_pattern1_annotations )                             | No      | object           | No         | -                       | Global annotations to add to all resources                                                                                                                                                                                                                                       |
| - [appContext](#cronJobs_pattern1_appContext )                               | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [appSecrets](#cronJobs_pattern1_appSecrets )                               | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [argoBuildEnv](#cronJobs_pattern1_argoBuildEnv )                           | No      | object           | No         | -                       | Argo built-in environment parameters (provided by Argus API)                                                                                                                                                                                                                     |
| - [args](#cronJobs_pattern1_args )                                           | No      | array of string  | No         | -                       | Arguments to pass to the command in the primary container                                                                                                                                                                                                                        |
| - [argusMetadata](#cronJobs_pattern1_argusMetadata )                         | No      | object           | No         | -                       | Argus metadata (provided by Argus API)                                                                                                                                                                                                                                           |
| - [autoscaling](#cronJobs_pattern1_autoscaling )                             | No      | object           | No         | -                       | Autoscaling configuration                                                                                                                                                                                                                                                        |
| - [command](#cronJobs_pattern1_command )                                     | No      | array of string  | No         | -                       | Command to run in the primary container                                                                                                                                                                                                                                          |
| - [deploymentKind](#cronJobs_pattern1_deploymentKind )                       | No      | enum (of string) | No         | -                       | Specifies the Kubernetes Kind for the main application workload controller (Deployment or Rollout).                                                                                                                                                                              |
| - [deploymentStage](#cronJobs_pattern1_deploymentStage )                     | No      | string           | No         | -                       | Deployment stage                                                                                                                                                                                                                                                                 |
| - [dnsPolicy](#cronJobs_pattern1_dnsPolicy )                                 | No      | enum (of string) | No         | -                       | DNS policy for the pod                                                                                                                                                                                                                                                           |
| - [env](#cronJobs_pattern1_env )                                             | No      | array of object  | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [envFrom](#cronJobs_pattern1_envFrom )                                     | No      | array of object  | No         | -                       | Environment variables from configmaps or secrets                                                                                                                                                                                                                                 |
| - [fullnameOverride](#cronJobs_pattern1_fullnameOverride )                   | No      | string           | No         | -                       | Name to prefix the K8s resources with, replaces the stack name prefix                                                                                                                                                                                                            |
| - [gateway](#cronJobs_pattern1_gateway )                                     | No      | object           | No         | -                       | Gateway API HTTPRoute configuration                                                                                                                                                                                                                                              |
| - [grafanaDashboard](#cronJobs_pattern1_grafanaDashboard )                   | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [image](#cronJobs_pattern1_image )                                         | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [imagePullSecrets](#cronJobs_pattern1_imagePullSecrets )                   | No      | array of string  | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [ingress](#cronJobs_pattern1_ingress )                                     | No      | object           | No         | -                       | Ingress configuration                                                                                                                                                                                                                                                            |
| - [initContainers](#cronJobs_pattern1_initContainers )                       | No      | array            | No         | -                       | List of init containers                                                                                                                                                                                                                                                          |
| - [kedaAutoscaling](#cronJobs_pattern1_kedaAutoscaling )                     | No      | object           | No         | -                       | KEDA autoscaling configuration (creates a ScaledObject instead of HPA)                                                                                                                                                                                                           |
| - [livenessProbe](#cronJobs_pattern1_livenessProbe )                         | No      | object           | No         | -                       | Liveness probe configuration                                                                                                                                                                                                                                                     |
| - [nameOverride](#cronJobs_pattern1_nameOverride )                           | No      | string           | No         | -                       | Name to prefix the K8s resources with, combined with the stack name prefix                                                                                                                                                                                                       |
| - [nodeSelector](#cronJobs_pattern1_nodeSelector )                           | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [oidcProxy](#cronJobs_pattern1_oidcProxy )                                 | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [oidcProxyGateway](#cronJobs_pattern1_oidcProxyGateway )                   | No      | object           | No         | -                       | Native Envoy Gateway OIDC authentication configuration (used when gateway.oidcProtected is true). Requires explicit clientID and issuer configuration. clientSecret is auto-referenced from appSecrets. redirectURL is auto-generated as https://<gateway.host>/oauth2/callback. |
| - [persistence](#cronJobs_pattern1_persistence )                             | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [podAnnotations](#cronJobs_pattern1_podAnnotations )                       | No      | object           | No         | -                       | Annotations to add to pods                                                                                                                                                                                                                                                       |
| - [podLabels](#cronJobs_pattern1_podLabels )                                 | No      | object           | No         | -                       | Global labels to add to all pods                                                                                                                                                                                                                                                 |
| - [podSecurityContext](#cronJobs_pattern1_podSecurityContext )               | No      | object           | No         | -                       | Pod security context                                                                                                                                                                                                                                                             |
| - [progressDeadlineSeconds](#cronJobs_pattern1_progressDeadlineSeconds )     | No      | integer          | No         | -                       | the number of seconds the Deployment controller waits before indicating (in the Deployment status) that the Deployment progress has stalled                                                                                                                                      |
| - [readinessProbe](#cronJobs_pattern1_readinessProbe )                       | No      | object           | No         | -                       | Readiness probe configuration                                                                                                                                                                                                                                                    |
| - [replicaCount](#cronJobs_pattern1_replicaCount )                           | No      | integer          | No         | -                       | Number of replicas                                                                                                                                                                                                                                                               |
| - [resources](#cronJobs_pattern1_resources )                                 | No      | object           | No         | -                       | Resource requests and limits for the primary container                                                                                                                                                                                                                           |
| - [restartPolicy](#cronJobs_pattern1_restartPolicy )                         | No      | enum (of string) | No         | -                       | Restart policy for the pod                                                                                                                                                                                                                                                       |
| - [rollout](#cronJobs_pattern1_rollout )                                     | No      | object           | No         | In #/properties/rollout | -                                                                                                                                                                                                                                                                                |
| - [s3Storage](#cronJobs_pattern1_s3Storage )                                 | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [securityContext](#cronJobs_pattern1_securityContext )                     | No      | object           | No         | -                       | Security context                                                                                                                                                                                                                                                                 |
| - [service](#cronJobs_pattern1_service )                                     | No      | object           | No         | -                       | Service configuration                                                                                                                                                                                                                                                            |
| - [serviceAccount](#cronJobs_pattern1_serviceAccount )                       | No      | object           | No         | -                       | Service account configuration                                                                                                                                                                                                                                                    |
| - [shareProcessNamespace](#cronJobs_pattern1_shareProcessNamespace )         | No      | boolean          | No         | -                       | Share process namespace                                                                                                                                                                                                                                                          |
| - [sidecars](#cronJobs_pattern1_sidecars )                                   | No      | array            | No         | -                       | List of sidecars                                                                                                                                                                                                                                                                 |
| - [startupProbe](#cronJobs_pattern1_startupProbe )                           | No      | object           | No         | -                       | Startup probe configuration                                                                                                                                                                                                                                                      |
| - [tolerations](#cronJobs_pattern1_tolerations )                             | No      | array            | No         | -                       | Tolerations for the pod                                                                                                                                                                                                                                                          |
| - [topologySpreadConstraints](#cronJobs_pattern1_topologySpreadConstraints ) | No      | array            | No         | -                       | Topology spread constraints for the pod                                                                                                                                                                                                                                          |
| - [volumeMounts](#cronJobs_pattern1_volumeMounts )                           | No      | array            | No         | -                       | Additional volume mounts on the output Deployment definition                                                                                                                                                                                                                     |
| - [volumes](#cronJobs_pattern1_volumes )                                     | No      | array            | No         | -                       | Additional volumes on the output Deployment definition                                                                                                                                                                                                                           |

#### <a name="cronJobs_pattern1_affinity"></a>4.1.1. Property `stack > cronJobs > ^.*$ > affinity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Affinity for the pod

#### <a name="cronJobs_pattern1_annotations"></a>4.1.2. Property `stack > cronJobs > ^.*$ > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global annotations to add to all resources

#### <a name="cronJobs_pattern1_appContext"></a>4.1.3. Property `stack > cronJobs > ^.*$ > appContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [envContextConfigMapName](#cronJobs_pattern1_appContext_envContextConfigMapName )     | No      | string | No         | -          | -                 |
| - [stackContextConfigMapName](#cronJobs_pattern1_appContext_stackContextConfigMapName ) | No      | string | No         | -          | -                 |

##### <a name="cronJobs_pattern1_appContext_envContextConfigMapName"></a>4.1.3.1. Property `stack > cronJobs > ^.*$ > appContext > envContextConfigMapName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appContext_stackContextConfigMapName"></a>4.1.3.2. Property `stack > cronJobs > ^.*$ > appContext > stackContextConfigMapName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_appSecrets"></a>4.1.4. Property `stack > cronJobs > ^.*$ > appSecrets`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [clusterSecret](#cronJobs_pattern1_appSecrets_clusterSecret ) | No      | object | No         | -          | -                 |
| - [envSecret](#cronJobs_pattern1_appSecrets_envSecret )         | No      | object | No         | -          | -                 |
| - [stackSecret](#cronJobs_pattern1_appSecrets_stackSecret )     | No      | object | No         | -          | -                 |

##### <a name="cronJobs_pattern1_appSecrets_clusterSecret"></a>4.1.4.1. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_clusterSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_clusterSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_clusterSecret_secretKey"></a>4.1.4.1.1. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_clusterSecret_secretName"></a>4.1.4.1.2. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appSecrets_envSecret"></a>4.1.4.2. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_envSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_envSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_envSecret_secretKey"></a>4.1.4.2.1. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_envSecret_secretName"></a>4.1.4.2.2. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appSecrets_stackSecret"></a>4.1.4.3. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                              | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_stackSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_stackSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_stackSecret_secretKey"></a>4.1.4.3.1. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_stackSecret_secretName"></a>4.1.4.3.2. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_argoBuildEnv"></a>4.1.5. Property `stack > cronJobs > ^.*$ > argoBuildEnv`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Argo built-in environment parameters (provided by Argus API)

| Property                                                                              | Pattern | Type   | Deprecated | Definition | Title/Description                                                                         |
| ------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------------------------------------------------------------- |
| - [appName](#cronJobs_pattern1_argoBuildEnv_appName )                                 | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_NAME (this is the ArgoCD app name, not the Argus app name) |
| - [appNamespace](#cronJobs_pattern1_argoBuildEnv_appNamespace )                       | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_NAMESPACE                                                  |
| - [appRevision](#cronJobs_pattern1_argoBuildEnv_appRevision )                         | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION                                                   |
| - [appRevisionShort](#cronJobs_pattern1_argoBuildEnv_appRevisionShort )               | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION_SHORT                                             |
| - [appRevisionShort8](#cronJobs_pattern1_argoBuildEnv_appRevisionShort8 )             | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION_SHORT_8                                           |
| - [appSourcePath](#cronJobs_pattern1_argoBuildEnv_appSourcePath )                     | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_PATH                                                |
| - [appSourceRepoUrl](#cronJobs_pattern1_argoBuildEnv_appSourceRepoUrl )               | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL                                            |
| - [appSourceTargetRevision](#cronJobs_pattern1_argoBuildEnv_appSourceTargetRevision ) | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL                                            |

##### <a name="cronJobs_pattern1_argoBuildEnv_appName"></a>4.1.5.1. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_NAME (this is the ArgoCD app name, not the Argus app name)

##### <a name="cronJobs_pattern1_argoBuildEnv_appNamespace"></a>4.1.5.2. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appNamespace`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_NAMESPACE

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevision"></a>4.1.5.3. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevision`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevisionShort"></a>4.1.5.4. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevisionShort`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION_SHORT

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevisionShort8"></a>4.1.5.5. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevisionShort8`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION_SHORT_8

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourcePath"></a>4.1.5.6. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourcePath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_PATH

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourceRepoUrl"></a>4.1.5.7. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourceRepoUrl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourceTargetRevision"></a>4.1.5.8. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourceTargetRevision`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL

#### <a name="cronJobs_pattern1_args"></a>4.1.6. Property `stack > cronJobs > ^.*$ > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Arguments to pass to the command in the primary container

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be             | Description |
| ------------------------------------------- | ----------- |
| [args items](#cronJobs_pattern1_args_items) | -           |

##### <a name="cronJobs_pattern1_args_items"></a>4.1.6.1. stack > cronJobs > ^.*$ > args > args items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_argusMetadata"></a>4.1.7. Property `stack > cronJobs > ^.*$ > argusMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Argus metadata (provided by Argus API)

| Property                                                   | Pattern | Type   | Deprecated | Definition | Title/Description                          |
| ---------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------ |
| - [appName](#cronJobs_pattern1_argusMetadata_appName )     | No      | string | No         | -          | Set by Argus API to Argus app name         |
| - [envName](#cronJobs_pattern1_argusMetadata_envName )     | No      | string | No         | -          | Set by Argus API to Argus environment name |
| - [repoName](#cronJobs_pattern1_argusMetadata_repoName )   | No      | string | No         | -          | Set by Argus API to Argus repository name  |
| - [repoOwner](#cronJobs_pattern1_argusMetadata_repoOwner ) | No      | string | No         | -          | Set by Argus API to Argus repository owner |
| - [stackName](#cronJobs_pattern1_argusMetadata_stackName ) | No      | string | No         | -          | Set by Argus API to Argus stack name       |

##### <a name="cronJobs_pattern1_argusMetadata_appName"></a>4.1.7.1. Property `stack > cronJobs > ^.*$ > argusMetadata > appName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus app name

##### <a name="cronJobs_pattern1_argusMetadata_envName"></a>4.1.7.2. Property `stack > cronJobs > ^.*$ > argusMetadata > envName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus environment name

##### <a name="cronJobs_pattern1_argusMetadata_repoName"></a>4.1.7.3. Property `stack > cronJobs > ^.*$ > argusMetadata > repoName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus repository name

##### <a name="cronJobs_pattern1_argusMetadata_repoOwner"></a>4.1.7.4. Property `stack > cronJobs > ^.*$ > argusMetadata > repoOwner`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus repository owner

##### <a name="cronJobs_pattern1_argusMetadata_stackName"></a>4.1.7.5. Property `stack > cronJobs > ^.*$ > argusMetadata > stackName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus stack name

#### <a name="cronJobs_pattern1_autoscaling"></a>4.1.8. Property `stack > cronJobs > ^.*$ > autoscaling`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Autoscaling configuration

| Property                                                                                                 | Pattern | Type    | Deprecated | Definition | Title/Description                    |
| -------------------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------ |
| - [enabled](#cronJobs_pattern1_autoscaling_enabled )                                                     | No      | boolean | No         | -          | Enable autoscaling                   |
| - [maxReplicas](#cronJobs_pattern1_autoscaling_maxReplicas )                                             | No      | integer | No         | -          | Maximum number of replicas           |
| - [minReplicas](#cronJobs_pattern1_autoscaling_minReplicas )                                             | No      | integer | No         | -          | Minimum number of replicas           |
| - [targetCPUUtilizationPercentage](#cronJobs_pattern1_autoscaling_targetCPUUtilizationPercentage )       | No      | integer | No         | -          | Target CPU utilization percentage    |
| - [targetMemoryUtilizationPercentage](#cronJobs_pattern1_autoscaling_targetMemoryUtilizationPercentage ) | No      | integer | No         | -          | Target memory utilization percentage |

##### <a name="cronJobs_pattern1_autoscaling_enabled"></a>4.1.8.1. Property `stack > cronJobs > ^.*$ > autoscaling > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable autoscaling

##### <a name="cronJobs_pattern1_autoscaling_maxReplicas"></a>4.1.8.2. Property `stack > cronJobs > ^.*$ > autoscaling > maxReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Maximum number of replicas

##### <a name="cronJobs_pattern1_autoscaling_minReplicas"></a>4.1.8.3. Property `stack > cronJobs > ^.*$ > autoscaling > minReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Minimum number of replicas

##### <a name="cronJobs_pattern1_autoscaling_targetCPUUtilizationPercentage"></a>4.1.8.4. Property `stack > cronJobs > ^.*$ > autoscaling > targetCPUUtilizationPercentage`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Target CPU utilization percentage

##### <a name="cronJobs_pattern1_autoscaling_targetMemoryUtilizationPercentage"></a>4.1.8.5. Property `stack > cronJobs > ^.*$ > autoscaling > targetMemoryUtilizationPercentage`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Target memory utilization percentage

#### <a name="cronJobs_pattern1_command"></a>4.1.9. Property `stack > cronJobs > ^.*$ > command`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Command to run in the primary container

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                   | Description |
| ------------------------------------------------- | ----------- |
| [command items](#cronJobs_pattern1_command_items) | -           |

##### <a name="cronJobs_pattern1_command_items"></a>4.1.9.1. stack > cronJobs > ^.*$ > command > command items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_deploymentKind"></a>4.1.10. Property `stack > cronJobs > ^.*$ > deploymentKind`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |
| **Default**  | `"Deployment"`     |

**Description:** Specifies the Kubernetes Kind for the main application workload controller (Deployment or Rollout).

Must be one of:
* "Deployment"
* "Rollout"

#### <a name="cronJobs_pattern1_deploymentStage"></a>4.1.11. Property `stack > cronJobs > ^.*$ > deploymentStage`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Deployment stage

#### <a name="cronJobs_pattern1_dnsPolicy"></a>4.1.12. Property `stack > cronJobs > ^.*$ > dnsPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** DNS policy for the pod

Must be one of:
* "ClusterFirst"
* "Default"
* "None"

#### <a name="cronJobs_pattern1_env"></a>4.1.13. Property `stack > cronJobs > ^.*$ > env`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be           | Description |
| ----------------------------------------- | ----------- |
| [env items](#cronJobs_pattern1_env_items) | -           |

##### <a name="cronJobs_pattern1_env_items"></a>4.1.13.1. stack > cronJobs > ^.*$ > env > env items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_env_items_name )   | No      | string | No         | -          | -                 |
| - [value](#cronJobs_pattern1_env_items_value ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_env_items_name"></a>4.1.13.1.1. Property `stack > cronJobs > ^.*$ > env > env items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_env_items_value"></a>4.1.13.1.2. Property `stack > cronJobs > ^.*$ > env > env items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_envFrom"></a>4.1.14. Property `stack > cronJobs > ^.*$ > envFrom`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Environment variables from configmaps or secrets

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                   | Description |
| ------------------------------------------------- | ----------- |
| [envFrom items](#cronJobs_pattern1_envFrom_items) | -           |

##### <a name="cronJobs_pattern1_envFrom_items"></a>4.1.14.1. stack > cronJobs > ^.*$ > envFrom > envFrom items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [configMapRef](#cronJobs_pattern1_envFrom_items_configMapRef ) | No      | object | No         | -          | -                 |
| - [prefix](#cronJobs_pattern1_envFrom_items_prefix )             | No      | string | No         | -          | -                 |
| - [secretRef](#cronJobs_pattern1_envFrom_items_secretRef )       | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_envFrom_items_configMapRef"></a>4.1.14.1.1. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > configMapRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_envFrom_items_prefix"></a>4.1.14.1.2. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > prefix`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_envFrom_items_secretRef"></a>4.1.14.1.3. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > secretRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

#### <a name="cronJobs_pattern1_fullnameOverride"></a>4.1.15. Property `stack > cronJobs > ^.*$ > fullnameOverride`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name to prefix the K8s resources with, replaces the stack name prefix

#### <a name="cronJobs_pattern1_gateway"></a>4.1.16. Property `stack > cronJobs > ^.*$ > gateway`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Gateway API HTTPRoute configuration

| Property                                                           | Pattern | Type            | Deprecated | Definition | Title/Description                                                                                                                                                                                                                                                   |
| ------------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_gateway_annotations )           | No      | object          | No         | -          | Annotations to add to HTTPRoute resources                                                                                                                                                                                                                           |
| - [backendTLS](#cronJobs_pattern1_gateway_backendTLS )             | No      | object          | No         | -          | TLS to the upstream Service via a BackendTLSPolicy (gateway.networking.k8s.io/v1)                                                                                                                                                                                   |
| - [basicAuth](#cronJobs_pattern1_gateway_basicAuth )               | No      | object          | No         | -          | HTTP basic auth via a SecurityPolicy. Mutually exclusive with gateway.oidcProtected                                                                                                                                                                                 |
| - [cors](#cronJobs_pattern1_gateway_cors )                         | No      | object          | No         | -          | CORS via a SecurityPolicy                                                                                                                                                                                                                                           |
| - [enabled](#cronJobs_pattern1_gateway_enabled )                   | No      | boolean         | No         | -          | Enable Gateway API HTTPRoute (alternative to Ingress)                                                                                                                                                                                                               |
| - [gatewayName](#cronJobs_pattern1_gateway_gatewayName )           | No      | string          | No         | -          | Name of the Gateway resource to attach to                                                                                                                                                                                                                           |
| - [gatewayNamespace](#cronJobs_pattern1_gateway_gatewayNamespace ) | No      | string          | No         | -          | Namespace of the Gateway resource                                                                                                                                                                                                                                   |
| - [host](#cronJobs_pattern1_gateway_host )                         | No      | string          | No         | -          | Hostname for HTTPRoute                                                                                                                                                                                                                                              |
| - [hostRewrite](#cronJobs_pattern1_gateway_hostRewrite )           | No      | string          | No         | -          | Rewrite the Host header sent upstream via an HTTPRoute URLRewrite filter, empty disables it                                                                                                                                                                         |
| - [ipAllowList](#cronJobs_pattern1_gateway_ipAllowList )           | No      | array           | No         | -          | Client IP allowlist of CIDRs that renders a SecurityPolicy authorization rule (defaultAction Deny). Empty disables it                                                                                                                                               |
| - [oidcProtected](#cronJobs_pattern1_gateway_oidcProtected )       | No      | boolean         | No         | -          | Enable OIDC protection via Envoy Gateway SecurityPolicy (requires oidcProxyGateway configuration)                                                                                                                                                                   |
| - [paths](#cronJobs_pattern1_gateway_paths )                       | No      | array of object | No         | -          | List of HTTPRoute paths                                                                                                                                                                                                                                             |
| - [rateLimit](#cronJobs_pattern1_gateway_rateLimit )               | No      | object          | No         | -          | Local rate limit via a BackendTrafficPolicy (Envoy local token bucket, no burst concept)                                                                                                                                                                            |
| - [redirect](#cronJobs_pattern1_gateway_redirect )                 | No      | object          | No         | -          | Whole-route redirect via an HTTPRoute RequestRedirect filter, replaces backend routing for the host                                                                                                                                                                 |
| - [requestHeaders](#cronJobs_pattern1_gateway_requestHeaders )     | No      | object          | No         | -          | Request header modifications (HTTPRoute RequestHeaderModifier filter)                                                                                                                                                                                               |
| - [responseHeaders](#cronJobs_pattern1_gateway_responseHeaders )   | No      | object          | No         | -          | Response header modifications (HTTPRoute ResponseHeaderModifier filter)                                                                                                                                                                                             |
| - [rules](#cronJobs_pattern1_gateway_rules )                       | No      | array           | No         | -          | List of additional HTTPRoute rules with custom hosts. Each entry takes host, optional paths, and an optional vanity block (enabled, hostname, clusterIssuer) that renders a per-host ListenerSet so the extra host can be a vanity domain, mirroring gateway.vanity |
| - [sectionName](#cronJobs_pattern1_gateway_sectionName )           | No      | string          | No         | -          | Optional section name (listener name) on the Gateway                                                                                                                                                                                                                |
| - [sessionAffinity](#cronJobs_pattern1_gateway_sessionAffinity )   | No      | object          | No         | -          | Cookie-based sticky sessions via a BackendTrafficPolicy. Off by default (the ingress cookie-affinity default is not carried to the gateway)                                                                                                                         |
| - [timeouts](#cronJobs_pattern1_gateway_timeouts )                 | No      | object          | No         | -          | HTTPRoute timeouts. request maps to nginx proxy-read and send-timeout. connect (optional) renders a BackendTrafficPolicy                                                                                                                                            |
| - [tlsPassthrough](#cronJobs_pattern1_gateway_tlsPassthrough )     | No      | object          | No         | -          | TLS passthrough via a TLSRoute (the Gateway does not terminate TLS). Mutually exclusive with the L7 gateway features, and requires a Passthrough listener on the shared Gateway                                                                                     |
| - [vanity](#cronJobs_pattern1_gateway_vanity )                     | No      | object          | No         | -          | Self-serve public/vanity-domain TLS via a tenant-owned Gateway API ListenerSet (requires Envoy Gateway >= v1.8 and cert-manager >= v1.20)                                                                                                                           |

##### <a name="cronJobs_pattern1_gateway_annotations"></a>4.1.16.1. Property `stack > cronJobs > ^.*$ > gateway > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to HTTPRoute resources

| Property                                                                                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [external-dns.alpha.kubernetes.io/ttl](#cronJobs_pattern1_gateway_annotations_external-dnsalphakubernetesio/ttl ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_gateway_annotations_external-dnsalphakubernetesio/ttl"></a>4.1.16.1.1. Property `stack > cronJobs > ^.*$ > gateway > annotations > external-dns.alpha.kubernetes.io/ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_gateway_backendTLS"></a>4.1.16.2. Property `stack > cronJobs > ^.*$ > gateway > backendTLS`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** TLS to the upstream Service via a BackendTLSPolicy (gateway.networking.k8s.io/v1)

| Property                                                                                    | Pattern | Type    | Deprecated | Definition | Title/Description                                                                |
| ------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | -------------------------------------------------------------------------------- |
| - [caCertificateRefs](#cronJobs_pattern1_gateway_backendTLS_caCertificateRefs )             | No      | array   | No         | -          | ConfigMap refs holding the CA bundle for self-signed/internal upstreams          |
| - [enabled](#cronJobs_pattern1_gateway_backendTLS_enabled )                                 | No      | boolean | No         | -          | Enable upstream TLS                                                              |
| - [hostname](#cronJobs_pattern1_gateway_backendTLS_hostname )                               | No      | string  | No         | -          | SNI/validation hostname presented by the upstream (required when enabled)        |
| - [wellKnownCACertificates](#cronJobs_pattern1_gateway_backendTLS_wellKnownCACertificates ) | No      | string  | No         | -          | Use the System trust store, or set "" and use caCertificateRefs for a private CA |

###### <a name="cronJobs_pattern1_gateway_backendTLS_caCertificateRefs"></a>4.1.16.2.1. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > caCertificateRefs`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** ConfigMap refs holding the CA bundle for self-signed/internal upstreams

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_backendTLS_enabled"></a>4.1.16.2.2. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable upstream TLS

###### <a name="cronJobs_pattern1_gateway_backendTLS_hostname"></a>4.1.16.2.3. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** SNI/validation hostname presented by the upstream (required when enabled)

###### <a name="cronJobs_pattern1_gateway_backendTLS_wellKnownCACertificates"></a>4.1.16.2.4. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > wellKnownCACertificates`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Use the System trust store, or set "" and use caCertificateRefs for a private CA

##### <a name="cronJobs_pattern1_gateway_basicAuth"></a>4.1.16.3. Property `stack > cronJobs > ^.*$ > gateway > basicAuth`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP basic auth via a SecurityPolicy. Mutually exclusive with gateway.oidcProtected

| Property                                                         | Pattern | Type    | Deprecated | Definition | Title/Description                             |
| ---------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | --------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_basicAuth_enabled )       | No      | boolean | No         | -          | Enable basic auth                             |
| - [secretName](#cronJobs_pattern1_gateway_basicAuth_secretName ) | No      | string  | No         | -          | Name of an Opaque Secret with a .htpasswd key |

###### <a name="cronJobs_pattern1_gateway_basicAuth_enabled"></a>4.1.16.3.1. Property `stack > cronJobs > ^.*$ > gateway > basicAuth > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable basic auth

###### <a name="cronJobs_pattern1_gateway_basicAuth_secretName"></a>4.1.16.3.2. Property `stack > cronJobs > ^.*$ > gateway > basicAuth > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of an Opaque Secret with a .htpasswd key

##### <a name="cronJobs_pattern1_gateway_cors"></a>4.1.16.4. Property `stack > cronJobs > ^.*$ > gateway > cors`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CORS via a SecurityPolicy

| Property                                                                | Pattern | Type    | Deprecated | Definition | Title/Description                                    |
| ----------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------------------------------------- |
| - [allowCredentials](#cronJobs_pattern1_gateway_cors_allowCredentials ) | No      | boolean | No         | -          | Allow credentials                                    |
| - [allowHeaders](#cronJobs_pattern1_gateway_cors_allowHeaders )         | No      | array   | No         | -          | Allowed request headers                              |
| - [allowMethods](#cronJobs_pattern1_gateway_cors_allowMethods )         | No      | array   | No         | -          | Allowed methods                                      |
| - [allowOrigins](#cronJobs_pattern1_gateway_cors_allowOrigins )         | No      | array   | No         | -          | Allowed origins (string patterns)                    |
| - [enabled](#cronJobs_pattern1_gateway_cors_enabled )                   | No      | boolean | No         | -          | Enable CORS                                          |
| - [exposeHeaders](#cronJobs_pattern1_gateway_cors_exposeHeaders )       | No      | array   | No         | -          | Response headers exposed to the browser              |
| - [maxAge](#cronJobs_pattern1_gateway_cors_maxAge )                     | No      | string  | No         | -          | Preflight cache duration (e.g. "1h"), empty omits it |

###### <a name="cronJobs_pattern1_gateway_cors_allowCredentials"></a>4.1.16.4.1. Property `stack > cronJobs > ^.*$ > gateway > cors > allowCredentials`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Allow credentials

###### <a name="cronJobs_pattern1_gateway_cors_allowHeaders"></a>4.1.16.4.2. Property `stack > cronJobs > ^.*$ > gateway > cors > allowHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed request headers

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_allowMethods"></a>4.1.16.4.3. Property `stack > cronJobs > ^.*$ > gateway > cors > allowMethods`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed methods

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_allowOrigins"></a>4.1.16.4.4. Property `stack > cronJobs > ^.*$ > gateway > cors > allowOrigins`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed origins (string patterns)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_enabled"></a>4.1.16.4.5. Property `stack > cronJobs > ^.*$ > gateway > cors > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable CORS

###### <a name="cronJobs_pattern1_gateway_cors_exposeHeaders"></a>4.1.16.4.6. Property `stack > cronJobs > ^.*$ > gateway > cors > exposeHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Response headers exposed to the browser

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_maxAge"></a>4.1.16.4.7. Property `stack > cronJobs > ^.*$ > gateway > cors > maxAge`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Preflight cache duration (e.g. "1h"), empty omits it

##### <a name="cronJobs_pattern1_gateway_enabled"></a>4.1.16.5. Property `stack > cronJobs > ^.*$ > gateway > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable Gateway API HTTPRoute (alternative to Ingress)

##### <a name="cronJobs_pattern1_gateway_gatewayName"></a>4.1.16.6. Property `stack > cronJobs > ^.*$ > gateway > gatewayName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the Gateway resource to attach to

##### <a name="cronJobs_pattern1_gateway_gatewayNamespace"></a>4.1.16.7. Property `stack > cronJobs > ^.*$ > gateway > gatewayNamespace`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Namespace of the Gateway resource

##### <a name="cronJobs_pattern1_gateway_host"></a>4.1.16.8. Property `stack > cronJobs > ^.*$ > gateway > host`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Hostname for HTTPRoute

##### <a name="cronJobs_pattern1_gateway_hostRewrite"></a>4.1.16.9. Property `stack > cronJobs > ^.*$ > gateway > hostRewrite`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Rewrite the Host header sent upstream via an HTTPRoute URLRewrite filter, empty disables it

##### <a name="cronJobs_pattern1_gateway_ipAllowList"></a>4.1.16.10. Property `stack > cronJobs > ^.*$ > gateway > ipAllowList`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Client IP allowlist of CIDRs that renders a SecurityPolicy authorization rule (defaultAction Deny). Empty disables it

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_oidcProtected"></a>4.1.16.11. Property `stack > cronJobs > ^.*$ > gateway > oidcProtected`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC protection via Envoy Gateway SecurityPolicy (requires oidcProxyGateway configuration)

##### <a name="cronJobs_pattern1_gateway_paths"></a>4.1.16.12. Property `stack > cronJobs > ^.*$ > gateway > paths`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of HTTPRoute paths

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                       | Description |
| ----------------------------------------------------- | ----------- |
| [paths items](#cronJobs_pattern1_gateway_paths_items) | -           |

###### <a name="cronJobs_pattern1_gateway_paths_items"></a>4.1.16.12.1. stack > cronJobs > ^.*$ > gateway > paths > paths items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                     |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------- |
| - [path](#cronJobs_pattern1_gateway_paths_items_path )         | No      | string | No         | -          | HTTPRoute path                        |
| - [pathType](#cronJobs_pattern1_gateway_paths_items_pathType ) | No      | string | No         | -          | HTTPRoute path type (Exact or Prefix) |

###### <a name="cronJobs_pattern1_gateway_paths_items_path"></a>4.1.16.12.1.1. Property `stack > cronJobs > ^.*$ > gateway > paths > paths items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** HTTPRoute path

###### <a name="cronJobs_pattern1_gateway_paths_items_pathType"></a>4.1.16.12.1.2. Property `stack > cronJobs > ^.*$ > gateway > paths > paths items > pathType`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** HTTPRoute path type (Exact or Prefix)

##### <a name="cronJobs_pattern1_gateway_rateLimit"></a>4.1.16.13. Property `stack > cronJobs > ^.*$ > gateway > rateLimit`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Local rate limit via a BackendTrafficPolicy (Envoy local token bucket, no burst concept)

| Property                                                     | Pattern | Type    | Deprecated | Definition | Title/Description                           |
| ------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_rateLimit_enabled )   | No      | boolean | No         | -          | Enable local rate limiting                  |
| - [requests](#cronJobs_pattern1_gateway_rateLimit_requests ) | No      | integer | No         | -          | Allowed requests per unit                   |
| - [unit](#cronJobs_pattern1_gateway_rateLimit_unit )         | No      | string  | No         | -          | Rate limit unit (Second, Minute, Hour, Day) |

###### <a name="cronJobs_pattern1_gateway_rateLimit_enabled"></a>4.1.16.13.1. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable local rate limiting

###### <a name="cronJobs_pattern1_gateway_rateLimit_requests"></a>4.1.16.13.2. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > requests`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Allowed requests per unit

###### <a name="cronJobs_pattern1_gateway_rateLimit_unit"></a>4.1.16.13.3. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > unit`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Rate limit unit (Second, Minute, Hour, Day)

##### <a name="cronJobs_pattern1_gateway_redirect"></a>4.1.16.14. Property `stack > cronJobs > ^.*$ > gateway > redirect`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Whole-route redirect via an HTTPRoute RequestRedirect filter, replaces backend routing for the host

| Property                                                        | Pattern | Type    | Deprecated | Definition | Title/Description                                               |
| --------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | --------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_redirect_enabled )       | No      | boolean | No         | -          | Enable a redirect-only route                                    |
| - [hostname](#cronJobs_pattern1_gateway_redirect_hostname )     | No      | string  | No         | -          | Target hostname, empty keeps the request host                   |
| - [path](#cronJobs_pattern1_gateway_redirect_path )             | No      | string  | No         | -          | Replacement full path via ReplaceFullPath, empty keeps the path |
| - [scheme](#cronJobs_pattern1_gateway_redirect_scheme )         | No      | string  | No         | -          | Target scheme, e.g. https                                       |
| - [statusCode](#cronJobs_pattern1_gateway_redirect_statusCode ) | No      | integer | No         | -          | Redirect status code (301 or 302)                               |

###### <a name="cronJobs_pattern1_gateway_redirect_enabled"></a>4.1.16.14.1. Property `stack > cronJobs > ^.*$ > gateway > redirect > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable a redirect-only route

###### <a name="cronJobs_pattern1_gateway_redirect_hostname"></a>4.1.16.14.2. Property `stack > cronJobs > ^.*$ > gateway > redirect > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Target hostname, empty keeps the request host

###### <a name="cronJobs_pattern1_gateway_redirect_path"></a>4.1.16.14.3. Property `stack > cronJobs > ^.*$ > gateway > redirect > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Replacement full path via ReplaceFullPath, empty keeps the path

###### <a name="cronJobs_pattern1_gateway_redirect_scheme"></a>4.1.16.14.4. Property `stack > cronJobs > ^.*$ > gateway > redirect > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Target scheme, e.g. https

###### <a name="cronJobs_pattern1_gateway_redirect_statusCode"></a>4.1.16.14.5. Property `stack > cronJobs > ^.*$ > gateway > redirect > statusCode`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Redirect status code (301 or 302)

##### <a name="cronJobs_pattern1_gateway_requestHeaders"></a>4.1.16.15. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Request header modifications (HTTPRoute RequestHeaderModifier filter)

| Property                                                      | Pattern | Type  | Deprecated | Definition | Title/Description                    |
| ------------------------------------------------------------- | ------- | ----- | ---------- | ---------- | ------------------------------------ |
| - [add](#cronJobs_pattern1_gateway_requestHeaders_add )       | No      | array | No         | -          | Headers to add, list of {name,value} |
| - [remove](#cronJobs_pattern1_gateway_requestHeaders_remove ) | No      | array | No         | -          | Header names to remove               |
| - [set](#cronJobs_pattern1_gateway_requestHeaders_set )       | No      | array | No         | -          | Headers to set, list of {name,value} |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_add"></a>4.1.16.15.1. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > add`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to add, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_remove"></a>4.1.16.15.2. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > remove`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Header names to remove

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_set"></a>4.1.16.15.3. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > set`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to set, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_responseHeaders"></a>4.1.16.16. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Response header modifications (HTTPRoute ResponseHeaderModifier filter)

| Property                                                       | Pattern | Type  | Deprecated | Definition | Title/Description                    |
| -------------------------------------------------------------- | ------- | ----- | ---------- | ---------- | ------------------------------------ |
| - [add](#cronJobs_pattern1_gateway_responseHeaders_add )       | No      | array | No         | -          | Headers to add, list of {name,value} |
| - [remove](#cronJobs_pattern1_gateway_responseHeaders_remove ) | No      | array | No         | -          | Header names to remove               |
| - [set](#cronJobs_pattern1_gateway_responseHeaders_set )       | No      | array | No         | -          | Headers to set, list of {name,value} |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_add"></a>4.1.16.16.1. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > add`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to add, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_remove"></a>4.1.16.16.2. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > remove`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Header names to remove

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_set"></a>4.1.16.16.3. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > set`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to set, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_rules"></a>4.1.16.17. Property `stack > cronJobs > ^.*$ > gateway > rules`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of additional HTTPRoute rules with custom hosts. Each entry takes host, optional paths, and an optional vanity block (enabled, hostname, clusterIssuer) that renders a per-host ListenerSet so the extra host can be a vanity domain, mirroring gateway.vanity

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_sectionName"></a>4.1.16.18. Property `stack > cronJobs > ^.*$ > gateway > sectionName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional section name (listener name) on the Gateway

##### <a name="cronJobs_pattern1_gateway_sessionAffinity"></a>4.1.16.19. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Cookie-based sticky sessions via a BackendTrafficPolicy. Off by default (the ingress cookie-affinity default is not carried to the gateway)

| Property                                                               | Pattern | Type    | Deprecated | Definition | Title/Description                              |
| ---------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------------------------------- |
| - [cookieName](#cronJobs_pattern1_gateway_sessionAffinity_cookieName ) | No      | string  | No         | -          | Affinity cookie name                           |
| - [enabled](#cronJobs_pattern1_gateway_sessionAffinity_enabled )       | No      | boolean | No         | -          | Enable consistent-hash cookie session affinity |
| - [ttl](#cronJobs_pattern1_gateway_sessionAffinity_ttl )               | No      | string  | No         | -          | Affinity cookie TTL                            |

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_cookieName"></a>4.1.16.19.1. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > cookieName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Affinity cookie name

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_enabled"></a>4.1.16.19.2. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable consistent-hash cookie session affinity

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_ttl"></a>4.1.16.19.3. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Affinity cookie TTL

##### <a name="cronJobs_pattern1_gateway_timeouts"></a>4.1.16.20. Property `stack > cronJobs > ^.*$ > gateway > timeouts`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTPRoute timeouts. request maps to nginx proxy-read and send-timeout. connect (optional) renders a BackendTrafficPolicy

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description                                                                                                             |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------------------------------------------------------------------------------------------------- |
| - [backendRequest](#cronJobs_pattern1_gateway_timeouts_backendRequest ) | No      | string | No         | -          | Per-try backend request timeout (HTTPRoute rules[].timeouts.backendRequest). Must be <= request                               |
| - [connect](#cronJobs_pattern1_gateway_timeouts_connect )               | No      | string | No         | -          | Optional upstream TCP connect timeout (renders BackendTrafficPolicy timeout.tcp.connectTimeout), empty uses the Envoy default |
| - [request](#cronJobs_pattern1_gateway_timeouts_request )               | No      | string | No         | -          | Overall request timeout (HTTPRoute rules[].timeouts.request). Set "0s" to disable, e.g. for streaming or websockets           |

###### <a name="cronJobs_pattern1_gateway_timeouts_backendRequest"></a>4.1.16.20.1. Property `stack > cronJobs > ^.*$ > gateway > timeouts > backendRequest`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Per-try backend request timeout (HTTPRoute rules[].timeouts.backendRequest). Must be <= request

###### <a name="cronJobs_pattern1_gateway_timeouts_connect"></a>4.1.16.20.2. Property `stack > cronJobs > ^.*$ > gateway > timeouts > connect`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional upstream TCP connect timeout (renders BackendTrafficPolicy timeout.tcp.connectTimeout), empty uses the Envoy default

###### <a name="cronJobs_pattern1_gateway_timeouts_request"></a>4.1.16.20.3. Property `stack > cronJobs > ^.*$ > gateway > timeouts > request`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Overall request timeout (HTTPRoute rules[].timeouts.request). Set "0s" to disable, e.g. for streaming or websockets

##### <a name="cronJobs_pattern1_gateway_tlsPassthrough"></a>4.1.16.21. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** TLS passthrough via a TLSRoute (the Gateway does not terminate TLS). Mutually exclusive with the L7 gateway features, and requires a Passthrough listener on the shared Gateway

| Property                                                                | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                   |
| ----------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_tlsPassthrough_enabled )         | No      | boolean | No         | -          | Render a TLSRoute instead of an HTTPRoute and skip TLS termination for this service                                 |
| - [sectionName](#cronJobs_pattern1_gateway_tlsPassthrough_sectionName ) | No      | string  | No         | -          | Optional Passthrough listener name to pin to. Empty attaches by hostname plus TLS protocol, which is the usual case |

###### <a name="cronJobs_pattern1_gateway_tlsPassthrough_enabled"></a>4.1.16.21.1. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Render a TLSRoute instead of an HTTPRoute and skip TLS termination for this service

###### <a name="cronJobs_pattern1_gateway_tlsPassthrough_sectionName"></a>4.1.16.21.2. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough > sectionName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional Passthrough listener name to pin to. Empty attaches by hostname plus TLS protocol, which is the usual case

##### <a name="cronJobs_pattern1_gateway_vanity"></a>4.1.16.22. Property `stack > cronJobs > ^.*$ > gateway > vanity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Self-serve public/vanity-domain TLS via a tenant-owned Gateway API ListenerSet (requires Envoy Gateway >= v1.8 and cert-manager >= v1.20)

| Property                                                            | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                                                        |
| ------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [clusterIssuer](#cronJobs_pattern1_gateway_vanity_clusterIssuer ) | No      | string  | No         | -          | cert-manager ClusterIssuer used by the gateway-shim to issue the listener certificate                                                                    |
| - [enabled](#cronJobs_pattern1_gateway_vanity_enabled )             | No      | boolean | No         | -          | Render a ListenerSet attaching an HTTPS listener for this service's vanity domain to the shared Gateway                                                  |
| - [hostname](#cronJobs_pattern1_gateway_vanity_hostname )           | No      | string  | No         | -          | Listener SNI hostname (defaults to gateway.host). A wildcard such as *.parent requires a dns01-capable issuer because http01 cannot issue wildcard certs |

###### <a name="cronJobs_pattern1_gateway_vanity_clusterIssuer"></a>4.1.16.22.1. Property `stack > cronJobs > ^.*$ > gateway > vanity > clusterIssuer`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** cert-manager ClusterIssuer used by the gateway-shim to issue the listener certificate

###### <a name="cronJobs_pattern1_gateway_vanity_enabled"></a>4.1.16.22.2. Property `stack > cronJobs > ^.*$ > gateway > vanity > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Render a ListenerSet attaching an HTTPS listener for this service's vanity domain to the shared Gateway

###### <a name="cronJobs_pattern1_gateway_vanity_hostname"></a>4.1.16.22.3. Property `stack > cronJobs > ^.*$ > gateway > vanity > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Listener SNI hostname (defaults to gateway.host). A wildcard such as *.parent requires a dns01-capable issuer because http01 cannot issue wildcard certs

#### <a name="cronJobs_pattern1_grafanaDashboard"></a>4.1.17. Property `stack > cronJobs > ^.*$ > grafanaDashboard`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                    | Pattern | Type            | Deprecated | Definition | Title/Description                                                  |
| --------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ------------------------------------------------------------------ |
| - [datasources](#cronJobs_pattern1_grafanaDashboard_datasources )           | No      | object          | No         | -          | -                                                                  |
| - [enabled](#cronJobs_pattern1_grafanaDashboard_enabled )                   | No      | boolean         | No         | -          | Enable Grafana dashboard (globally, can be overridden per service) |
| - [extraPanels](#cronJobs_pattern1_grafanaDashboard_extraPanels )           | No      | array of object | No         | -          | Extra panels to add to the Grafana dashboard                       |
| - [instanceSelector](#cronJobs_pattern1_grafanaDashboard_instanceSelector ) | No      | object          | No         | -          | Instance selector for the Grafana dashboard                        |

##### <a name="cronJobs_pattern1_grafanaDashboard_datasources"></a>4.1.17.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                    | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [prometheus](#cronJobs_pattern1_grafanaDashboard_datasources_prometheus ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_datasources_prometheus"></a>4.1.17.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources > prometheus`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                 | Pattern | Type   | Deprecated | Definition | Title/Description         |
| ------------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ------------------------- |
| - [uid](#cronJobs_pattern1_grafanaDashboard_datasources_prometheus_uid ) | No      | string | No         | -          | Prometheus datasource UID |

###### <a name="cronJobs_pattern1_grafanaDashboard_datasources_prometheus_uid"></a>4.1.17.1.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources > prometheus > uid`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Prometheus datasource UID

##### <a name="cronJobs_pattern1_grafanaDashboard_enabled"></a>4.1.17.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable Grafana dashboard (globally, can be overridden per service)

##### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels"></a>4.1.17.3. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Extra panels to add to the Grafana dashboard

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                            | Description |
| -------------------------------------------------------------------------- | ----------- |
| [extraPanels items](#cronJobs_pattern1_grafanaDashboard_extraPanels_items) | -           |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items"></a>4.1.17.3.1. stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [datasource](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_datasource )       | No      | object | No         | -          | -                 |
| - [fieldConfig](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_fieldConfig )     | No      | object | No         | -          | -                 |
| - [gridPos](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos )             | No      | object | No         | -          | -                 |
| - [options](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_options )             | No      | object | No         | -          | -                 |
| - [pluginVersion](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_pluginVersion ) | No      | string | No         | -          | -                 |
| - [targets](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_targets )             | No      | array  | No         | -          | -                 |
| - [title](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_title )                 | No      | string | No         | -          | -                 |
| - [type](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_type )                   | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_datasource"></a>4.1.17.3.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > datasource`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_fieldConfig"></a>4.1.17.3.1.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > fieldConfig`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos"></a>4.1.17.3.1.3. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [h](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_h ) | No      | number | No         | -          | -                 |
| - [w](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_w ) | No      | number | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_h"></a>4.1.17.3.1.3.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos > h`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_w"></a>4.1.17.3.1.3.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos > w`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_options"></a>4.1.17.3.1.4. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > options`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_pluginVersion"></a>4.1.17.3.1.5. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > pluginVersion`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_targets"></a>4.1.17.3.1.6. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > targets`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_title"></a>4.1.17.3.1.7. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > title`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_type"></a>4.1.17.3.1.8. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > type`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector"></a>4.1.17.4. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Instance selector for the Grafana dashboard

| Property                                                                           | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [matchLabels](#cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels"></a>4.1.17.4.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector > matchLabels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                         | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels_name ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels_name"></a>4.1.17.4.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector > matchLabels > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_image"></a>4.1.18. Property `stack > cronJobs > ^.*$ > image`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                             | Pattern | Type             | Deprecated | Definition | Title/Description |
| ---------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [pullPolicy](#cronJobs_pattern1_image_pullPolicy ) | No      | enum (of string) | No         | -          | Image pull policy |
| - [repository](#cronJobs_pattern1_image_repository ) | No      | string           | No         | -          | Image repository  |
| - [tag](#cronJobs_pattern1_image_tag )               | No      | string           | No         | -          | Image tag         |

##### <a name="cronJobs_pattern1_image_pullPolicy"></a>4.1.18.1. Property `stack > cronJobs > ^.*$ > image > pullPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** Image pull policy

Must be one of:
* "Always"
* "IfNotPresent"
* "Never"

##### <a name="cronJobs_pattern1_image_repository"></a>4.1.18.2. Property `stack > cronJobs > ^.*$ > image > repository`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image repository

##### <a name="cronJobs_pattern1_image_tag"></a>4.1.18.3. Property `stack > cronJobs > ^.*$ > image > tag`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image tag

#### <a name="cronJobs_pattern1_imagePullSecrets"></a>4.1.19. Property `stack > cronJobs > ^.*$ > imagePullSecrets`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [imagePullSecrets items](#cronJobs_pattern1_imagePullSecrets_items) | -           |

##### <a name="cronJobs_pattern1_imagePullSecrets_items"></a>4.1.19.1. stack > cronJobs > ^.*$ > imagePullSecrets > imagePullSecrets items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_ingress"></a>4.1.20. Property `stack > cronJobs > ^.*$ > ingress`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Ingress configuration

| Property                                                     | Pattern | Type            | Deprecated | Definition | Title/Description                                                 |
| ------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_ingress_annotations )     | No      | object          | No         | -          | -                                                                 |
| - [className](#cronJobs_pattern1_ingress_className )         | No      | string          | No         | -          | Ingress class name                                                |
| - [enabled](#cronJobs_pattern1_ingress_enabled )             | No      | boolean         | No         | -          | Enable ingress                                                    |
| - [host](#cronJobs_pattern1_ingress_host )                   | No      | string          | No         | -          | Ingress host                                                      |
| - [oidcProtected](#cronJobs_pattern1_ingress_oidcProtected ) | No      | boolean         | No         | -          | Enable OIDC protection (route to oauth2-proxy when using Ingress) |
| - [paths](#cronJobs_pattern1_ingress_paths )                 | No      | array of object | No         | -          | List of ingress paths                                             |
| - [rules](#cronJobs_pattern1_ingress_rules )                 | No      | array           | No         | -          | List of ingress rules                                             |
| - [tls](#cronJobs_pattern1_ingress_tls )                     | No      | array           | No         | -          | List of ingress TLS configurations                                |

##### <a name="cronJobs_pattern1_ingress_annotations"></a>4.1.20.1. Property `stack > cronJobs > ^.*$ > ingress > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [external-dns.alpha.kubernetes.io/ttl](#cronJobs_pattern1_ingress_annotations_external-dnsalphakubernetesio/ttl )                             | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/affinity](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/affinity )                             | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-connect-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-connect-timeout )   | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-read-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-read-timeout )         | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-send-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-send-timeout )         | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/session-cookie-max-age](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-max-age ) | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/session-cookie-name](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-name )       | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_ingress_annotations_external-dnsalphakubernetesio/ttl"></a>4.1.20.1.1. Property `stack > cronJobs > ^.*$ > ingress > annotations > external-dns.alpha.kubernetes.io/ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/affinity"></a>4.1.20.1.2. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/affinity`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-connect-timeout"></a>4.1.20.1.3. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-connect-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-read-timeout"></a>4.1.20.1.4. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-read-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-send-timeout"></a>4.1.20.1.5. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-send-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-max-age"></a>4.1.20.1.6. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/session-cookie-max-age`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-name"></a>4.1.20.1.7. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/session-cookie-name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_ingress_className"></a>4.1.20.2. Property `stack > cronJobs > ^.*$ > ingress > className`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress class name

##### <a name="cronJobs_pattern1_ingress_enabled"></a>4.1.20.3. Property `stack > cronJobs > ^.*$ > ingress > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable ingress

##### <a name="cronJobs_pattern1_ingress_host"></a>4.1.20.4. Property `stack > cronJobs > ^.*$ > ingress > host`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress host

##### <a name="cronJobs_pattern1_ingress_oidcProtected"></a>4.1.20.5. Property `stack > cronJobs > ^.*$ > ingress > oidcProtected`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC protection (route to oauth2-proxy when using Ingress)

##### <a name="cronJobs_pattern1_ingress_paths"></a>4.1.20.6. Property `stack > cronJobs > ^.*$ > ingress > paths`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of ingress paths

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                       | Description |
| ----------------------------------------------------- | ----------- |
| [paths items](#cronJobs_pattern1_ingress_paths_items) | -           |

###### <a name="cronJobs_pattern1_ingress_paths_items"></a>4.1.20.6.1. stack > cronJobs > ^.*$ > ingress > paths > paths items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_ingress_paths_items_path )         | No      | string | No         | -          | Ingress path      |
| - [pathType](#cronJobs_pattern1_ingress_paths_items_pathType ) | No      | string | No         | -          | Ingress path type |

###### <a name="cronJobs_pattern1_ingress_paths_items_path"></a>4.1.20.6.1.1. Property `stack > cronJobs > ^.*$ > ingress > paths > paths items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress path

###### <a name="cronJobs_pattern1_ingress_paths_items_pathType"></a>4.1.20.6.1.2. Property `stack > cronJobs > ^.*$ > ingress > paths > paths items > pathType`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress path type

##### <a name="cronJobs_pattern1_ingress_rules"></a>4.1.20.7. Property `stack > cronJobs > ^.*$ > ingress > rules`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of ingress rules

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_ingress_tls"></a>4.1.20.8. Property `stack > cronJobs > ^.*$ > ingress > tls`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of ingress TLS configurations

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_initContainers"></a>4.1.21. Property `stack > cronJobs > ^.*$ > initContainers`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of init containers

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_kedaAutoscaling"></a>4.1.22. Property `stack > cronJobs > ^.*$ > kedaAutoscaling`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** KEDA autoscaling configuration (creates a ScaledObject instead of HPA)

| Property                                                                 | Pattern | Type            | Deprecated | Definition | Title/Description                                                                         |
| ------------------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------------------------- |
| - [advanced](#cronJobs_pattern1_kedaAutoscaling_advanced )               | No      | object          | No         | -          | Advanced KEDA ScaledObject configuration                                                  |
| - [cooldownPeriod](#cronJobs_pattern1_kedaAutoscaling_cooldownPeriod )   | No      | integer         | No         | -          | Period in seconds to wait after the last trigger fires before scaling back to minReplicas |
| - [enabled](#cronJobs_pattern1_kedaAutoscaling_enabled )                 | No      | boolean         | No         | -          | Enable KEDA autoscaling                                                                   |
| - [maxReplicas](#cronJobs_pattern1_kedaAutoscaling_maxReplicas )         | No      | integer         | No         | -          | Maximum number of replicas                                                                |
| - [minReplicas](#cronJobs_pattern1_kedaAutoscaling_minReplicas )         | No      | integer         | No         | -          | Minimum number of replicas                                                                |
| - [pollingInterval](#cronJobs_pattern1_kedaAutoscaling_pollingInterval ) | No      | integer         | No         | -          | Interval in seconds to check each trigger                                                 |
| - [triggers](#cronJobs_pattern1_kedaAutoscaling_triggers )               | No      | array of object | No         | -          | List of KEDA triggers (e.g. prometheus, cpu, memory, cron)                                |

##### <a name="cronJobs_pattern1_kedaAutoscaling_advanced"></a>4.1.22.1. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > advanced`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Advanced KEDA ScaledObject configuration

##### <a name="cronJobs_pattern1_kedaAutoscaling_cooldownPeriod"></a>4.1.22.2. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > cooldownPeriod`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Period in seconds to wait after the last trigger fires before scaling back to minReplicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_enabled"></a>4.1.22.3. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable KEDA autoscaling

##### <a name="cronJobs_pattern1_kedaAutoscaling_maxReplicas"></a>4.1.22.4. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > maxReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Maximum number of replicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_minReplicas"></a>4.1.22.5. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > minReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Minimum number of replicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_pollingInterval"></a>4.1.22.6. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > pollingInterval`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Interval in seconds to check each trigger

##### <a name="cronJobs_pattern1_kedaAutoscaling_triggers"></a>4.1.22.7. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > triggers`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of KEDA triggers (e.g. prometheus, cpu, memory, cron)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [triggers items](#cronJobs_pattern1_kedaAutoscaling_triggers_items) | -           |

###### <a name="cronJobs_pattern1_kedaAutoscaling_triggers_items"></a>4.1.22.7.1. stack > cronJobs > ^.*$ > kedaAutoscaling > triggers > triggers items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

#### <a name="cronJobs_pattern1_livenessProbe"></a>4.1.23. Property `stack > cronJobs > ^.*$ > livenessProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Liveness probe configuration

| Property                                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                                                                     |
| ------------------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [failureThreshold](#cronJobs_pattern1_livenessProbe_failureThreshold )       | No      | number | No         | -          | Number of failures before the probe is considered failed                              |
| - [httpGet](#cronJobs_pattern1_livenessProbe_httpGet )                         | No      | object | No         | -          | HTTP probe configuration (exec & tcpSocket are also available)                        |
| - [initialDelaySeconds](#cronJobs_pattern1_livenessProbe_initialDelaySeconds ) | No      | number | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_livenessProbe_periodSeconds )             | No      | number | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_livenessProbe_successThreshold )       | No      | number | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_livenessProbe_timeoutSeconds )           | No      | number | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_livenessProbe_failureThreshold"></a>4.1.23.1. Property `stack > cronJobs > ^.*$ > livenessProbe > failureThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_livenessProbe_httpGet"></a>4.1.23.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP probe configuration (exec & tcpSocket are also available)

| Property                                                     | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------ | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_livenessProbe_httpGet_path )     | No      | string      | No         | -          | Path to probe     |
| - [port](#cronJobs_pattern1_livenessProbe_httpGet_port )     | No      | Combination | No         | -          | Port to probe     |
| - [scheme](#cronJobs_pattern1_livenessProbe_httpGet_scheme ) | No      | string      | No         | -          | Scheme to use     |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_path"></a>4.1.23.2.1. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path to probe

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port"></a>4.1.23.2.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Port to probe

| One of(Option)                                                   |
| ---------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i0) |
| [item 1](#cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i1) |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i0"></a>4.1.23.2.2.1. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i1"></a>4.1.23.2.2.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_scheme"></a>4.1.23.2.3. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Scheme to use

##### <a name="cronJobs_pattern1_livenessProbe_initialDelaySeconds"></a>4.1.23.3. Property `stack > cronJobs > ^.*$ > livenessProbe > initialDelaySeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_livenessProbe_periodSeconds"></a>4.1.23.4. Property `stack > cronJobs > ^.*$ > livenessProbe > periodSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_livenessProbe_successThreshold"></a>4.1.23.5. Property `stack > cronJobs > ^.*$ > livenessProbe > successThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_livenessProbe_timeoutSeconds"></a>4.1.23.6. Property `stack > cronJobs > ^.*$ > livenessProbe > timeoutSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_nameOverride"></a>4.1.24. Property `stack > cronJobs > ^.*$ > nameOverride`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name to prefix the K8s resources with, combined with the stack name prefix

#### <a name="cronJobs_pattern1_nodeSelector"></a>4.1.25. Property `stack > cronJobs > ^.*$ > nodeSelector`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description              |
| -------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------ |
| - [kubernetes.io/arch](#cronJobs_pattern1_nodeSelector_kubernetesio/arch ) | No      | string | No         | -          | Node selector for architecture |

##### <a name="cronJobs_pattern1_nodeSelector_kubernetesio/arch"></a>4.1.25.1. Property `stack > cronJobs > ^.*$ > nodeSelector > kubernetes.io/arch`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Node selector for architecture

#### <a name="cronJobs_pattern1_oidcProxy"></a>4.1.26. Property `stack > cronJobs > ^.*$ > oidcProxy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                               | Pattern | Type            | Deprecated | Definition | Title/Description                            |
| ---------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | -------------------------------------------- |
| - [additionalHeaders](#cronJobs_pattern1_oidcProxy_additionalHeaders ) | No      | array           | No         | -          | Additional headers to add                    |
| - [additionalSecrets](#cronJobs_pattern1_oidcProxy_additionalSecrets ) | No      | array           | No         | -          | Additional secrets to mount                  |
| - [annotations](#cronJobs_pattern1_oidcProxy_annotations )             | No      | object          | No         | -          | Annotations to add to the OIDC proxy         |
| - [cookieRefresh](#cronJobs_pattern1_oidcProxy_cookieRefresh )         | No      | string          | No         | -          | Refresh tokens and cookies after this period |
| - [enabled](#cronJobs_pattern1_oidcProxy_enabled )                     | No      | boolean         | No         | -          | Enable OIDC proxy                            |
| - [extraArgs](#cronJobs_pattern1_oidcProxy_extraArgs )                 | No      | array of string | No         | -          | Extra arguments to pass to the OIDC proxy    |
| - [image](#cronJobs_pattern1_oidcProxy_image )                         | No      | object          | No         | -          | -                                            |
| - [replicaCount](#cronJobs_pattern1_oidcProxy_replicaCount )           | No      | integer         | No         | -          | Number of replicas                           |
| - [resources](#cronJobs_pattern1_oidcProxy_resources )                 | No      | object          | No         | -          | -                                            |
| - [skipAuth](#cronJobs_pattern1_oidcProxy_skipAuth )                   | No      | array of object | No         | -          | Paths to skip authentication                 |
| - [volumeMounts](#cronJobs_pattern1_oidcProxy_volumeMounts )           | No      | array           | No         | -          | Volume mounts for the OIDC proxy             |

##### <a name="cronJobs_pattern1_oidcProxy_additionalHeaders"></a>4.1.26.1. Property `stack > cronJobs > ^.*$ > oidcProxy > additionalHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional headers to add

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxy_additionalSecrets"></a>4.1.26.2. Property `stack > cronJobs > ^.*$ > oidcProxy > additionalSecrets`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional secrets to mount

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxy_annotations"></a>4.1.26.3. Property `stack > cronJobs > ^.*$ > oidcProxy > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to the OIDC proxy

##### <a name="cronJobs_pattern1_oidcProxy_cookieRefresh"></a>4.1.26.4. Property `stack > cronJobs > ^.*$ > oidcProxy > cookieRefresh`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Refresh tokens and cookies after this period

##### <a name="cronJobs_pattern1_oidcProxy_enabled"></a>4.1.26.5. Property `stack > cronJobs > ^.*$ > oidcProxy > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC proxy

##### <a name="cronJobs_pattern1_oidcProxy_extraArgs"></a>4.1.26.6. Property `stack > cronJobs > ^.*$ > oidcProxy > extraArgs`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Extra arguments to pass to the OIDC proxy

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                 | Description |
| --------------------------------------------------------------- | ----------- |
| [extraArgs items](#cronJobs_pattern1_oidcProxy_extraArgs_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxy_extraArgs_items"></a>4.1.26.6.1. stack > cronJobs > ^.*$ > oidcProxy > extraArgs > extraArgs items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxy_image"></a>4.1.26.7. Property `stack > cronJobs > ^.*$ > oidcProxy > image`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [repository](#cronJobs_pattern1_oidcProxy_image_repository ) | No      | string | No         | -          | Image repository  |
| - [tag](#cronJobs_pattern1_oidcProxy_image_tag )               | No      | string | No         | -          | Image tag         |

###### <a name="cronJobs_pattern1_oidcProxy_image_repository"></a>4.1.26.7.1. Property `stack > cronJobs > ^.*$ > oidcProxy > image > repository`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image repository

###### <a name="cronJobs_pattern1_oidcProxy_image_tag"></a>4.1.26.7.2. Property `stack > cronJobs > ^.*$ > oidcProxy > image > tag`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image tag

##### <a name="cronJobs_pattern1_oidcProxy_replicaCount"></a>4.1.26.8. Property `stack > cronJobs > ^.*$ > oidcProxy > replicaCount`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of replicas

##### <a name="cronJobs_pattern1_oidcProxy_resources"></a>4.1.26.9. Property `stack > cronJobs > ^.*$ > oidcProxy > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [limits](#cronJobs_pattern1_oidcProxy_resources_limits )     | No      | object | No         | -          | -                 |
| - [requests](#cronJobs_pattern1_oidcProxy_resources_requests ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits"></a>4.1.26.9.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                          | Pattern | Type        | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_oidcProxy_resources_limits_cpu )       | No      | Combination | No         | -          | CPU limit         |
| - [memory](#cronJobs_pattern1_oidcProxy_resources_limits_memory ) | No      | string      | No         | -          | Memory limit      |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu"></a>4.1.26.9.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU limit

| One of(Option)                                                       |
| -------------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i0"></a>4.1.26.9.1.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i1"></a>4.1.26.9.1.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_memory"></a>4.1.26.9.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory limit

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests"></a>4.1.26.9.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                            | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_oidcProxy_resources_requests_cpu )       | No      | Combination | No         | -          | CPU request       |
| - [memory](#cronJobs_pattern1_oidcProxy_resources_requests_memory ) | No      | string      | No         | -          | Memory request    |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu"></a>4.1.26.9.2.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU request

| One of(Option)                                                         |
| ---------------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i0"></a>4.1.26.9.2.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i1"></a>4.1.26.9.2.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_memory"></a>4.1.26.9.2.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory request

##### <a name="cronJobs_pattern1_oidcProxy_skipAuth"></a>4.1.26.10. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Paths to skip authentication

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                               | Description |
| ------------------------------------------------------------- | ----------- |
| [skipAuth items](#cronJobs_pattern1_oidcProxy_skipAuth_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items"></a>4.1.26.10.1. stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [method](#cronJobs_pattern1_oidcProxy_skipAuth_items_method ) | No      | string | No         | -          | -                 |
| - [path](#cronJobs_pattern1_oidcProxy_skipAuth_items_path )     | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items_method"></a>4.1.26.10.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items > method`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items_path"></a>4.1.26.10.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxy_volumeMounts"></a>4.1.26.11. Property `stack > cronJobs > ^.*$ > oidcProxy > volumeMounts`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Volume mounts for the OIDC proxy

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_oidcProxyGateway"></a>4.1.27. Property `stack > cronJobs > ^.*$ > oidcProxyGateway`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Native Envoy Gateway OIDC authentication configuration (used when gateway.oidcProtected is true). Requires explicit clientID and issuer configuration. clientSecret is auto-referenced from appSecrets. redirectURL is auto-generated as https://<gateway.host>/oauth2/callback.

| Property                                                                        | Pattern | Type            | Deprecated | Definition | Title/Description                                                                      |
| ------------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | -------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_oidcProxyGateway_annotations )               | No      | object          | No         | -          | Annotations to add to SecurityPolicy resources                                         |
| - [clientID](#cronJobs_pattern1_oidcProxyGateway_clientID )                     | No      | string          | No         | -          | OIDC client ID (required when gateway.oidcProtected is enabled)                        |
| - [cookieDomain](#cronJobs_pattern1_oidcProxyGateway_cookieDomain )             | No      | string          | No         | -          | Optional root domain for sharing tokens across subdomains (e.g., cluster.dev.czi.team) |
| - [cookieNames](#cronJobs_pattern1_oidcProxyGateway_cookieNames )               | No      | object          | No         | -          | Customize cookie names                                                                 |
| - [forwardAccessToken](#cronJobs_pattern1_oidcProxyGateway_forwardAccessToken ) | No      | boolean         | No         | -          | Forward access token to backend service                                                |
| - [logoutPath](#cronJobs_pattern1_oidcProxyGateway_logoutPath )                 | No      | string          | No         | -          | Path for logout operations                                                             |
| - [provider](#cronJobs_pattern1_oidcProxyGateway_provider )                     | No      | object          | No         | -          | OIDC provider configuration                                                            |
| - [refreshToken](#cronJobs_pattern1_oidcProxyGateway_refreshToken )             | No      | boolean         | No         | -          | Use refresh tokens to refresh access tokens (default true in Envoy Gateway v1.6.0+)    |
| - [resources](#cronJobs_pattern1_oidcProxyGateway_resources )                   | No      | array           | No         | -          | Optional OAuth2 resources parameter                                                    |
| - [scopes](#cronJobs_pattern1_oidcProxyGateway_scopes )                         | No      | array of string | No         | -          | OIDC scopes to request                                                                 |
| - [skipAuth](#cronJobs_pattern1_oidcProxyGateway_skipAuth )                     | No      | array of object | No         | -          | Paths to skip authentication (creates separate public HTTPRoute)                       |

##### <a name="cronJobs_pattern1_oidcProxyGateway_annotations"></a>4.1.27.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to SecurityPolicy resources

##### <a name="cronJobs_pattern1_oidcProxyGateway_clientID"></a>4.1.27.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > clientID`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** OIDC client ID (required when gateway.oidcProtected is enabled)

##### <a name="cronJobs_pattern1_oidcProxyGateway_cookieDomain"></a>4.1.27.3. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieDomain`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional root domain for sharing tokens across subdomains (e.g., cluster.dev.czi.team)

##### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames"></a>4.1.27.4. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Customize cookie names

| Property                                                                      | Pattern | Type   | Deprecated | Definition | Title/Description                   |
| ----------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------- |
| - [accessToken](#cronJobs_pattern1_oidcProxyGateway_cookieNames_accessToken ) | No      | string | No         | -          | Custom name for access token cookie |
| - [idToken](#cronJobs_pattern1_oidcProxyGateway_cookieNames_idToken )         | No      | string | No         | -          | Custom name for ID token cookie     |

###### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames_accessToken"></a>4.1.27.4.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames > accessToken`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom name for access token cookie

###### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames_idToken"></a>4.1.27.4.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames > idToken`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom name for ID token cookie

##### <a name="cronJobs_pattern1_oidcProxyGateway_forwardAccessToken"></a>4.1.27.5. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > forwardAccessToken`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Forward access token to backend service

##### <a name="cronJobs_pattern1_oidcProxyGateway_logoutPath"></a>4.1.27.6. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > logoutPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path for logout operations

##### <a name="cronJobs_pattern1_oidcProxyGateway_provider"></a>4.1.27.7. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** OIDC provider configuration

| Property                                                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                                                         |
| ---------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [authorizationEndpoint](#cronJobs_pattern1_oidcProxyGateway_provider_authorizationEndpoint ) | No      | string | No         | -          | Optional authorization endpoint (auto-discovered by provider if empty)    |
| - [issuer](#cronJobs_pattern1_oidcProxyGateway_provider_issuer )                               | No      | string | No         | -          | OIDC provider issuer URL (required when gateway.oidcProtected is enabled) |
| - [tokenEndpoint](#cronJobs_pattern1_oidcProxyGateway_provider_tokenEndpoint )                 | No      | string | No         | -          | Optional token endpoint (auto-discovered by provider if empty)            |

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_authorizationEndpoint"></a>4.1.27.7.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > authorizationEndpoint`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional authorization endpoint (auto-discovered by provider if empty)

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_issuer"></a>4.1.27.7.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > issuer`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** OIDC provider issuer URL (required when gateway.oidcProtected is enabled)

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_tokenEndpoint"></a>4.1.27.7.3. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > tokenEndpoint`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional token endpoint (auto-discovered by provider if empty)

##### <a name="cronJobs_pattern1_oidcProxyGateway_refreshToken"></a>4.1.27.8. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > refreshToken`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Use refresh tokens to refresh access tokens (default true in Envoy Gateway v1.6.0+)

##### <a name="cronJobs_pattern1_oidcProxyGateway_resources"></a>4.1.27.9. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > resources`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Optional OAuth2 resources parameter

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxyGateway_scopes"></a>4.1.27.10. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > scopes`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** OIDC scopes to request

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                  | Description |
| ---------------------------------------------------------------- | ----------- |
| [scopes items](#cronJobs_pattern1_oidcProxyGateway_scopes_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxyGateway_scopes_items"></a>4.1.27.10.1. stack > cronJobs > ^.*$ > oidcProxyGateway > scopes > scopes items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth"></a>4.1.27.11. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Paths to skip authentication (creates separate public HTTPRoute)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                      | Description |
| -------------------------------------------------------------------- | ----------- |
| [skipAuth items](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items"></a>4.1.27.11.1. stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                               | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [method](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items_method ) | No      | string | No         | -          | -                 |
| - [path](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items_path )     | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items_method"></a>4.1.27.11.1.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items > method`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items_path"></a>4.1.27.11.1.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_persistence"></a>4.1.28. Property `stack > cronJobs > ^.*$ > persistence`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type    | Deprecated | Definition | Title/Description      |
| ---------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------- |
| - [enabled](#cronJobs_pattern1_persistence_enabled )             | No      | boolean | No         | -          | Enable persistence     |
| - [existingClaim](#cronJobs_pattern1_persistence_existingClaim ) | No      | string  | No         | -          | Existing PVC name      |
| - [mountPath](#cronJobs_pattern1_persistence_mountPath )         | No      | string  | No         | -          | Mount path for the PVC |
| - [pvc](#cronJobs_pattern1_persistence_pvc )                     | No      | object  | No         | -          | -                      |

##### <a name="cronJobs_pattern1_persistence_enabled"></a>4.1.28.1. Property `stack > cronJobs > ^.*$ > persistence > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable persistence

##### <a name="cronJobs_pattern1_persistence_existingClaim"></a>4.1.28.2. Property `stack > cronJobs > ^.*$ > persistence > existingClaim`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Existing PVC name

##### <a name="cronJobs_pattern1_persistence_mountPath"></a>4.1.28.3. Property `stack > cronJobs > ^.*$ > persistence > mountPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Mount path for the PVC

##### <a name="cronJobs_pattern1_persistence_pvc"></a>4.1.28.4. Property `stack > cronJobs > ^.*$ > persistence > pvc`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                   | Pattern | Type                      | Deprecated | Definition | Title/Description        |
| -------------------------------------------------------------------------- | ------- | ------------------------- | ---------- | ---------- | ------------------------ |
| - [accessModes](#cronJobs_pattern1_persistence_pvc_accessModes )           | No      | array of enum (of string) | No         | -          | Access modes for the PVC |
| - [dataSource](#cronJobs_pattern1_persistence_pvc_dataSource )             | No      | object                    | No         | -          | -                        |
| - [resources](#cronJobs_pattern1_persistence_pvc_resources )               | No      | object                    | No         | -          | -                        |
| - [storageClassName](#cronJobs_pattern1_persistence_pvc_storageClassName ) | No      | string                    | No         | -          | Storage class name       |

###### <a name="cronJobs_pattern1_persistence_pvc_accessModes"></a>4.1.28.4.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > accessModes`

|              |                             |
| ------------ | --------------------------- |
| **Type**     | `array of enum (of string)` |
| **Required** | No                          |

**Description:** Access modes for the PVC

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                           | Description |
| ------------------------------------------------------------------------- | ----------- |
| [accessModes items](#cronJobs_pattern1_persistence_pvc_accessModes_items) | -           |

###### <a name="cronJobs_pattern1_persistence_pvc_accessModes_items"></a>4.1.28.4.1.1. stack > cronJobs > ^.*$ > persistence > pvc > accessModes > accessModes items

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "ReadWriteOnce"
* "ReadOnlyMany"
* "ReadWriteMany"
* "ReadWriteOncePod"

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource"></a>4.1.28.4.2. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                              | Pattern | Type   | Deprecated | Definition | Title/Description                                               |
| --------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | --------------------------------------------------------------- |
| - [apiGroup](#cronJobs_pattern1_persistence_pvc_dataSource_apiGroup ) | No      | string | No         | -          | API version of the data source                                  |
| - [kind](#cronJobs_pattern1_persistence_pvc_dataSource_kind )         | No      | string | No         | -          | Kind of the data source [VolumeSnapshot, PersistentVolumeClaim] |
| - [name](#cronJobs_pattern1_persistence_pvc_dataSource_name )         | No      | string | No         | -          | Name of the data source                                         |

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_apiGroup"></a>4.1.28.4.2.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > apiGroup`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** API version of the data source

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_kind"></a>4.1.28.4.2.2. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > kind`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Kind of the data source [VolumeSnapshot, PersistentVolumeClaim]

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_name"></a>4.1.28.4.2.3. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the data source

###### <a name="cronJobs_pattern1_persistence_pvc_resources"></a>4.1.28.4.3. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                             | Pattern | Type   | Deprecated | Definition | Title/Description     |
| -------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | --------------------- |
| - [requests](#cronJobs_pattern1_persistence_pvc_resources_requests ) | No      | object | No         | -          | PVC resource requests |

###### <a name="cronJobs_pattern1_persistence_pvc_resources_requests"></a>4.1.28.4.3.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** PVC resource requests

| Property                                                                    | Pattern | Type   | Deprecated | Definition | Title/Description        |
| --------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------ |
| - [storage](#cronJobs_pattern1_persistence_pvc_resources_requests_storage ) | No      | string | No         | -          | Storage resource request |

###### <a name="cronJobs_pattern1_persistence_pvc_resources_requests_storage"></a>4.1.28.4.3.1.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources > requests > storage`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage resource request

###### <a name="cronJobs_pattern1_persistence_pvc_storageClassName"></a>4.1.28.4.4. Property `stack > cronJobs > ^.*$ > persistence > pvc > storageClassName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage class name

#### <a name="cronJobs_pattern1_podAnnotations"></a>4.1.29. Property `stack > cronJobs > ^.*$ > podAnnotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to pods

#### <a name="cronJobs_pattern1_podLabels"></a>4.1.30. Property `stack > cronJobs > ^.*$ > podLabels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global labels to add to all pods

#### <a name="cronJobs_pattern1_podSecurityContext"></a>4.1.31. Property `stack > cronJobs > ^.*$ > podSecurityContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Pod security context

#### <a name="cronJobs_pattern1_progressDeadlineSeconds"></a>4.1.32. Property `stack > cronJobs > ^.*$ > progressDeadlineSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** the number of seconds the Deployment controller waits before indicating (in the Deployment status) that the Deployment progress has stalled

#### <a name="cronJobs_pattern1_readinessProbe"></a>4.1.33. Property `stack > cronJobs > ^.*$ > readinessProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Readiness probe configuration

| Property                                                                        | Pattern | Type   | Deprecated | Definition | Title/Description                                                                     |
| ------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [failureThreshold](#cronJobs_pattern1_readinessProbe_failureThreshold )       | No      | number | No         | -          | Number of failures before the probe is considered failed                              |
| - [httpGet](#cronJobs_pattern1_readinessProbe_httpGet )                         | No      | object | No         | -          | HTTP probe configuration (exec & tcpSocket are also available)                        |
| - [initialDelaySeconds](#cronJobs_pattern1_readinessProbe_initialDelaySeconds ) | No      | number | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_readinessProbe_periodSeconds )             | No      | number | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_readinessProbe_successThreshold )       | No      | number | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_readinessProbe_timeoutSeconds )           | No      | number | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_readinessProbe_failureThreshold"></a>4.1.33.1. Property `stack > cronJobs > ^.*$ > readinessProbe > failureThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_readinessProbe_httpGet"></a>4.1.33.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP probe configuration (exec & tcpSocket are also available)

| Property                                                      | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_readinessProbe_httpGet_path )     | No      | string      | No         | -          | Path to probe     |
| - [port](#cronJobs_pattern1_readinessProbe_httpGet_port )     | No      | Combination | No         | -          | Port to probe     |
| - [scheme](#cronJobs_pattern1_readinessProbe_httpGet_scheme ) | No      | string      | No         | -          | Scheme to use     |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_path"></a>4.1.33.2.1. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path to probe

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port"></a>4.1.33.2.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Port to probe

| One of(Option)                                                    |
| ----------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i0) |
| [item 1](#cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i1) |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i0"></a>4.1.33.2.2.1. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i1"></a>4.1.33.2.2.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_scheme"></a>4.1.33.2.3. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Scheme to use

##### <a name="cronJobs_pattern1_readinessProbe_initialDelaySeconds"></a>4.1.33.3. Property `stack > cronJobs > ^.*$ > readinessProbe > initialDelaySeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_readinessProbe_periodSeconds"></a>4.1.33.4. Property `stack > cronJobs > ^.*$ > readinessProbe > periodSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_readinessProbe_successThreshold"></a>4.1.33.5. Property `stack > cronJobs > ^.*$ > readinessProbe > successThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_readinessProbe_timeoutSeconds"></a>4.1.33.6. Property `stack > cronJobs > ^.*$ > readinessProbe > timeoutSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_replicaCount"></a>4.1.34. Property `stack > cronJobs > ^.*$ > replicaCount`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of replicas

#### <a name="cronJobs_pattern1_resources"></a>4.1.35. Property `stack > cronJobs > ^.*$ > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource requests and limits for the primary container

| Property                                             | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [limits](#cronJobs_pattern1_resources_limits )     | No      | object | No         | -          | Resource limits   |
| - [requests](#cronJobs_pattern1_resources_requests ) | No      | object | No         | -          | Resource requests |

##### <a name="cronJobs_pattern1_resources_limits"></a>4.1.35.1. Property `stack > cronJobs > ^.*$ > resources > limits`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource limits

| Property                                                | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_resources_limits_cpu )       | No      | Combination | No         | -          | CPU limit         |
| - [memory](#cronJobs_pattern1_resources_limits_memory ) | No      | string      | No         | -          | Memory limit      |

###### <a name="cronJobs_pattern1_resources_limits_cpu"></a>4.1.35.1.1. Property `stack > cronJobs > ^.*$ > resources > limits > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU limit

| One of(Option)                                             |
| ---------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_resources_limits_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_resources_limits_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_resources_limits_cpu_oneOf_i0"></a>4.1.35.1.1.1. Property `stack > cronJobs > ^.*$ > resources > limits > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_limits_cpu_oneOf_i1"></a>4.1.35.1.1.2. Property `stack > cronJobs > ^.*$ > resources > limits > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_limits_memory"></a>4.1.35.1.2. Property `stack > cronJobs > ^.*$ > resources > limits > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory limit

##### <a name="cronJobs_pattern1_resources_requests"></a>4.1.35.2. Property `stack > cronJobs > ^.*$ > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource requests

| Property                                                  | Pattern | Type        | Deprecated | Definition | Title/Description |
| --------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_resources_requests_cpu )       | No      | Combination | No         | -          | CPU request       |
| - [memory](#cronJobs_pattern1_resources_requests_memory ) | No      | string      | No         | -          | Memory request    |

###### <a name="cronJobs_pattern1_resources_requests_cpu"></a>4.1.35.2.1. Property `stack > cronJobs > ^.*$ > resources > requests > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU request

| One of(Option)                                               |
| ------------------------------------------------------------ |
| [item 0](#cronJobs_pattern1_resources_requests_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_resources_requests_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_resources_requests_cpu_oneOf_i0"></a>4.1.35.2.1.1. Property `stack > cronJobs > ^.*$ > resources > requests > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_requests_cpu_oneOf_i1"></a>4.1.35.2.1.2. Property `stack > cronJobs > ^.*$ > resources > requests > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_requests_memory"></a>4.1.35.2.2. Property `stack > cronJobs > ^.*$ > resources > requests > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory request

#### <a name="cronJobs_pattern1_restartPolicy"></a>4.1.36. Property `stack > cronJobs > ^.*$ > restartPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** Restart policy for the pod

Must be one of:
* "Always"
* "OnFailure"
* "Never"

#### <a name="cronJobs_pattern1_rollout"></a>4.1.37. Property `stack > cronJobs > ^.*$ > rollout`

|                           |                      |
| ------------------------- | -------------------- |
| **Type**                  | `object`             |
| **Required**              | No                   |
| **Additional properties** | Any type allowed     |
| **Defined in**            | #/properties/rollout |

| Property                                               | Pattern | Type   | Deprecated | Definition | Title/Description                                   |
| ------------------------------------------------------ | ------- | ------ | ---------- | ---------- | --------------------------------------------------- |
| - [strategy](#cronJobs_pattern1_rollout_strategy )     | No      | object | No         | -          | Specifies the rollout strategy for the application. |
| - [](#cronJobs_pattern1_rollout_additionalProperties ) | No      | object | No         | -          | -                                                   |

##### <a name="cronJobs_pattern1_rollout_strategy"></a>4.1.37.1. Property `stack > cronJobs > ^.*$ > rollout > strategy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

**Description:** Specifies the rollout strategy for the application.

| Property                                                      | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [blueGreen](#cronJobs_pattern1_rollout_strategy_blueGreen ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen"></a>4.1.37.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

| Property                                                                                      | Pattern | Type    | Deprecated | Definition                      | Title/Description                                                                                                       |
| --------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| - [activeService](#cronJobs_pattern1_rollout_strategy_blueGreen_activeService )               | No      | string  | No         | -                               | Name of the service that the rollout modifies as the active service.                                                    |
| - [autoPromotionEnabled](#cronJobs_pattern1_rollout_strategy_blueGreen_autoPromotionEnabled ) | No      | boolean | No         | -                               | indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state. |
| - [prePromotionAnalysis](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis ) | No      | object  | No         | In #/properties/rolloutAnalysis | configuration to run analysis before a selector switch                                                                  |
| - [previewService](#cronJobs_pattern1_rollout_strategy_blueGreen_previewService )             | No      | string  | No         | -                               | Name of the service that the rollout modifies as the preview service.                                                   |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_activeService"></a>4.1.37.1.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > activeService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the active service.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_autoPromotionEnabled"></a>4.1.37.1.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > autoPromotionEnabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis"></a>4.1.37.1.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis`

|                           |                              |
| ------------------------- | ---------------------------- |
| **Type**                  | `object`                     |
| **Required**              | No                           |
| **Additional properties** | Any type allowed             |
| **Defined in**            | #/properties/rolloutAnalysis |

**Description:** configuration to run analysis before a selector switch

| Property                                                                                                         | Pattern | Type            | Deprecated | Definition | Title/Description                                                       |
| ---------------------------------------------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------- |
| - [analysisRunMetadata](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata ) | No      | object          | No         | -          | extra labels to add to the AnalysisRun                                  |
| - [args](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args )                               | No      | array of object | No         | -          | the arguments that will be added to the AnalysisRuns                    |
| - [templates](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates )                     | No      | array of object | No         | -          | reference to a list of analysis templates to combine for an AnalysisRun |
| - [](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_additionalProperties )                   | No      | object          | No         | -          | -                                                                       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata"></a>4.1.37.1.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** extra labels to add to the AnalysisRun

| Property                                                                                                             | Pattern | Type   | Deprecated | Definition | Title/Description                                |
| -------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------ |
| - [annotations](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations ) | No      | object | No         | -          | additional annotations to add to the AnalysisRun |
| - [labels](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels )           | No      | object | No         | -          | additional labels to add to the AnalysisRun      |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations"></a>4.1.37.1.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional annotations to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels"></a>4.1.37.1.1.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional labels to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args"></a>4.1.37.1.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** the arguments that will be added to the AnalysisRuns

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                             | Description |
| ------------------------------------------------------------------------------------------- | ----------- |
| [args items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items"></a>4.1.37.1.1.3.2.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name )           | No      | string | No         | -          | -                 |
| - [value](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value )         | No      | string | No         | -          | -                 |
| - [valueFrom](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name"></a>4.1.37.1.1.3.2.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value"></a>4.1.37.1.1.3.2.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom"></a>4.1.37.1.1.3.2.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                                | Pattern | Type             | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [fieldRef](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef )                         | No      | object           | No         | -          | -                 |
| - [podTemplateHashValue](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue ) | No      | enum (of string) | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef"></a>4.1.37.1.1.3.2.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [fieldPath](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath"></a>4.1.37.1.1.3.2.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef > fieldPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue"></a>4.1.37.1.1.3.2.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > podTemplateHashValue`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "Latest"
* "Stable"

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates"></a>4.1.37.1.1.3.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** reference to a list of analysis templates to combine for an AnalysisRun

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                                       | Description |
| ----------------------------------------------------------------------------------------------------- | ----------- |
| [templates items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items"></a>4.1.37.1.1.3.3.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                           | Pattern | Type    | Deprecated | Definition | Title/Description                                                         |
| ------------------------------------------------------------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [clusterScope](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope ) | No      | boolean | No         | -          | Whether to look for the templateName at cluster scope or namespace scope. |
| - [templateName](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName ) | No      | string  | No         | -          |  name of the AnalysisTemplate to use for the rollout analysis             |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope"></a>4.1.37.1.1.3.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > clusterScope`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Whether to look for the templateName at cluster scope or namespace scope.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName"></a>4.1.37.1.1.3.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > templateName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:**  name of the AnalysisTemplate to use for the rollout analysis

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_previewService"></a>4.1.37.1.1.4. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > previewService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the preview service.

#### <a name="cronJobs_pattern1_s3Storage"></a>4.1.38. Property `stack > cronJobs > ^.*$ > s3Storage`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                             | Pattern | Type                      | Deprecated | Definition | Title/Description                           |
| -------------------------------------------------------------------- | ------- | ------------------------- | ---------- | ---------- | ------------------------------------------- |
| - [accessModes](#cronJobs_pattern1_s3Storage_accessModes )           | No      | array of enum (of string) | No         | -          | Access modes for the S3 storage             |
| - [annotations](#cronJobs_pattern1_s3Storage_annotations )           | No      | object                    | No         | -          | Additional annotations for PV/PVC           |
| - [bucketName](#cronJobs_pattern1_s3Storage_bucketName )             | No      | string                    | No         | -          | S3 bucket name                              |
| - [capacity](#cronJobs_pattern1_s3Storage_capacity )                 | No      | string                    | No         | -          | Storage capacity                            |
| - [enabled](#cronJobs_pattern1_s3Storage_enabled )                   | No      | boolean                   | No         | -          | Enable S3 CSI storage                       |
| - [labels](#cronJobs_pattern1_s3Storage_labels )                     | No      | object                    | No         | -          | Additional labels for PV/PVC                |
| - [pvName](#cronJobs_pattern1_s3Storage_pvName )                     | No      | string                    | No         | -          | Custom PV name (auto-generated if empty)    |
| - [pvcName](#cronJobs_pattern1_s3Storage_pvcName )                   | No      | string                    | No         | -          | Custom PVC name (auto-generated if empty)   |
| - [reclaimPolicy](#cronJobs_pattern1_s3Storage_reclaimPolicy )       | No      | string                    | No         | -          | Reclaim policy for the PV                   |
| - [region](#cronJobs_pattern1_s3Storage_region )                     | No      | string                    | No         | -          | AWS region                                  |
| - [volumeAttributes](#cronJobs_pattern1_s3Storage_volumeAttributes ) | No      | object                    | No         | -          | Additional CSI volume attributes            |
| - [volumeHandle](#cronJobs_pattern1_s3Storage_volumeHandle )         | No      | string                    | No         | -          | CSI volume handle (auto-generated if empty) |

##### <a name="cronJobs_pattern1_s3Storage_accessModes"></a>4.1.38.1. Property `stack > cronJobs > ^.*$ > s3Storage > accessModes`

|              |                             |
| ------------ | --------------------------- |
| **Type**     | `array of enum (of string)` |
| **Required** | No                          |

**Description:** Access modes for the S3 storage

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [accessModes items](#cronJobs_pattern1_s3Storage_accessModes_items) | -           |

###### <a name="cronJobs_pattern1_s3Storage_accessModes_items"></a>4.1.38.1.1. stack > cronJobs > ^.*$ > s3Storage > accessModes > accessModes items

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "ReadWriteOnce"
* "ReadOnlyMany"
* "ReadWriteMany"
* "ReadWriteOncePod"

##### <a name="cronJobs_pattern1_s3Storage_annotations"></a>4.1.38.2. Property `stack > cronJobs > ^.*$ > s3Storage > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional annotations for PV/PVC

##### <a name="cronJobs_pattern1_s3Storage_bucketName"></a>4.1.38.3. Property `stack > cronJobs > ^.*$ > s3Storage > bucketName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** S3 bucket name

##### <a name="cronJobs_pattern1_s3Storage_capacity"></a>4.1.38.4. Property `stack > cronJobs > ^.*$ > s3Storage > capacity`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage capacity

##### <a name="cronJobs_pattern1_s3Storage_enabled"></a>4.1.38.5. Property `stack > cronJobs > ^.*$ > s3Storage > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable S3 CSI storage

##### <a name="cronJobs_pattern1_s3Storage_labels"></a>4.1.38.6. Property `stack > cronJobs > ^.*$ > s3Storage > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional labels for PV/PVC

##### <a name="cronJobs_pattern1_s3Storage_pvName"></a>4.1.38.7. Property `stack > cronJobs > ^.*$ > s3Storage > pvName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom PV name (auto-generated if empty)

##### <a name="cronJobs_pattern1_s3Storage_pvcName"></a>4.1.38.8. Property `stack > cronJobs > ^.*$ > s3Storage > pvcName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom PVC name (auto-generated if empty)

##### <a name="cronJobs_pattern1_s3Storage_reclaimPolicy"></a>4.1.38.9. Property `stack > cronJobs > ^.*$ > s3Storage > reclaimPolicy`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Reclaim policy for the PV

##### <a name="cronJobs_pattern1_s3Storage_region"></a>4.1.38.10. Property `stack > cronJobs > ^.*$ > s3Storage > region`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** AWS region

##### <a name="cronJobs_pattern1_s3Storage_volumeAttributes"></a>4.1.38.11. Property `stack > cronJobs > ^.*$ > s3Storage > volumeAttributes`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional CSI volume attributes

##### <a name="cronJobs_pattern1_s3Storage_volumeHandle"></a>4.1.38.12. Property `stack > cronJobs > ^.*$ > s3Storage > volumeHandle`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** CSI volume handle (auto-generated if empty)

#### <a name="cronJobs_pattern1_securityContext"></a>4.1.39. Property `stack > cronJobs > ^.*$ > securityContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Security context

#### <a name="cronJobs_pattern1_service"></a>4.1.40. Property `stack > cronJobs > ^.*$ > service`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Service configuration

| Property                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------- |
| - [port](#cronJobs_pattern1_service_port ) | No      | number | No         | -          | Service port      |
| - [type](#cronJobs_pattern1_service_type ) | No      | string | No         | -          | Service type      |

##### <a name="cronJobs_pattern1_service_port"></a>4.1.40.1. Property `stack > cronJobs > ^.*$ > service > port`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Service port

##### <a name="cronJobs_pattern1_service_type"></a>4.1.40.2. Property `stack > cronJobs > ^.*$ > service > type`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Service type

#### <a name="cronJobs_pattern1_serviceAccount"></a>4.1.41. Property `stack > cronJobs > ^.*$ > serviceAccount`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Service account configuration

| Property                                                        | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                   |
| --------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_serviceAccount_annotations ) | No      | object  | No         | -          | Annotations to add to the service account                                                                           |
| - [automount](#cronJobs_pattern1_serviceAccount_automount )     | No      | boolean | No         | -          | Specifies whether to automatically mount a ServiceAccount's API credentials                                         |
| - [create](#cronJobs_pattern1_serviceAccount_create )           | No      | boolean | No         | -          | Specifies whether a service account should be created                                                               |
| - [name](#cronJobs_pattern1_serviceAccount_name )               | No      | string  | No         | -          | Name of the service account to use (if not set and create is true, a name is generated using the fullname template) |

##### <a name="cronJobs_pattern1_serviceAccount_annotations"></a>4.1.41.1. Property `stack > cronJobs > ^.*$ > serviceAccount > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to the service account

##### <a name="cronJobs_pattern1_serviceAccount_automount"></a>4.1.41.2. Property `stack > cronJobs > ^.*$ > serviceAccount > automount`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Specifies whether to automatically mount a ServiceAccount's API credentials

##### <a name="cronJobs_pattern1_serviceAccount_create"></a>4.1.41.3. Property `stack > cronJobs > ^.*$ > serviceAccount > create`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Specifies whether a service account should be created

##### <a name="cronJobs_pattern1_serviceAccount_name"></a>4.1.41.4. Property `stack > cronJobs > ^.*$ > serviceAccount > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service account to use (if not set and create is true, a name is generated using the fullname template)

#### <a name="cronJobs_pattern1_shareProcessNamespace"></a>4.1.42. Property `stack > cronJobs > ^.*$ > shareProcessNamespace`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Share process namespace

#### <a name="cronJobs_pattern1_sidecars"></a>4.1.43. Property `stack > cronJobs > ^.*$ > sidecars`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of sidecars

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_startupProbe"></a>4.1.44. Property `stack > cronJobs > ^.*$ > startupProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Startup probe configuration

| Property                                                                      | Pattern | Type    | Deprecated | Definition | Title/Description                                                                     |
| ----------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_startupProbe_enabled )                         | No      | boolean | No         | -          | Enable the startup probe                                                              |
| - [exec](#cronJobs_pattern1_startupProbe_exec )                               | No      | object  | No         | -          | Exec probe configuration                                                              |
| - [failureThreshold](#cronJobs_pattern1_startupProbe_failureThreshold )       | No      | integer | No         | -          | Number of failures before the probe is considered failed                              |
| - [initialDelaySeconds](#cronJobs_pattern1_startupProbe_initialDelaySeconds ) | No      | integer | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_startupProbe_periodSeconds )             | No      | integer | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_startupProbe_successThreshold )       | No      | integer | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_startupProbe_timeoutSeconds )           | No      | integer | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_startupProbe_enabled"></a>4.1.44.1. Property `stack > cronJobs > ^.*$ > startupProbe > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable the startup probe

##### <a name="cronJobs_pattern1_startupProbe_exec"></a>4.1.44.2. Property `stack > cronJobs > ^.*$ > startupProbe > exec`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Exec probe configuration

| Property                                                   | Pattern | Type            | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------- |
| - [command](#cronJobs_pattern1_startupProbe_exec_command ) | No      | array of string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_startupProbe_exec_command"></a>4.1.44.2.1. Property `stack > cronJobs > ^.*$ > startupProbe > exec > command`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [command items](#cronJobs_pattern1_startupProbe_exec_command_items) | -           |

###### <a name="cronJobs_pattern1_startupProbe_exec_command_items"></a>4.1.44.2.1.1. stack > cronJobs > ^.*$ > startupProbe > exec > command > command items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_startupProbe_failureThreshold"></a>4.1.44.3. Property `stack > cronJobs > ^.*$ > startupProbe > failureThreshold`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_startupProbe_initialDelaySeconds"></a>4.1.44.4. Property `stack > cronJobs > ^.*$ > startupProbe > initialDelaySeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_startupProbe_periodSeconds"></a>4.1.44.5. Property `stack > cronJobs > ^.*$ > startupProbe > periodSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_startupProbe_successThreshold"></a>4.1.44.6. Property `stack > cronJobs > ^.*$ > startupProbe > successThreshold`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_startupProbe_timeoutSeconds"></a>4.1.44.7. Property `stack > cronJobs > ^.*$ > startupProbe > timeoutSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_tolerations"></a>4.1.45. Property `stack > cronJobs > ^.*$ > tolerations`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Tolerations for the pod

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_topologySpreadConstraints"></a>4.1.46. Property `stack > cronJobs > ^.*$ > topologySpreadConstraints`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Topology spread constraints for the pod

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_volumeMounts"></a>4.1.47. Property `stack > cronJobs > ^.*$ > volumeMounts`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional volume mounts on the output Deployment definition

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_volumes"></a>4.1.48. Property `stack > cronJobs > ^.*$ > volumes`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional volumes on the output Deployment definition

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

## <a name="rollout"></a>5. Property `stack > rollout`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                             | Pattern | Type   | Deprecated | Definition | Title/Description                                   |
| ------------------------------------ | ------- | ------ | ---------- | ---------- | --------------------------------------------------- |
| - [strategy](#rollout_strategy )     | No      | object | No         | -          | Specifies the rollout strategy for the application. |
| - [](#rollout_additionalProperties ) | No      | object | No         | -          | -                                                   |

### <a name="rollout_strategy"></a>5.1. Property `stack > rollout > strategy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

**Description:** Specifies the rollout strategy for the application.

| Property                                    | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [blueGreen](#rollout_strategy_blueGreen ) | No      | object | No         | -          | -                 |

#### <a name="rollout_strategy_blueGreen"></a>5.1.1. Property `stack > rollout > strategy > blueGreen`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

| Property                                                                    | Pattern | Type    | Deprecated | Definition                      | Title/Description                                                                                                       |
| --------------------------------------------------------------------------- | ------- | ------- | ---------- | ------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| - [activeService](#rollout_strategy_blueGreen_activeService )               | No      | string  | No         | -                               | Name of the service that the rollout modifies as the active service.                                                    |
| - [autoPromotionEnabled](#rollout_strategy_blueGreen_autoPromotionEnabled ) | No      | boolean | No         | -                               | indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state. |
| - [prePromotionAnalysis](#rollout_strategy_blueGreen_prePromotionAnalysis ) | No      | object  | No         | In #/properties/rolloutAnalysis | configuration to run analysis before a selector switch                                                                  |
| - [previewService](#rollout_strategy_blueGreen_previewService )             | No      | string  | No         | -                               | Name of the service that the rollout modifies as the preview service.                                                   |

##### <a name="rollout_strategy_blueGreen_activeService"></a>5.1.1.1. Property `stack > rollout > strategy > blueGreen > activeService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the active service.

##### <a name="rollout_strategy_blueGreen_autoPromotionEnabled"></a>5.1.1.2. Property `stack > rollout > strategy > blueGreen > autoPromotionEnabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state.

##### <a name="rollout_strategy_blueGreen_prePromotionAnalysis"></a>5.1.1.3. Property `stack > rollout > strategy > blueGreen > prePromotionAnalysis`

|                           |                              |
| ------------------------- | ---------------------------- |
| **Type**                  | `object`                     |
| **Required**              | No                           |
| **Additional properties** | Any type allowed             |
| **Defined in**            | #/properties/rolloutAnalysis |

**Description:** configuration to run analysis before a selector switch

| Property                                                                                                         | Pattern | Type            | Deprecated | Definition | Title/Description                                                       |
| ---------------------------------------------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------- |
| - [analysisRunMetadata](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata ) | No      | object          | No         | -          | extra labels to add to the AnalysisRun                                  |
| - [args](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args )                               | No      | array of object | No         | -          | the arguments that will be added to the AnalysisRuns                    |
| - [templates](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates )                     | No      | array of object | No         | -          | reference to a list of analysis templates to combine for an AnalysisRun |
| - [](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_additionalProperties )                   | No      | object          | No         | -          | -                                                                       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata"></a>5.1.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** extra labels to add to the AnalysisRun

| Property                                                                                                             | Pattern | Type   | Deprecated | Definition | Title/Description                                |
| -------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------ |
| - [annotations](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations ) | No      | object | No         | -          | additional annotations to add to the AnalysisRun |
| - [labels](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels )           | No      | object | No         | -          | additional labels to add to the AnalysisRun      |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations"></a>5.1.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional annotations to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels"></a>5.1.1.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional labels to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args"></a>5.1.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** the arguments that will be added to the AnalysisRuns

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                             | Description |
| ------------------------------------------------------------------------------------------- | ----------- |
| [args items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items"></a>5.1.1.3.2.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name )           | No      | string | No         | -          | -                 |
| - [value](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value )         | No      | string | No         | -          | -                 |
| - [valueFrom](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name"></a>5.1.1.3.2.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value"></a>5.1.1.3.2.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom"></a>5.1.1.3.2.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                                | Pattern | Type             | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [fieldRef](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef )                         | No      | object           | No         | -          | -                 |
| - [podTemplateHashValue](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue ) | No      | enum (of string) | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef"></a>5.1.1.3.2.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [fieldPath](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath"></a>5.1.1.3.2.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef > fieldPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue"></a>5.1.1.3.2.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > podTemplateHashValue`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "Latest"
* "Stable"

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates"></a>5.1.1.3.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** reference to a list of analysis templates to combine for an AnalysisRun

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                                       | Description |
| ----------------------------------------------------------------------------------------------------- | ----------- |
| [templates items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items"></a>5.1.1.3.3.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                           | Pattern | Type    | Deprecated | Definition | Title/Description                                                         |
| ------------------------------------------------------------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [clusterScope](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope ) | No      | boolean | No         | -          | Whether to look for the templateName at cluster scope or namespace scope. |
| - [templateName](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName ) | No      | string  | No         | -          |  name of the AnalysisTemplate to use for the rollout analysis             |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope"></a>5.1.1.3.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > clusterScope`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Whether to look for the templateName at cluster scope or namespace scope.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName"></a>5.1.1.3.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > templateName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:**  name of the AnalysisTemplate to use for the rollout analysis

##### <a name="rollout_strategy_blueGreen_previewService"></a>5.1.1.4. Property `stack > rollout > strategy > blueGreen > previewService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the preview service.

## <a name="rolloutAnalysis"></a>6. Property `stack > rolloutAnalysis`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** defines a template that is used to create a analysisRun

| Property                                                       | Pattern | Type            | Deprecated | Definition | Title/Description                                                       |
| -------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------- |
| - [analysisRunMetadata](#rolloutAnalysis_analysisRunMetadata ) | No      | object          | No         | -          | extra labels to add to the AnalysisRun                                  |
| - [args](#rolloutAnalysis_args )                               | No      | array of object | No         | -          | the arguments that will be added to the AnalysisRuns                    |
| - [templates](#rolloutAnalysis_templates )                     | No      | array of object | No         | -          | reference to a list of analysis templates to combine for an AnalysisRun |
| - [](#rolloutAnalysis_additionalProperties )                   | No      | object          | No         | -          | -                                                                       |

### <a name="rolloutAnalysis_analysisRunMetadata"></a>6.1. Property `stack > rolloutAnalysis > analysisRunMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** extra labels to add to the AnalysisRun

| Property                                                           | Pattern | Type   | Deprecated | Definition | Title/Description                                |
| ------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ------------------------------------------------ |
| - [annotations](#rolloutAnalysis_analysisRunMetadata_annotations ) | No      | object | No         | -          | additional annotations to add to the AnalysisRun |
| - [labels](#rolloutAnalysis_analysisRunMetadata_labels )           | No      | object | No         | -          | additional labels to add to the AnalysisRun      |

#### <a name="rolloutAnalysis_analysisRunMetadata_annotations"></a>6.1.1. Property `stack > rolloutAnalysis > analysisRunMetadata > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional annotations to add to the AnalysisRun

#### <a name="rolloutAnalysis_analysisRunMetadata_labels"></a>6.1.2. Property `stack > rolloutAnalysis > analysisRunMetadata > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional labels to add to the AnalysisRun

### <a name="rolloutAnalysis_args"></a>6.2. Property `stack > rolloutAnalysis > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** the arguments that will be added to the AnalysisRuns

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be           | Description |
| ----------------------------------------- | ----------- |
| [args items](#rolloutAnalysis_args_items) | -           |

#### <a name="rolloutAnalysis_args_items"></a>6.2.1. stack > rolloutAnalysis > args > args items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                              | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#rolloutAnalysis_args_items_name )           | No      | string | No         | -          | -                 |
| - [value](#rolloutAnalysis_args_items_value )         | No      | string | No         | -          | -                 |
| - [valueFrom](#rolloutAnalysis_args_items_valueFrom ) | No      | object | No         | -          | -                 |

##### <a name="rolloutAnalysis_args_items_name"></a>6.2.1.1. Property `stack > rolloutAnalysis > args > args items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="rolloutAnalysis_args_items_value"></a>6.2.1.2. Property `stack > rolloutAnalysis > args > args items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="rolloutAnalysis_args_items_valueFrom"></a>6.2.1.3. Property `stack > rolloutAnalysis > args > args items > valueFrom`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                              | Pattern | Type             | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [fieldRef](#rolloutAnalysis_args_items_valueFrom_fieldRef )                         | No      | object           | No         | -          | -                 |
| - [podTemplateHashValue](#rolloutAnalysis_args_items_valueFrom_podTemplateHashValue ) | No      | enum (of string) | No         | -          | -                 |

###### <a name="rolloutAnalysis_args_items_valueFrom_fieldRef"></a>6.2.1.3.1. Property `stack > rolloutAnalysis > args > args items > valueFrom > fieldRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                 | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------- |
| - [fieldPath](#rolloutAnalysis_args_items_valueFrom_fieldRef_fieldPath ) | No      | string | No         | -          | -                 |

###### <a name="rolloutAnalysis_args_items_valueFrom_fieldRef_fieldPath"></a>6.2.1.3.1.1. Property `stack > rolloutAnalysis > args > args items > valueFrom > fieldRef > fieldPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="rolloutAnalysis_args_items_valueFrom_podTemplateHashValue"></a>6.2.1.3.2. Property `stack > rolloutAnalysis > args > args items > valueFrom > podTemplateHashValue`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "Latest"
* "Stable"

### <a name="rolloutAnalysis_templates"></a>6.3. Property `stack > rolloutAnalysis > templates`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** reference to a list of analysis templates to combine for an AnalysisRun

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                     | Description |
| --------------------------------------------------- | ----------- |
| [templates items](#rolloutAnalysis_templates_items) | -           |

#### <a name="rolloutAnalysis_templates_items"></a>6.3.1. stack > rolloutAnalysis > templates > templates items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type    | Deprecated | Definition | Title/Description                                                         |
| ---------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [clusterScope](#rolloutAnalysis_templates_items_clusterScope ) | No      | boolean | No         | -          | Whether to look for the templateName at cluster scope or namespace scope. |
| - [templateName](#rolloutAnalysis_templates_items_templateName ) | No      | string  | No         | -          |  name of the AnalysisTemplate to use for the rollout analysis             |

##### <a name="rolloutAnalysis_templates_items_clusterScope"></a>6.3.1.1. Property `stack > rolloutAnalysis > templates > templates items > clusterScope`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Whether to look for the templateName at cluster scope or namespace scope.

##### <a name="rolloutAnalysis_templates_items_templateName"></a>6.3.1.2. Property `stack > rolloutAnalysis > templates > templates items > templateName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:**  name of the AnalysisTemplate to use for the rollout analysis

## <a name="services"></a>7. Property `stack > services`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Services to deploy

| Property                      | Pattern | Type   | Deprecated | Definition             | Title/Description                                                                                            |
| ----------------------------- | ------- | ------ | ---------- | ---------------------- | ------------------------------------------------------------------------------------------------------------ |
| - [^.*$](#services_pattern1 ) | Yes     | object | No         | In #/properties/global | Global configuration for the stack - this serves as the default configuration for all services/jobs/cronjobs |

### <a name="services_pattern1"></a>7.1. Pattern Property `stack > services > global`
> All properties whose name matches the regular expression
```^.*$``` ([Test](https://regex101.com/?regex=%5E.%2A%24))
must respect the following conditions

|                           |                     |
| ------------------------- | ------------------- |
| **Type**                  | `object`            |
| **Required**              | No                  |
| **Additional properties** | Any type allowed    |
| **Defined in**            | #/properties/global |

**Description:** Global configuration for the stack - this serves as the default configuration for all services/jobs/cronjobs

| Property                                                                     | Pattern | Type             | Deprecated | Definition              | Title/Description                                                                                                                                                                                                                                                                |
| ---------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [affinity](#cronJobs_pattern1_affinity )                                   | No      | object           | No         | -                       | Affinity for the pod                                                                                                                                                                                                                                                             |
| - [annotations](#cronJobs_pattern1_annotations )                             | No      | object           | No         | -                       | Global annotations to add to all resources                                                                                                                                                                                                                                       |
| - [appContext](#cronJobs_pattern1_appContext )                               | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [appSecrets](#cronJobs_pattern1_appSecrets )                               | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [argoBuildEnv](#cronJobs_pattern1_argoBuildEnv )                           | No      | object           | No         | -                       | Argo built-in environment parameters (provided by Argus API)                                                                                                                                                                                                                     |
| - [args](#cronJobs_pattern1_args )                                           | No      | array of string  | No         | -                       | Arguments to pass to the command in the primary container                                                                                                                                                                                                                        |
| - [argusMetadata](#cronJobs_pattern1_argusMetadata )                         | No      | object           | No         | -                       | Argus metadata (provided by Argus API)                                                                                                                                                                                                                                           |
| - [autoscaling](#cronJobs_pattern1_autoscaling )                             | No      | object           | No         | -                       | Autoscaling configuration                                                                                                                                                                                                                                                        |
| - [command](#cronJobs_pattern1_command )                                     | No      | array of string  | No         | -                       | Command to run in the primary container                                                                                                                                                                                                                                          |
| - [deploymentKind](#cronJobs_pattern1_deploymentKind )                       | No      | enum (of string) | No         | -                       | Specifies the Kubernetes Kind for the main application workload controller (Deployment or Rollout).                                                                                                                                                                              |
| - [deploymentStage](#cronJobs_pattern1_deploymentStage )                     | No      | string           | No         | -                       | Deployment stage                                                                                                                                                                                                                                                                 |
| - [dnsPolicy](#cronJobs_pattern1_dnsPolicy )                                 | No      | enum (of string) | No         | -                       | DNS policy for the pod                                                                                                                                                                                                                                                           |
| - [env](#cronJobs_pattern1_env )                                             | No      | array of object  | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [envFrom](#cronJobs_pattern1_envFrom )                                     | No      | array of object  | No         | -                       | Environment variables from configmaps or secrets                                                                                                                                                                                                                                 |
| - [fullnameOverride](#cronJobs_pattern1_fullnameOverride )                   | No      | string           | No         | -                       | Name to prefix the K8s resources with, replaces the stack name prefix                                                                                                                                                                                                            |
| - [gateway](#cronJobs_pattern1_gateway )                                     | No      | object           | No         | -                       | Gateway API HTTPRoute configuration                                                                                                                                                                                                                                              |
| - [grafanaDashboard](#cronJobs_pattern1_grafanaDashboard )                   | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [image](#cronJobs_pattern1_image )                                         | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [imagePullSecrets](#cronJobs_pattern1_imagePullSecrets )                   | No      | array of string  | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [ingress](#cronJobs_pattern1_ingress )                                     | No      | object           | No         | -                       | Ingress configuration                                                                                                                                                                                                                                                            |
| - [initContainers](#cronJobs_pattern1_initContainers )                       | No      | array            | No         | -                       | List of init containers                                                                                                                                                                                                                                                          |
| - [kedaAutoscaling](#cronJobs_pattern1_kedaAutoscaling )                     | No      | object           | No         | -                       | KEDA autoscaling configuration (creates a ScaledObject instead of HPA)                                                                                                                                                                                                           |
| - [livenessProbe](#cronJobs_pattern1_livenessProbe )                         | No      | object           | No         | -                       | Liveness probe configuration                                                                                                                                                                                                                                                     |
| - [nameOverride](#cronJobs_pattern1_nameOverride )                           | No      | string           | No         | -                       | Name to prefix the K8s resources with, combined with the stack name prefix                                                                                                                                                                                                       |
| - [nodeSelector](#cronJobs_pattern1_nodeSelector )                           | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [oidcProxy](#cronJobs_pattern1_oidcProxy )                                 | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [oidcProxyGateway](#cronJobs_pattern1_oidcProxyGateway )                   | No      | object           | No         | -                       | Native Envoy Gateway OIDC authentication configuration (used when gateway.oidcProtected is true). Requires explicit clientID and issuer configuration. clientSecret is auto-referenced from appSecrets. redirectURL is auto-generated as https://<gateway.host>/oauth2/callback. |
| - [persistence](#cronJobs_pattern1_persistence )                             | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [podAnnotations](#cronJobs_pattern1_podAnnotations )                       | No      | object           | No         | -                       | Annotations to add to pods                                                                                                                                                                                                                                                       |
| - [podLabels](#cronJobs_pattern1_podLabels )                                 | No      | object           | No         | -                       | Global labels to add to all pods                                                                                                                                                                                                                                                 |
| - [podSecurityContext](#cronJobs_pattern1_podSecurityContext )               | No      | object           | No         | -                       | Pod security context                                                                                                                                                                                                                                                             |
| - [progressDeadlineSeconds](#cronJobs_pattern1_progressDeadlineSeconds )     | No      | integer          | No         | -                       | the number of seconds the Deployment controller waits before indicating (in the Deployment status) that the Deployment progress has stalled                                                                                                                                      |
| - [readinessProbe](#cronJobs_pattern1_readinessProbe )                       | No      | object           | No         | -                       | Readiness probe configuration                                                                                                                                                                                                                                                    |
| - [replicaCount](#cronJobs_pattern1_replicaCount )                           | No      | integer          | No         | -                       | Number of replicas                                                                                                                                                                                                                                                               |
| - [resources](#cronJobs_pattern1_resources )                                 | No      | object           | No         | -                       | Resource requests and limits for the primary container                                                                                                                                                                                                                           |
| - [restartPolicy](#cronJobs_pattern1_restartPolicy )                         | No      | enum (of string) | No         | -                       | Restart policy for the pod                                                                                                                                                                                                                                                       |
| - [rollout](#cronJobs_pattern1_rollout )                                     | No      | object           | No         | In #/properties/rollout | -                                                                                                                                                                                                                                                                                |
| - [s3Storage](#cronJobs_pattern1_s3Storage )                                 | No      | object           | No         | -                       | -                                                                                                                                                                                                                                                                                |
| - [securityContext](#cronJobs_pattern1_securityContext )                     | No      | object           | No         | -                       | Security context                                                                                                                                                                                                                                                                 |
| - [service](#cronJobs_pattern1_service )                                     | No      | object           | No         | -                       | Service configuration                                                                                                                                                                                                                                                            |
| - [serviceAccount](#cronJobs_pattern1_serviceAccount )                       | No      | object           | No         | -                       | Service account configuration                                                                                                                                                                                                                                                    |
| - [shareProcessNamespace](#cronJobs_pattern1_shareProcessNamespace )         | No      | boolean          | No         | -                       | Share process namespace                                                                                                                                                                                                                                                          |
| - [sidecars](#cronJobs_pattern1_sidecars )                                   | No      | array            | No         | -                       | List of sidecars                                                                                                                                                                                                                                                                 |
| - [startupProbe](#cronJobs_pattern1_startupProbe )                           | No      | object           | No         | -                       | Startup probe configuration                                                                                                                                                                                                                                                      |
| - [tolerations](#cronJobs_pattern1_tolerations )                             | No      | array            | No         | -                       | Tolerations for the pod                                                                                                                                                                                                                                                          |
| - [topologySpreadConstraints](#cronJobs_pattern1_topologySpreadConstraints ) | No      | array            | No         | -                       | Topology spread constraints for the pod                                                                                                                                                                                                                                          |
| - [volumeMounts](#cronJobs_pattern1_volumeMounts )                           | No      | array            | No         | -                       | Additional volume mounts on the output Deployment definition                                                                                                                                                                                                                     |
| - [volumes](#cronJobs_pattern1_volumes )                                     | No      | array            | No         | -                       | Additional volumes on the output Deployment definition                                                                                                                                                                                                                           |

#### <a name="cronJobs_pattern1_affinity"></a>7.1.1. Property `stack > cronJobs > ^.*$ > affinity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Affinity for the pod

#### <a name="cronJobs_pattern1_annotations"></a>7.1.2. Property `stack > cronJobs > ^.*$ > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global annotations to add to all resources

#### <a name="cronJobs_pattern1_appContext"></a>7.1.3. Property `stack > cronJobs > ^.*$ > appContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [envContextConfigMapName](#cronJobs_pattern1_appContext_envContextConfigMapName )     | No      | string | No         | -          | -                 |
| - [stackContextConfigMapName](#cronJobs_pattern1_appContext_stackContextConfigMapName ) | No      | string | No         | -          | -                 |

##### <a name="cronJobs_pattern1_appContext_envContextConfigMapName"></a>7.1.3.1. Property `stack > cronJobs > ^.*$ > appContext > envContextConfigMapName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appContext_stackContextConfigMapName"></a>7.1.3.2. Property `stack > cronJobs > ^.*$ > appContext > stackContextConfigMapName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_appSecrets"></a>7.1.4. Property `stack > cronJobs > ^.*$ > appSecrets`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [clusterSecret](#cronJobs_pattern1_appSecrets_clusterSecret ) | No      | object | No         | -          | -                 |
| - [envSecret](#cronJobs_pattern1_appSecrets_envSecret )         | No      | object | No         | -          | -                 |
| - [stackSecret](#cronJobs_pattern1_appSecrets_stackSecret )     | No      | object | No         | -          | -                 |

##### <a name="cronJobs_pattern1_appSecrets_clusterSecret"></a>7.1.4.1. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_clusterSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_clusterSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_clusterSecret_secretKey"></a>7.1.4.1.1. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_clusterSecret_secretName"></a>7.1.4.1.2. Property `stack > cronJobs > ^.*$ > appSecrets > clusterSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appSecrets_envSecret"></a>7.1.4.2. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_envSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_envSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_envSecret_secretKey"></a>7.1.4.2.1. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_envSecret_secretName"></a>7.1.4.2.2. Property `stack > cronJobs > ^.*$ > appSecrets > envSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_appSecrets_stackSecret"></a>7.1.4.3. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                              | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [secretKey](#cronJobs_pattern1_appSecrets_stackSecret_secretKey )   | No      | string | No         | -          | -                 |
| - [secretName](#cronJobs_pattern1_appSecrets_stackSecret_secretName ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_appSecrets_stackSecret_secretKey"></a>7.1.4.3.1. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret > secretKey`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_appSecrets_stackSecret_secretName"></a>7.1.4.3.2. Property `stack > cronJobs > ^.*$ > appSecrets > stackSecret > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_argoBuildEnv"></a>7.1.5. Property `stack > cronJobs > ^.*$ > argoBuildEnv`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Argo built-in environment parameters (provided by Argus API)

| Property                                                                              | Pattern | Type   | Deprecated | Definition | Title/Description                                                                         |
| ------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------------------------------------------------------------- |
| - [appName](#cronJobs_pattern1_argoBuildEnv_appName )                                 | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_NAME (this is the ArgoCD app name, not the Argus app name) |
| - [appNamespace](#cronJobs_pattern1_argoBuildEnv_appNamespace )                       | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_NAMESPACE                                                  |
| - [appRevision](#cronJobs_pattern1_argoBuildEnv_appRevision )                         | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION                                                   |
| - [appRevisionShort](#cronJobs_pattern1_argoBuildEnv_appRevisionShort )               | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION_SHORT                                             |
| - [appRevisionShort8](#cronJobs_pattern1_argoBuildEnv_appRevisionShort8 )             | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_REVISION_SHORT_8                                           |
| - [appSourcePath](#cronJobs_pattern1_argoBuildEnv_appSourcePath )                     | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_PATH                                                |
| - [appSourceRepoUrl](#cronJobs_pattern1_argoBuildEnv_appSourceRepoUrl )               | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL                                            |
| - [appSourceTargetRevision](#cronJobs_pattern1_argoBuildEnv_appSourceTargetRevision ) | No      | string | No         | -          | Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL                                            |

##### <a name="cronJobs_pattern1_argoBuildEnv_appName"></a>7.1.5.1. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_NAME (this is the ArgoCD app name, not the Argus app name)

##### <a name="cronJobs_pattern1_argoBuildEnv_appNamespace"></a>7.1.5.2. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appNamespace`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_NAMESPACE

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevision"></a>7.1.5.3. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevision`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevisionShort"></a>7.1.5.4. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevisionShort`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION_SHORT

##### <a name="cronJobs_pattern1_argoBuildEnv_appRevisionShort8"></a>7.1.5.5. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appRevisionShort8`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_REVISION_SHORT_8

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourcePath"></a>7.1.5.6. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourcePath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_PATH

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourceRepoUrl"></a>7.1.5.7. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourceRepoUrl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL

##### <a name="cronJobs_pattern1_argoBuildEnv_appSourceTargetRevision"></a>7.1.5.8. Property `stack > cronJobs > ^.*$ > argoBuildEnv > appSourceTargetRevision`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to ARGOCD_APP_SOURCE_REPO_URL

#### <a name="cronJobs_pattern1_args"></a>7.1.6. Property `stack > cronJobs > ^.*$ > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Arguments to pass to the command in the primary container

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be             | Description |
| ------------------------------------------- | ----------- |
| [args items](#cronJobs_pattern1_args_items) | -           |

##### <a name="cronJobs_pattern1_args_items"></a>7.1.6.1. stack > cronJobs > ^.*$ > args > args items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_argusMetadata"></a>7.1.7. Property `stack > cronJobs > ^.*$ > argusMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Argus metadata (provided by Argus API)

| Property                                                   | Pattern | Type   | Deprecated | Definition | Title/Description                          |
| ---------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------ |
| - [appName](#cronJobs_pattern1_argusMetadata_appName )     | No      | string | No         | -          | Set by Argus API to Argus app name         |
| - [envName](#cronJobs_pattern1_argusMetadata_envName )     | No      | string | No         | -          | Set by Argus API to Argus environment name |
| - [repoName](#cronJobs_pattern1_argusMetadata_repoName )   | No      | string | No         | -          | Set by Argus API to Argus repository name  |
| - [repoOwner](#cronJobs_pattern1_argusMetadata_repoOwner ) | No      | string | No         | -          | Set by Argus API to Argus repository owner |
| - [stackName](#cronJobs_pattern1_argusMetadata_stackName ) | No      | string | No         | -          | Set by Argus API to Argus stack name       |

##### <a name="cronJobs_pattern1_argusMetadata_appName"></a>7.1.7.1. Property `stack > cronJobs > ^.*$ > argusMetadata > appName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus app name

##### <a name="cronJobs_pattern1_argusMetadata_envName"></a>7.1.7.2. Property `stack > cronJobs > ^.*$ > argusMetadata > envName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus environment name

##### <a name="cronJobs_pattern1_argusMetadata_repoName"></a>7.1.7.3. Property `stack > cronJobs > ^.*$ > argusMetadata > repoName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus repository name

##### <a name="cronJobs_pattern1_argusMetadata_repoOwner"></a>7.1.7.4. Property `stack > cronJobs > ^.*$ > argusMetadata > repoOwner`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus repository owner

##### <a name="cronJobs_pattern1_argusMetadata_stackName"></a>7.1.7.5. Property `stack > cronJobs > ^.*$ > argusMetadata > stackName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Set by Argus API to Argus stack name

#### <a name="cronJobs_pattern1_autoscaling"></a>7.1.8. Property `stack > cronJobs > ^.*$ > autoscaling`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Autoscaling configuration

| Property                                                                                                 | Pattern | Type    | Deprecated | Definition | Title/Description                    |
| -------------------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------ |
| - [enabled](#cronJobs_pattern1_autoscaling_enabled )                                                     | No      | boolean | No         | -          | Enable autoscaling                   |
| - [maxReplicas](#cronJobs_pattern1_autoscaling_maxReplicas )                                             | No      | integer | No         | -          | Maximum number of replicas           |
| - [minReplicas](#cronJobs_pattern1_autoscaling_minReplicas )                                             | No      | integer | No         | -          | Minimum number of replicas           |
| - [targetCPUUtilizationPercentage](#cronJobs_pattern1_autoscaling_targetCPUUtilizationPercentage )       | No      | integer | No         | -          | Target CPU utilization percentage    |
| - [targetMemoryUtilizationPercentage](#cronJobs_pattern1_autoscaling_targetMemoryUtilizationPercentage ) | No      | integer | No         | -          | Target memory utilization percentage |

##### <a name="cronJobs_pattern1_autoscaling_enabled"></a>7.1.8.1. Property `stack > cronJobs > ^.*$ > autoscaling > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable autoscaling

##### <a name="cronJobs_pattern1_autoscaling_maxReplicas"></a>7.1.8.2. Property `stack > cronJobs > ^.*$ > autoscaling > maxReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Maximum number of replicas

##### <a name="cronJobs_pattern1_autoscaling_minReplicas"></a>7.1.8.3. Property `stack > cronJobs > ^.*$ > autoscaling > minReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Minimum number of replicas

##### <a name="cronJobs_pattern1_autoscaling_targetCPUUtilizationPercentage"></a>7.1.8.4. Property `stack > cronJobs > ^.*$ > autoscaling > targetCPUUtilizationPercentage`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Target CPU utilization percentage

##### <a name="cronJobs_pattern1_autoscaling_targetMemoryUtilizationPercentage"></a>7.1.8.5. Property `stack > cronJobs > ^.*$ > autoscaling > targetMemoryUtilizationPercentage`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Target memory utilization percentage

#### <a name="cronJobs_pattern1_command"></a>7.1.9. Property `stack > cronJobs > ^.*$ > command`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Command to run in the primary container

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                   | Description |
| ------------------------------------------------- | ----------- |
| [command items](#cronJobs_pattern1_command_items) | -           |

##### <a name="cronJobs_pattern1_command_items"></a>7.1.9.1. stack > cronJobs > ^.*$ > command > command items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_deploymentKind"></a>7.1.10. Property `stack > cronJobs > ^.*$ > deploymentKind`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |
| **Default**  | `"Deployment"`     |

**Description:** Specifies the Kubernetes Kind for the main application workload controller (Deployment or Rollout).

Must be one of:
* "Deployment"
* "Rollout"

#### <a name="cronJobs_pattern1_deploymentStage"></a>7.1.11. Property `stack > cronJobs > ^.*$ > deploymentStage`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Deployment stage

#### <a name="cronJobs_pattern1_dnsPolicy"></a>7.1.12. Property `stack > cronJobs > ^.*$ > dnsPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** DNS policy for the pod

Must be one of:
* "ClusterFirst"
* "Default"
* "None"

#### <a name="cronJobs_pattern1_env"></a>7.1.13. Property `stack > cronJobs > ^.*$ > env`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be           | Description |
| ----------------------------------------- | ----------- |
| [env items](#cronJobs_pattern1_env_items) | -           |

##### <a name="cronJobs_pattern1_env_items"></a>7.1.13.1. stack > cronJobs > ^.*$ > env > env items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_env_items_name )   | No      | string | No         | -          | -                 |
| - [value](#cronJobs_pattern1_env_items_value ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_env_items_name"></a>7.1.13.1.1. Property `stack > cronJobs > ^.*$ > env > env items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_env_items_value"></a>7.1.13.1.2. Property `stack > cronJobs > ^.*$ > env > env items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_envFrom"></a>7.1.14. Property `stack > cronJobs > ^.*$ > envFrom`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Environment variables from configmaps or secrets

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                   | Description |
| ------------------------------------------------- | ----------- |
| [envFrom items](#cronJobs_pattern1_envFrom_items) | -           |

##### <a name="cronJobs_pattern1_envFrom_items"></a>7.1.14.1. stack > cronJobs > ^.*$ > envFrom > envFrom items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [configMapRef](#cronJobs_pattern1_envFrom_items_configMapRef ) | No      | object | No         | -          | -                 |
| - [prefix](#cronJobs_pattern1_envFrom_items_prefix )             | No      | string | No         | -          | -                 |
| - [secretRef](#cronJobs_pattern1_envFrom_items_secretRef )       | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_envFrom_items_configMapRef"></a>7.1.14.1.1. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > configMapRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_envFrom_items_prefix"></a>7.1.14.1.2. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > prefix`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_envFrom_items_secretRef"></a>7.1.14.1.3. Property `stack > cronJobs > ^.*$ > envFrom > envFrom items > secretRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

#### <a name="cronJobs_pattern1_fullnameOverride"></a>7.1.15. Property `stack > cronJobs > ^.*$ > fullnameOverride`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name to prefix the K8s resources with, replaces the stack name prefix

#### <a name="cronJobs_pattern1_gateway"></a>7.1.16. Property `stack > cronJobs > ^.*$ > gateway`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Gateway API HTTPRoute configuration

| Property                                                           | Pattern | Type            | Deprecated | Definition | Title/Description                                                                                                                                                                                                                                                   |
| ------------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_gateway_annotations )           | No      | object          | No         | -          | Annotations to add to HTTPRoute resources                                                                                                                                                                                                                           |
| - [backendTLS](#cronJobs_pattern1_gateway_backendTLS )             | No      | object          | No         | -          | TLS to the upstream Service via a BackendTLSPolicy (gateway.networking.k8s.io/v1)                                                                                                                                                                                   |
| - [basicAuth](#cronJobs_pattern1_gateway_basicAuth )               | No      | object          | No         | -          | HTTP basic auth via a SecurityPolicy. Mutually exclusive with gateway.oidcProtected                                                                                                                                                                                 |
| - [cors](#cronJobs_pattern1_gateway_cors )                         | No      | object          | No         | -          | CORS via a SecurityPolicy                                                                                                                                                                                                                                           |
| - [enabled](#cronJobs_pattern1_gateway_enabled )                   | No      | boolean         | No         | -          | Enable Gateway API HTTPRoute (alternative to Ingress)                                                                                                                                                                                                               |
| - [gatewayName](#cronJobs_pattern1_gateway_gatewayName )           | No      | string          | No         | -          | Name of the Gateway resource to attach to                                                                                                                                                                                                                           |
| - [gatewayNamespace](#cronJobs_pattern1_gateway_gatewayNamespace ) | No      | string          | No         | -          | Namespace of the Gateway resource                                                                                                                                                                                                                                   |
| - [host](#cronJobs_pattern1_gateway_host )                         | No      | string          | No         | -          | Hostname for HTTPRoute                                                                                                                                                                                                                                              |
| - [hostRewrite](#cronJobs_pattern1_gateway_hostRewrite )           | No      | string          | No         | -          | Rewrite the Host header sent upstream via an HTTPRoute URLRewrite filter, empty disables it                                                                                                                                                                         |
| - [ipAllowList](#cronJobs_pattern1_gateway_ipAllowList )           | No      | array           | No         | -          | Client IP allowlist of CIDRs that renders a SecurityPolicy authorization rule (defaultAction Deny). Empty disables it                                                                                                                                               |
| - [oidcProtected](#cronJobs_pattern1_gateway_oidcProtected )       | No      | boolean         | No         | -          | Enable OIDC protection via Envoy Gateway SecurityPolicy (requires oidcProxyGateway configuration)                                                                                                                                                                   |
| - [paths](#cronJobs_pattern1_gateway_paths )                       | No      | array of object | No         | -          | List of HTTPRoute paths                                                                                                                                                                                                                                             |
| - [rateLimit](#cronJobs_pattern1_gateway_rateLimit )               | No      | object          | No         | -          | Local rate limit via a BackendTrafficPolicy (Envoy local token bucket, no burst concept)                                                                                                                                                                            |
| - [redirect](#cronJobs_pattern1_gateway_redirect )                 | No      | object          | No         | -          | Whole-route redirect via an HTTPRoute RequestRedirect filter, replaces backend routing for the host                                                                                                                                                                 |
| - [requestHeaders](#cronJobs_pattern1_gateway_requestHeaders )     | No      | object          | No         | -          | Request header modifications (HTTPRoute RequestHeaderModifier filter)                                                                                                                                                                                               |
| - [responseHeaders](#cronJobs_pattern1_gateway_responseHeaders )   | No      | object          | No         | -          | Response header modifications (HTTPRoute ResponseHeaderModifier filter)                                                                                                                                                                                             |
| - [rules](#cronJobs_pattern1_gateway_rules )                       | No      | array           | No         | -          | List of additional HTTPRoute rules with custom hosts. Each entry takes host, optional paths, and an optional vanity block (enabled, hostname, clusterIssuer) that renders a per-host ListenerSet so the extra host can be a vanity domain, mirroring gateway.vanity |
| - [sectionName](#cronJobs_pattern1_gateway_sectionName )           | No      | string          | No         | -          | Optional section name (listener name) on the Gateway                                                                                                                                                                                                                |
| - [sessionAffinity](#cronJobs_pattern1_gateway_sessionAffinity )   | No      | object          | No         | -          | Cookie-based sticky sessions via a BackendTrafficPolicy. Off by default (the ingress cookie-affinity default is not carried to the gateway)                                                                                                                         |
| - [timeouts](#cronJobs_pattern1_gateway_timeouts )                 | No      | object          | No         | -          | HTTPRoute timeouts. request maps to nginx proxy-read and send-timeout. connect (optional) renders a BackendTrafficPolicy                                                                                                                                            |
| - [tlsPassthrough](#cronJobs_pattern1_gateway_tlsPassthrough )     | No      | object          | No         | -          | TLS passthrough via a TLSRoute (the Gateway does not terminate TLS). Mutually exclusive with the L7 gateway features, and requires a Passthrough listener on the shared Gateway                                                                                     |
| - [vanity](#cronJobs_pattern1_gateway_vanity )                     | No      | object          | No         | -          | Self-serve public/vanity-domain TLS via a tenant-owned Gateway API ListenerSet (requires Envoy Gateway >= v1.8 and cert-manager >= v1.20)                                                                                                                           |

##### <a name="cronJobs_pattern1_gateway_annotations"></a>7.1.16.1. Property `stack > cronJobs > ^.*$ > gateway > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to HTTPRoute resources

| Property                                                                                                            | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [external-dns.alpha.kubernetes.io/ttl](#cronJobs_pattern1_gateway_annotations_external-dnsalphakubernetesio/ttl ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_gateway_annotations_external-dnsalphakubernetesio/ttl"></a>7.1.16.1.1. Property `stack > cronJobs > ^.*$ > gateway > annotations > external-dns.alpha.kubernetes.io/ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_gateway_backendTLS"></a>7.1.16.2. Property `stack > cronJobs > ^.*$ > gateway > backendTLS`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** TLS to the upstream Service via a BackendTLSPolicy (gateway.networking.k8s.io/v1)

| Property                                                                                    | Pattern | Type    | Deprecated | Definition | Title/Description                                                                |
| ------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | -------------------------------------------------------------------------------- |
| - [caCertificateRefs](#cronJobs_pattern1_gateway_backendTLS_caCertificateRefs )             | No      | array   | No         | -          | ConfigMap refs holding the CA bundle for self-signed/internal upstreams          |
| - [enabled](#cronJobs_pattern1_gateway_backendTLS_enabled )                                 | No      | boolean | No         | -          | Enable upstream TLS                                                              |
| - [hostname](#cronJobs_pattern1_gateway_backendTLS_hostname )                               | No      | string  | No         | -          | SNI/validation hostname presented by the upstream (required when enabled)        |
| - [wellKnownCACertificates](#cronJobs_pattern1_gateway_backendTLS_wellKnownCACertificates ) | No      | string  | No         | -          | Use the System trust store, or set "" and use caCertificateRefs for a private CA |

###### <a name="cronJobs_pattern1_gateway_backendTLS_caCertificateRefs"></a>7.1.16.2.1. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > caCertificateRefs`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** ConfigMap refs holding the CA bundle for self-signed/internal upstreams

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_backendTLS_enabled"></a>7.1.16.2.2. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable upstream TLS

###### <a name="cronJobs_pattern1_gateway_backendTLS_hostname"></a>7.1.16.2.3. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** SNI/validation hostname presented by the upstream (required when enabled)

###### <a name="cronJobs_pattern1_gateway_backendTLS_wellKnownCACertificates"></a>7.1.16.2.4. Property `stack > cronJobs > ^.*$ > gateway > backendTLS > wellKnownCACertificates`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Use the System trust store, or set "" and use caCertificateRefs for a private CA

##### <a name="cronJobs_pattern1_gateway_basicAuth"></a>7.1.16.3. Property `stack > cronJobs > ^.*$ > gateway > basicAuth`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP basic auth via a SecurityPolicy. Mutually exclusive with gateway.oidcProtected

| Property                                                         | Pattern | Type    | Deprecated | Definition | Title/Description                             |
| ---------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | --------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_basicAuth_enabled )       | No      | boolean | No         | -          | Enable basic auth                             |
| - [secretName](#cronJobs_pattern1_gateway_basicAuth_secretName ) | No      | string  | No         | -          | Name of an Opaque Secret with a .htpasswd key |

###### <a name="cronJobs_pattern1_gateway_basicAuth_enabled"></a>7.1.16.3.1. Property `stack > cronJobs > ^.*$ > gateway > basicAuth > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable basic auth

###### <a name="cronJobs_pattern1_gateway_basicAuth_secretName"></a>7.1.16.3.2. Property `stack > cronJobs > ^.*$ > gateway > basicAuth > secretName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of an Opaque Secret with a .htpasswd key

##### <a name="cronJobs_pattern1_gateway_cors"></a>7.1.16.4. Property `stack > cronJobs > ^.*$ > gateway > cors`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CORS via a SecurityPolicy

| Property                                                                | Pattern | Type    | Deprecated | Definition | Title/Description                                    |
| ----------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------------------------------------- |
| - [allowCredentials](#cronJobs_pattern1_gateway_cors_allowCredentials ) | No      | boolean | No         | -          | Allow credentials                                    |
| - [allowHeaders](#cronJobs_pattern1_gateway_cors_allowHeaders )         | No      | array   | No         | -          | Allowed request headers                              |
| - [allowMethods](#cronJobs_pattern1_gateway_cors_allowMethods )         | No      | array   | No         | -          | Allowed methods                                      |
| - [allowOrigins](#cronJobs_pattern1_gateway_cors_allowOrigins )         | No      | array   | No         | -          | Allowed origins (string patterns)                    |
| - [enabled](#cronJobs_pattern1_gateway_cors_enabled )                   | No      | boolean | No         | -          | Enable CORS                                          |
| - [exposeHeaders](#cronJobs_pattern1_gateway_cors_exposeHeaders )       | No      | array   | No         | -          | Response headers exposed to the browser              |
| - [maxAge](#cronJobs_pattern1_gateway_cors_maxAge )                     | No      | string  | No         | -          | Preflight cache duration (e.g. "1h"), empty omits it |

###### <a name="cronJobs_pattern1_gateway_cors_allowCredentials"></a>7.1.16.4.1. Property `stack > cronJobs > ^.*$ > gateway > cors > allowCredentials`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Allow credentials

###### <a name="cronJobs_pattern1_gateway_cors_allowHeaders"></a>7.1.16.4.2. Property `stack > cronJobs > ^.*$ > gateway > cors > allowHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed request headers

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_allowMethods"></a>7.1.16.4.3. Property `stack > cronJobs > ^.*$ > gateway > cors > allowMethods`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed methods

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_allowOrigins"></a>7.1.16.4.4. Property `stack > cronJobs > ^.*$ > gateway > cors > allowOrigins`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Allowed origins (string patterns)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_enabled"></a>7.1.16.4.5. Property `stack > cronJobs > ^.*$ > gateway > cors > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable CORS

###### <a name="cronJobs_pattern1_gateway_cors_exposeHeaders"></a>7.1.16.4.6. Property `stack > cronJobs > ^.*$ > gateway > cors > exposeHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Response headers exposed to the browser

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_cors_maxAge"></a>7.1.16.4.7. Property `stack > cronJobs > ^.*$ > gateway > cors > maxAge`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Preflight cache duration (e.g. "1h"), empty omits it

##### <a name="cronJobs_pattern1_gateway_enabled"></a>7.1.16.5. Property `stack > cronJobs > ^.*$ > gateway > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable Gateway API HTTPRoute (alternative to Ingress)

##### <a name="cronJobs_pattern1_gateway_gatewayName"></a>7.1.16.6. Property `stack > cronJobs > ^.*$ > gateway > gatewayName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the Gateway resource to attach to

##### <a name="cronJobs_pattern1_gateway_gatewayNamespace"></a>7.1.16.7. Property `stack > cronJobs > ^.*$ > gateway > gatewayNamespace`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Namespace of the Gateway resource

##### <a name="cronJobs_pattern1_gateway_host"></a>7.1.16.8. Property `stack > cronJobs > ^.*$ > gateway > host`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Hostname for HTTPRoute

##### <a name="cronJobs_pattern1_gateway_hostRewrite"></a>7.1.16.9. Property `stack > cronJobs > ^.*$ > gateway > hostRewrite`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Rewrite the Host header sent upstream via an HTTPRoute URLRewrite filter, empty disables it

##### <a name="cronJobs_pattern1_gateway_ipAllowList"></a>7.1.16.10. Property `stack > cronJobs > ^.*$ > gateway > ipAllowList`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Client IP allowlist of CIDRs that renders a SecurityPolicy authorization rule (defaultAction Deny). Empty disables it

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_oidcProtected"></a>7.1.16.11. Property `stack > cronJobs > ^.*$ > gateway > oidcProtected`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC protection via Envoy Gateway SecurityPolicy (requires oidcProxyGateway configuration)

##### <a name="cronJobs_pattern1_gateway_paths"></a>7.1.16.12. Property `stack > cronJobs > ^.*$ > gateway > paths`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of HTTPRoute paths

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                       | Description |
| ----------------------------------------------------- | ----------- |
| [paths items](#cronJobs_pattern1_gateway_paths_items) | -           |

###### <a name="cronJobs_pattern1_gateway_paths_items"></a>7.1.16.12.1. stack > cronJobs > ^.*$ > gateway > paths > paths items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                     |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------- |
| - [path](#cronJobs_pattern1_gateway_paths_items_path )         | No      | string | No         | -          | HTTPRoute path                        |
| - [pathType](#cronJobs_pattern1_gateway_paths_items_pathType ) | No      | string | No         | -          | HTTPRoute path type (Exact or Prefix) |

###### <a name="cronJobs_pattern1_gateway_paths_items_path"></a>7.1.16.12.1.1. Property `stack > cronJobs > ^.*$ > gateway > paths > paths items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** HTTPRoute path

###### <a name="cronJobs_pattern1_gateway_paths_items_pathType"></a>7.1.16.12.1.2. Property `stack > cronJobs > ^.*$ > gateway > paths > paths items > pathType`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** HTTPRoute path type (Exact or Prefix)

##### <a name="cronJobs_pattern1_gateway_rateLimit"></a>7.1.16.13. Property `stack > cronJobs > ^.*$ > gateway > rateLimit`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Local rate limit via a BackendTrafficPolicy (Envoy local token bucket, no burst concept)

| Property                                                     | Pattern | Type    | Deprecated | Definition | Title/Description                           |
| ------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_rateLimit_enabled )   | No      | boolean | No         | -          | Enable local rate limiting                  |
| - [requests](#cronJobs_pattern1_gateway_rateLimit_requests ) | No      | integer | No         | -          | Allowed requests per unit                   |
| - [unit](#cronJobs_pattern1_gateway_rateLimit_unit )         | No      | string  | No         | -          | Rate limit unit (Second, Minute, Hour, Day) |

###### <a name="cronJobs_pattern1_gateway_rateLimit_enabled"></a>7.1.16.13.1. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable local rate limiting

###### <a name="cronJobs_pattern1_gateway_rateLimit_requests"></a>7.1.16.13.2. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > requests`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Allowed requests per unit

###### <a name="cronJobs_pattern1_gateway_rateLimit_unit"></a>7.1.16.13.3. Property `stack > cronJobs > ^.*$ > gateway > rateLimit > unit`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Rate limit unit (Second, Minute, Hour, Day)

##### <a name="cronJobs_pattern1_gateway_redirect"></a>7.1.16.14. Property `stack > cronJobs > ^.*$ > gateway > redirect`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Whole-route redirect via an HTTPRoute RequestRedirect filter, replaces backend routing for the host

| Property                                                        | Pattern | Type    | Deprecated | Definition | Title/Description                                               |
| --------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | --------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_redirect_enabled )       | No      | boolean | No         | -          | Enable a redirect-only route                                    |
| - [hostname](#cronJobs_pattern1_gateway_redirect_hostname )     | No      | string  | No         | -          | Target hostname, empty keeps the request host                   |
| - [path](#cronJobs_pattern1_gateway_redirect_path )             | No      | string  | No         | -          | Replacement full path via ReplaceFullPath, empty keeps the path |
| - [scheme](#cronJobs_pattern1_gateway_redirect_scheme )         | No      | string  | No         | -          | Target scheme, e.g. https                                       |
| - [statusCode](#cronJobs_pattern1_gateway_redirect_statusCode ) | No      | integer | No         | -          | Redirect status code (301 or 302)                               |

###### <a name="cronJobs_pattern1_gateway_redirect_enabled"></a>7.1.16.14.1. Property `stack > cronJobs > ^.*$ > gateway > redirect > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable a redirect-only route

###### <a name="cronJobs_pattern1_gateway_redirect_hostname"></a>7.1.16.14.2. Property `stack > cronJobs > ^.*$ > gateway > redirect > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Target hostname, empty keeps the request host

###### <a name="cronJobs_pattern1_gateway_redirect_path"></a>7.1.16.14.3. Property `stack > cronJobs > ^.*$ > gateway > redirect > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Replacement full path via ReplaceFullPath, empty keeps the path

###### <a name="cronJobs_pattern1_gateway_redirect_scheme"></a>7.1.16.14.4. Property `stack > cronJobs > ^.*$ > gateway > redirect > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Target scheme, e.g. https

###### <a name="cronJobs_pattern1_gateway_redirect_statusCode"></a>7.1.16.14.5. Property `stack > cronJobs > ^.*$ > gateway > redirect > statusCode`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Redirect status code (301 or 302)

##### <a name="cronJobs_pattern1_gateway_requestHeaders"></a>7.1.16.15. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Request header modifications (HTTPRoute RequestHeaderModifier filter)

| Property                                                      | Pattern | Type  | Deprecated | Definition | Title/Description                    |
| ------------------------------------------------------------- | ------- | ----- | ---------- | ---------- | ------------------------------------ |
| - [add](#cronJobs_pattern1_gateway_requestHeaders_add )       | No      | array | No         | -          | Headers to add, list of {name,value} |
| - [remove](#cronJobs_pattern1_gateway_requestHeaders_remove ) | No      | array | No         | -          | Header names to remove               |
| - [set](#cronJobs_pattern1_gateway_requestHeaders_set )       | No      | array | No         | -          | Headers to set, list of {name,value} |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_add"></a>7.1.16.15.1. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > add`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to add, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_remove"></a>7.1.16.15.2. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > remove`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Header names to remove

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_requestHeaders_set"></a>7.1.16.15.3. Property `stack > cronJobs > ^.*$ > gateway > requestHeaders > set`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to set, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_responseHeaders"></a>7.1.16.16. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Response header modifications (HTTPRoute ResponseHeaderModifier filter)

| Property                                                       | Pattern | Type  | Deprecated | Definition | Title/Description                    |
| -------------------------------------------------------------- | ------- | ----- | ---------- | ---------- | ------------------------------------ |
| - [add](#cronJobs_pattern1_gateway_responseHeaders_add )       | No      | array | No         | -          | Headers to add, list of {name,value} |
| - [remove](#cronJobs_pattern1_gateway_responseHeaders_remove ) | No      | array | No         | -          | Header names to remove               |
| - [set](#cronJobs_pattern1_gateway_responseHeaders_set )       | No      | array | No         | -          | Headers to set, list of {name,value} |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_add"></a>7.1.16.16.1. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > add`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to add, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_remove"></a>7.1.16.16.2. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > remove`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Header names to remove

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_gateway_responseHeaders_set"></a>7.1.16.16.3. Property `stack > cronJobs > ^.*$ > gateway > responseHeaders > set`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Headers to set, list of {name,value}

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_rules"></a>7.1.16.17. Property `stack > cronJobs > ^.*$ > gateway > rules`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of additional HTTPRoute rules with custom hosts. Each entry takes host, optional paths, and an optional vanity block (enabled, hostname, clusterIssuer) that renders a per-host ListenerSet so the extra host can be a vanity domain, mirroring gateway.vanity

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_gateway_sectionName"></a>7.1.16.18. Property `stack > cronJobs > ^.*$ > gateway > sectionName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional section name (listener name) on the Gateway

##### <a name="cronJobs_pattern1_gateway_sessionAffinity"></a>7.1.16.19. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Cookie-based sticky sessions via a BackendTrafficPolicy. Off by default (the ingress cookie-affinity default is not carried to the gateway)

| Property                                                               | Pattern | Type    | Deprecated | Definition | Title/Description                              |
| ---------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------------------------------- |
| - [cookieName](#cronJobs_pattern1_gateway_sessionAffinity_cookieName ) | No      | string  | No         | -          | Affinity cookie name                           |
| - [enabled](#cronJobs_pattern1_gateway_sessionAffinity_enabled )       | No      | boolean | No         | -          | Enable consistent-hash cookie session affinity |
| - [ttl](#cronJobs_pattern1_gateway_sessionAffinity_ttl )               | No      | string  | No         | -          | Affinity cookie TTL                            |

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_cookieName"></a>7.1.16.19.1. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > cookieName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Affinity cookie name

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_enabled"></a>7.1.16.19.2. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable consistent-hash cookie session affinity

###### <a name="cronJobs_pattern1_gateway_sessionAffinity_ttl"></a>7.1.16.19.3. Property `stack > cronJobs > ^.*$ > gateway > sessionAffinity > ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Affinity cookie TTL

##### <a name="cronJobs_pattern1_gateway_timeouts"></a>7.1.16.20. Property `stack > cronJobs > ^.*$ > gateway > timeouts`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTPRoute timeouts. request maps to nginx proxy-read and send-timeout. connect (optional) renders a BackendTrafficPolicy

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description                                                                                                             |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------------------------------------------------------------------------------------------------- |
| - [backendRequest](#cronJobs_pattern1_gateway_timeouts_backendRequest ) | No      | string | No         | -          | Per-try backend request timeout (HTTPRoute rules[].timeouts.backendRequest). Must be <= request                               |
| - [connect](#cronJobs_pattern1_gateway_timeouts_connect )               | No      | string | No         | -          | Optional upstream TCP connect timeout (renders BackendTrafficPolicy timeout.tcp.connectTimeout), empty uses the Envoy default |
| - [request](#cronJobs_pattern1_gateway_timeouts_request )               | No      | string | No         | -          | Overall request timeout (HTTPRoute rules[].timeouts.request). Set "0s" to disable, e.g. for streaming or websockets           |

###### <a name="cronJobs_pattern1_gateway_timeouts_backendRequest"></a>7.1.16.20.1. Property `stack > cronJobs > ^.*$ > gateway > timeouts > backendRequest`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Per-try backend request timeout (HTTPRoute rules[].timeouts.backendRequest). Must be <= request

###### <a name="cronJobs_pattern1_gateway_timeouts_connect"></a>7.1.16.20.2. Property `stack > cronJobs > ^.*$ > gateway > timeouts > connect`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional upstream TCP connect timeout (renders BackendTrafficPolicy timeout.tcp.connectTimeout), empty uses the Envoy default

###### <a name="cronJobs_pattern1_gateway_timeouts_request"></a>7.1.16.20.3. Property `stack > cronJobs > ^.*$ > gateway > timeouts > request`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Overall request timeout (HTTPRoute rules[].timeouts.request). Set "0s" to disable, e.g. for streaming or websockets

##### <a name="cronJobs_pattern1_gateway_tlsPassthrough"></a>7.1.16.21. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** TLS passthrough via a TLSRoute (the Gateway does not terminate TLS). Mutually exclusive with the L7 gateway features, and requires a Passthrough listener on the shared Gateway

| Property                                                                | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                   |
| ----------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_gateway_tlsPassthrough_enabled )         | No      | boolean | No         | -          | Render a TLSRoute instead of an HTTPRoute and skip TLS termination for this service                                 |
| - [sectionName](#cronJobs_pattern1_gateway_tlsPassthrough_sectionName ) | No      | string  | No         | -          | Optional Passthrough listener name to pin to. Empty attaches by hostname plus TLS protocol, which is the usual case |

###### <a name="cronJobs_pattern1_gateway_tlsPassthrough_enabled"></a>7.1.16.21.1. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Render a TLSRoute instead of an HTTPRoute and skip TLS termination for this service

###### <a name="cronJobs_pattern1_gateway_tlsPassthrough_sectionName"></a>7.1.16.21.2. Property `stack > cronJobs > ^.*$ > gateway > tlsPassthrough > sectionName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional Passthrough listener name to pin to. Empty attaches by hostname plus TLS protocol, which is the usual case

##### <a name="cronJobs_pattern1_gateway_vanity"></a>7.1.16.22. Property `stack > cronJobs > ^.*$ > gateway > vanity`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Self-serve public/vanity-domain TLS via a tenant-owned Gateway API ListenerSet (requires Envoy Gateway >= v1.8 and cert-manager >= v1.20)

| Property                                                            | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                                                        |
| ------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - [clusterIssuer](#cronJobs_pattern1_gateway_vanity_clusterIssuer ) | No      | string  | No         | -          | cert-manager ClusterIssuer used by the gateway-shim to issue the listener certificate                                                                    |
| - [enabled](#cronJobs_pattern1_gateway_vanity_enabled )             | No      | boolean | No         | -          | Render a ListenerSet attaching an HTTPS listener for this service's vanity domain to the shared Gateway                                                  |
| - [hostname](#cronJobs_pattern1_gateway_vanity_hostname )           | No      | string  | No         | -          | Listener SNI hostname (defaults to gateway.host). A wildcard such as *.parent requires a dns01-capable issuer because http01 cannot issue wildcard certs |

###### <a name="cronJobs_pattern1_gateway_vanity_clusterIssuer"></a>7.1.16.22.1. Property `stack > cronJobs > ^.*$ > gateway > vanity > clusterIssuer`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** cert-manager ClusterIssuer used by the gateway-shim to issue the listener certificate

###### <a name="cronJobs_pattern1_gateway_vanity_enabled"></a>7.1.16.22.2. Property `stack > cronJobs > ^.*$ > gateway > vanity > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Render a ListenerSet attaching an HTTPS listener for this service's vanity domain to the shared Gateway

###### <a name="cronJobs_pattern1_gateway_vanity_hostname"></a>7.1.16.22.3. Property `stack > cronJobs > ^.*$ > gateway > vanity > hostname`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Listener SNI hostname (defaults to gateway.host). A wildcard such as *.parent requires a dns01-capable issuer because http01 cannot issue wildcard certs

#### <a name="cronJobs_pattern1_grafanaDashboard"></a>7.1.17. Property `stack > cronJobs > ^.*$ > grafanaDashboard`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                    | Pattern | Type            | Deprecated | Definition | Title/Description                                                  |
| --------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ------------------------------------------------------------------ |
| - [datasources](#cronJobs_pattern1_grafanaDashboard_datasources )           | No      | object          | No         | -          | -                                                                  |
| - [enabled](#cronJobs_pattern1_grafanaDashboard_enabled )                   | No      | boolean         | No         | -          | Enable Grafana dashboard (globally, can be overridden per service) |
| - [extraPanels](#cronJobs_pattern1_grafanaDashboard_extraPanels )           | No      | array of object | No         | -          | Extra panels to add to the Grafana dashboard                       |
| - [instanceSelector](#cronJobs_pattern1_grafanaDashboard_instanceSelector ) | No      | object          | No         | -          | Instance selector for the Grafana dashboard                        |

##### <a name="cronJobs_pattern1_grafanaDashboard_datasources"></a>7.1.17.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                    | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [prometheus](#cronJobs_pattern1_grafanaDashboard_datasources_prometheus ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_datasources_prometheus"></a>7.1.17.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources > prometheus`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                 | Pattern | Type   | Deprecated | Definition | Title/Description         |
| ------------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ------------------------- |
| - [uid](#cronJobs_pattern1_grafanaDashboard_datasources_prometheus_uid ) | No      | string | No         | -          | Prometheus datasource UID |

###### <a name="cronJobs_pattern1_grafanaDashboard_datasources_prometheus_uid"></a>7.1.17.1.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > datasources > prometheus > uid`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Prometheus datasource UID

##### <a name="cronJobs_pattern1_grafanaDashboard_enabled"></a>7.1.17.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable Grafana dashboard (globally, can be overridden per service)

##### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels"></a>7.1.17.3. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Extra panels to add to the Grafana dashboard

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                            | Description |
| -------------------------------------------------------------------------- | ----------- |
| [extraPanels items](#cronJobs_pattern1_grafanaDashboard_extraPanels_items) | -           |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items"></a>7.1.17.3.1. stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [datasource](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_datasource )       | No      | object | No         | -          | -                 |
| - [fieldConfig](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_fieldConfig )     | No      | object | No         | -          | -                 |
| - [gridPos](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos )             | No      | object | No         | -          | -                 |
| - [options](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_options )             | No      | object | No         | -          | -                 |
| - [pluginVersion](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_pluginVersion ) | No      | string | No         | -          | -                 |
| - [targets](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_targets )             | No      | array  | No         | -          | -                 |
| - [title](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_title )                 | No      | string | No         | -          | -                 |
| - [type](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_type )                   | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_datasource"></a>7.1.17.3.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > datasource`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_fieldConfig"></a>7.1.17.3.1.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > fieldConfig`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos"></a>7.1.17.3.1.3. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [h](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_h ) | No      | number | No         | -          | -                 |
| - [w](#cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_w ) | No      | number | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_h"></a>7.1.17.3.1.3.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos > h`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_gridPos_w"></a>7.1.17.3.1.3.2. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > gridPos > w`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_options"></a>7.1.17.3.1.4. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > options`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_pluginVersion"></a>7.1.17.3.1.5. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > pluginVersion`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_targets"></a>7.1.17.3.1.6. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > targets`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_title"></a>7.1.17.3.1.7. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > title`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_grafanaDashboard_extraPanels_items_type"></a>7.1.17.3.1.8. Property `stack > cronJobs > ^.*$ > grafanaDashboard > extraPanels > extraPanels items > type`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector"></a>7.1.17.4. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Instance selector for the Grafana dashboard

| Property                                                                           | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [matchLabels](#cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels"></a>7.1.17.4.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector > matchLabels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                         | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels_name ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_grafanaDashboard_instanceSelector_matchLabels_name"></a>7.1.17.4.1.1. Property `stack > cronJobs > ^.*$ > grafanaDashboard > instanceSelector > matchLabels > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_image"></a>7.1.18. Property `stack > cronJobs > ^.*$ > image`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                             | Pattern | Type             | Deprecated | Definition | Title/Description |
| ---------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [pullPolicy](#cronJobs_pattern1_image_pullPolicy ) | No      | enum (of string) | No         | -          | Image pull policy |
| - [repository](#cronJobs_pattern1_image_repository ) | No      | string           | No         | -          | Image repository  |
| - [tag](#cronJobs_pattern1_image_tag )               | No      | string           | No         | -          | Image tag         |

##### <a name="cronJobs_pattern1_image_pullPolicy"></a>7.1.18.1. Property `stack > cronJobs > ^.*$ > image > pullPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** Image pull policy

Must be one of:
* "Always"
* "IfNotPresent"
* "Never"

##### <a name="cronJobs_pattern1_image_repository"></a>7.1.18.2. Property `stack > cronJobs > ^.*$ > image > repository`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image repository

##### <a name="cronJobs_pattern1_image_tag"></a>7.1.18.3. Property `stack > cronJobs > ^.*$ > image > tag`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image tag

#### <a name="cronJobs_pattern1_imagePullSecrets"></a>7.1.19. Property `stack > cronJobs > ^.*$ > imagePullSecrets`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [imagePullSecrets items](#cronJobs_pattern1_imagePullSecrets_items) | -           |

##### <a name="cronJobs_pattern1_imagePullSecrets_items"></a>7.1.19.1. stack > cronJobs > ^.*$ > imagePullSecrets > imagePullSecrets items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_ingress"></a>7.1.20. Property `stack > cronJobs > ^.*$ > ingress`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Ingress configuration

| Property                                                     | Pattern | Type            | Deprecated | Definition | Title/Description                                                 |
| ------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_ingress_annotations )     | No      | object          | No         | -          | -                                                                 |
| - [className](#cronJobs_pattern1_ingress_className )         | No      | string          | No         | -          | Ingress class name                                                |
| - [enabled](#cronJobs_pattern1_ingress_enabled )             | No      | boolean         | No         | -          | Enable ingress                                                    |
| - [host](#cronJobs_pattern1_ingress_host )                   | No      | string          | No         | -          | Ingress host                                                      |
| - [oidcProtected](#cronJobs_pattern1_ingress_oidcProtected ) | No      | boolean         | No         | -          | Enable OIDC protection (route to oauth2-proxy when using Ingress) |
| - [paths](#cronJobs_pattern1_ingress_paths )                 | No      | array of object | No         | -          | List of ingress paths                                             |
| - [rules](#cronJobs_pattern1_ingress_rules )                 | No      | array           | No         | -          | List of ingress rules                                             |
| - [tls](#cronJobs_pattern1_ingress_tls )                     | No      | array           | No         | -          | List of ingress TLS configurations                                |

##### <a name="cronJobs_pattern1_ingress_annotations"></a>7.1.20.1. Property `stack > cronJobs > ^.*$ > ingress > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [external-dns.alpha.kubernetes.io/ttl](#cronJobs_pattern1_ingress_annotations_external-dnsalphakubernetesio/ttl )                             | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/affinity](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/affinity )                             | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-connect-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-connect-timeout )   | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-read-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-read-timeout )         | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/proxy-send-timeout](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-send-timeout )         | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/session-cookie-max-age](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-max-age ) | No      | string | No         | -          | -                 |
| - [nginx.ingress.kubernetes.io/session-cookie-name](#cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-name )       | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_ingress_annotations_external-dnsalphakubernetesio/ttl"></a>7.1.20.1.1. Property `stack > cronJobs > ^.*$ > ingress > annotations > external-dns.alpha.kubernetes.io/ttl`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/affinity"></a>7.1.20.1.2. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/affinity`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-connect-timeout"></a>7.1.20.1.3. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-connect-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-read-timeout"></a>7.1.20.1.4. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-read-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/proxy-send-timeout"></a>7.1.20.1.5. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/proxy-send-timeout`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-max-age"></a>7.1.20.1.6. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/session-cookie-max-age`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_ingress_annotations_nginxingresskubernetesio/session-cookie-name"></a>7.1.20.1.7. Property `stack > cronJobs > ^.*$ > ingress > annotations > nginx.ingress.kubernetes.io/session-cookie-name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_ingress_className"></a>7.1.20.2. Property `stack > cronJobs > ^.*$ > ingress > className`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress class name

##### <a name="cronJobs_pattern1_ingress_enabled"></a>7.1.20.3. Property `stack > cronJobs > ^.*$ > ingress > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable ingress

##### <a name="cronJobs_pattern1_ingress_host"></a>7.1.20.4. Property `stack > cronJobs > ^.*$ > ingress > host`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress host

##### <a name="cronJobs_pattern1_ingress_oidcProtected"></a>7.1.20.5. Property `stack > cronJobs > ^.*$ > ingress > oidcProtected`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC protection (route to oauth2-proxy when using Ingress)

##### <a name="cronJobs_pattern1_ingress_paths"></a>7.1.20.6. Property `stack > cronJobs > ^.*$ > ingress > paths`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of ingress paths

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                       | Description |
| ----------------------------------------------------- | ----------- |
| [paths items](#cronJobs_pattern1_ingress_paths_items) | -           |

###### <a name="cronJobs_pattern1_ingress_paths_items"></a>7.1.20.6.1. stack > cronJobs > ^.*$ > ingress > paths > paths items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_ingress_paths_items_path )         | No      | string | No         | -          | Ingress path      |
| - [pathType](#cronJobs_pattern1_ingress_paths_items_pathType ) | No      | string | No         | -          | Ingress path type |

###### <a name="cronJobs_pattern1_ingress_paths_items_path"></a>7.1.20.6.1.1. Property `stack > cronJobs > ^.*$ > ingress > paths > paths items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress path

###### <a name="cronJobs_pattern1_ingress_paths_items_pathType"></a>7.1.20.6.1.2. Property `stack > cronJobs > ^.*$ > ingress > paths > paths items > pathType`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Ingress path type

##### <a name="cronJobs_pattern1_ingress_rules"></a>7.1.20.7. Property `stack > cronJobs > ^.*$ > ingress > rules`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of ingress rules

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_ingress_tls"></a>7.1.20.8. Property `stack > cronJobs > ^.*$ > ingress > tls`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of ingress TLS configurations

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_initContainers"></a>7.1.21. Property `stack > cronJobs > ^.*$ > initContainers`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of init containers

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_kedaAutoscaling"></a>7.1.22. Property `stack > cronJobs > ^.*$ > kedaAutoscaling`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** KEDA autoscaling configuration (creates a ScaledObject instead of HPA)

| Property                                                                 | Pattern | Type            | Deprecated | Definition | Title/Description                                                                         |
| ------------------------------------------------------------------------ | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------------------------- |
| - [advanced](#cronJobs_pattern1_kedaAutoscaling_advanced )               | No      | object          | No         | -          | Advanced KEDA ScaledObject configuration                                                  |
| - [cooldownPeriod](#cronJobs_pattern1_kedaAutoscaling_cooldownPeriod )   | No      | integer         | No         | -          | Period in seconds to wait after the last trigger fires before scaling back to minReplicas |
| - [enabled](#cronJobs_pattern1_kedaAutoscaling_enabled )                 | No      | boolean         | No         | -          | Enable KEDA autoscaling                                                                   |
| - [maxReplicas](#cronJobs_pattern1_kedaAutoscaling_maxReplicas )         | No      | integer         | No         | -          | Maximum number of replicas                                                                |
| - [minReplicas](#cronJobs_pattern1_kedaAutoscaling_minReplicas )         | No      | integer         | No         | -          | Minimum number of replicas                                                                |
| - [pollingInterval](#cronJobs_pattern1_kedaAutoscaling_pollingInterval ) | No      | integer         | No         | -          | Interval in seconds to check each trigger                                                 |
| - [triggers](#cronJobs_pattern1_kedaAutoscaling_triggers )               | No      | array of object | No         | -          | List of KEDA triggers (e.g. prometheus, cpu, memory, cron)                                |

##### <a name="cronJobs_pattern1_kedaAutoscaling_advanced"></a>7.1.22.1. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > advanced`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Advanced KEDA ScaledObject configuration

##### <a name="cronJobs_pattern1_kedaAutoscaling_cooldownPeriod"></a>7.1.22.2. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > cooldownPeriod`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Period in seconds to wait after the last trigger fires before scaling back to minReplicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_enabled"></a>7.1.22.3. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable KEDA autoscaling

##### <a name="cronJobs_pattern1_kedaAutoscaling_maxReplicas"></a>7.1.22.4. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > maxReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Maximum number of replicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_minReplicas"></a>7.1.22.5. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > minReplicas`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Minimum number of replicas

##### <a name="cronJobs_pattern1_kedaAutoscaling_pollingInterval"></a>7.1.22.6. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > pollingInterval`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Interval in seconds to check each trigger

##### <a name="cronJobs_pattern1_kedaAutoscaling_triggers"></a>7.1.22.7. Property `stack > cronJobs > ^.*$ > kedaAutoscaling > triggers`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** List of KEDA triggers (e.g. prometheus, cpu, memory, cron)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [triggers items](#cronJobs_pattern1_kedaAutoscaling_triggers_items) | -           |

###### <a name="cronJobs_pattern1_kedaAutoscaling_triggers_items"></a>7.1.22.7.1. stack > cronJobs > ^.*$ > kedaAutoscaling > triggers > triggers items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

#### <a name="cronJobs_pattern1_livenessProbe"></a>7.1.23. Property `stack > cronJobs > ^.*$ > livenessProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Liveness probe configuration

| Property                                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                                                                     |
| ------------------------------------------------------------------------------ | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [failureThreshold](#cronJobs_pattern1_livenessProbe_failureThreshold )       | No      | number | No         | -          | Number of failures before the probe is considered failed                              |
| - [httpGet](#cronJobs_pattern1_livenessProbe_httpGet )                         | No      | object | No         | -          | HTTP probe configuration (exec & tcpSocket are also available)                        |
| - [initialDelaySeconds](#cronJobs_pattern1_livenessProbe_initialDelaySeconds ) | No      | number | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_livenessProbe_periodSeconds )             | No      | number | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_livenessProbe_successThreshold )       | No      | number | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_livenessProbe_timeoutSeconds )           | No      | number | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_livenessProbe_failureThreshold"></a>7.1.23.1. Property `stack > cronJobs > ^.*$ > livenessProbe > failureThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_livenessProbe_httpGet"></a>7.1.23.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP probe configuration (exec & tcpSocket are also available)

| Property                                                     | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------ | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_livenessProbe_httpGet_path )     | No      | string      | No         | -          | Path to probe     |
| - [port](#cronJobs_pattern1_livenessProbe_httpGet_port )     | No      | Combination | No         | -          | Port to probe     |
| - [scheme](#cronJobs_pattern1_livenessProbe_httpGet_scheme ) | No      | string      | No         | -          | Scheme to use     |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_path"></a>7.1.23.2.1. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path to probe

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port"></a>7.1.23.2.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Port to probe

| One of(Option)                                                   |
| ---------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i0) |
| [item 1](#cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i1) |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i0"></a>7.1.23.2.2.1. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_port_oneOf_i1"></a>7.1.23.2.2.2. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > port > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_livenessProbe_httpGet_scheme"></a>7.1.23.2.3. Property `stack > cronJobs > ^.*$ > livenessProbe > httpGet > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Scheme to use

##### <a name="cronJobs_pattern1_livenessProbe_initialDelaySeconds"></a>7.1.23.3. Property `stack > cronJobs > ^.*$ > livenessProbe > initialDelaySeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_livenessProbe_periodSeconds"></a>7.1.23.4. Property `stack > cronJobs > ^.*$ > livenessProbe > periodSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_livenessProbe_successThreshold"></a>7.1.23.5. Property `stack > cronJobs > ^.*$ > livenessProbe > successThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_livenessProbe_timeoutSeconds"></a>7.1.23.6. Property `stack > cronJobs > ^.*$ > livenessProbe > timeoutSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_nameOverride"></a>7.1.24. Property `stack > cronJobs > ^.*$ > nameOverride`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name to prefix the K8s resources with, combined with the stack name prefix

#### <a name="cronJobs_pattern1_nodeSelector"></a>7.1.25. Property `stack > cronJobs > ^.*$ > nodeSelector`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description              |
| -------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------ |
| - [kubernetes.io/arch](#cronJobs_pattern1_nodeSelector_kubernetesio/arch ) | No      | string | No         | -          | Node selector for architecture |

##### <a name="cronJobs_pattern1_nodeSelector_kubernetesio/arch"></a>7.1.25.1. Property `stack > cronJobs > ^.*$ > nodeSelector > kubernetes.io/arch`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Node selector for architecture

#### <a name="cronJobs_pattern1_oidcProxy"></a>7.1.26. Property `stack > cronJobs > ^.*$ > oidcProxy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                               | Pattern | Type            | Deprecated | Definition | Title/Description                            |
| ---------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | -------------------------------------------- |
| - [additionalHeaders](#cronJobs_pattern1_oidcProxy_additionalHeaders ) | No      | array           | No         | -          | Additional headers to add                    |
| - [additionalSecrets](#cronJobs_pattern1_oidcProxy_additionalSecrets ) | No      | array           | No         | -          | Additional secrets to mount                  |
| - [annotations](#cronJobs_pattern1_oidcProxy_annotations )             | No      | object          | No         | -          | Annotations to add to the OIDC proxy         |
| - [cookieRefresh](#cronJobs_pattern1_oidcProxy_cookieRefresh )         | No      | string          | No         | -          | Refresh tokens and cookies after this period |
| - [enabled](#cronJobs_pattern1_oidcProxy_enabled )                     | No      | boolean         | No         | -          | Enable OIDC proxy                            |
| - [extraArgs](#cronJobs_pattern1_oidcProxy_extraArgs )                 | No      | array of string | No         | -          | Extra arguments to pass to the OIDC proxy    |
| - [image](#cronJobs_pattern1_oidcProxy_image )                         | No      | object          | No         | -          | -                                            |
| - [replicaCount](#cronJobs_pattern1_oidcProxy_replicaCount )           | No      | integer         | No         | -          | Number of replicas                           |
| - [resources](#cronJobs_pattern1_oidcProxy_resources )                 | No      | object          | No         | -          | -                                            |
| - [skipAuth](#cronJobs_pattern1_oidcProxy_skipAuth )                   | No      | array of object | No         | -          | Paths to skip authentication                 |
| - [volumeMounts](#cronJobs_pattern1_oidcProxy_volumeMounts )           | No      | array           | No         | -          | Volume mounts for the OIDC proxy             |

##### <a name="cronJobs_pattern1_oidcProxy_additionalHeaders"></a>7.1.26.1. Property `stack > cronJobs > ^.*$ > oidcProxy > additionalHeaders`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional headers to add

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxy_additionalSecrets"></a>7.1.26.2. Property `stack > cronJobs > ^.*$ > oidcProxy > additionalSecrets`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional secrets to mount

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxy_annotations"></a>7.1.26.3. Property `stack > cronJobs > ^.*$ > oidcProxy > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to the OIDC proxy

##### <a name="cronJobs_pattern1_oidcProxy_cookieRefresh"></a>7.1.26.4. Property `stack > cronJobs > ^.*$ > oidcProxy > cookieRefresh`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Refresh tokens and cookies after this period

##### <a name="cronJobs_pattern1_oidcProxy_enabled"></a>7.1.26.5. Property `stack > cronJobs > ^.*$ > oidcProxy > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable OIDC proxy

##### <a name="cronJobs_pattern1_oidcProxy_extraArgs"></a>7.1.26.6. Property `stack > cronJobs > ^.*$ > oidcProxy > extraArgs`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** Extra arguments to pass to the OIDC proxy

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                 | Description |
| --------------------------------------------------------------- | ----------- |
| [extraArgs items](#cronJobs_pattern1_oidcProxy_extraArgs_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxy_extraArgs_items"></a>7.1.26.6.1. stack > cronJobs > ^.*$ > oidcProxy > extraArgs > extraArgs items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxy_image"></a>7.1.26.7. Property `stack > cronJobs > ^.*$ > oidcProxy > image`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [repository](#cronJobs_pattern1_oidcProxy_image_repository ) | No      | string | No         | -          | Image repository  |
| - [tag](#cronJobs_pattern1_oidcProxy_image_tag )               | No      | string | No         | -          | Image tag         |

###### <a name="cronJobs_pattern1_oidcProxy_image_repository"></a>7.1.26.7.1. Property `stack > cronJobs > ^.*$ > oidcProxy > image > repository`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image repository

###### <a name="cronJobs_pattern1_oidcProxy_image_tag"></a>7.1.26.7.2. Property `stack > cronJobs > ^.*$ > oidcProxy > image > tag`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Image tag

##### <a name="cronJobs_pattern1_oidcProxy_replicaCount"></a>7.1.26.8. Property `stack > cronJobs > ^.*$ > oidcProxy > replicaCount`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of replicas

##### <a name="cronJobs_pattern1_oidcProxy_resources"></a>7.1.26.9. Property `stack > cronJobs > ^.*$ > oidcProxy > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                       | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [limits](#cronJobs_pattern1_oidcProxy_resources_limits )     | No      | object | No         | -          | -                 |
| - [requests](#cronJobs_pattern1_oidcProxy_resources_requests ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits"></a>7.1.26.9.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                          | Pattern | Type        | Deprecated | Definition | Title/Description |
| ----------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_oidcProxy_resources_limits_cpu )       | No      | Combination | No         | -          | CPU limit         |
| - [memory](#cronJobs_pattern1_oidcProxy_resources_limits_memory ) | No      | string      | No         | -          | Memory limit      |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu"></a>7.1.26.9.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU limit

| One of(Option)                                                       |
| -------------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i0"></a>7.1.26.9.1.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_cpu_oneOf_i1"></a>7.1.26.9.1.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_limits_memory"></a>7.1.26.9.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > limits > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory limit

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests"></a>7.1.26.9.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                            | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_oidcProxy_resources_requests_cpu )       | No      | Combination | No         | -          | CPU request       |
| - [memory](#cronJobs_pattern1_oidcProxy_resources_requests_memory ) | No      | string      | No         | -          | Memory request    |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu"></a>7.1.26.9.2.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU request

| One of(Option)                                                         |
| ---------------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i0"></a>7.1.26.9.2.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_cpu_oneOf_i1"></a>7.1.26.9.2.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_resources_requests_memory"></a>7.1.26.9.2.2. Property `stack > cronJobs > ^.*$ > oidcProxy > resources > requests > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory request

##### <a name="cronJobs_pattern1_oidcProxy_skipAuth"></a>7.1.26.10. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Paths to skip authentication

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                               | Description |
| ------------------------------------------------------------- | ----------- |
| [skipAuth items](#cronJobs_pattern1_oidcProxy_skipAuth_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items"></a>7.1.26.10.1. stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                        | Pattern | Type   | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [method](#cronJobs_pattern1_oidcProxy_skipAuth_items_method ) | No      | string | No         | -          | -                 |
| - [path](#cronJobs_pattern1_oidcProxy_skipAuth_items_path )     | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items_method"></a>7.1.26.10.1.1. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items > method`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxy_skipAuth_items_path"></a>7.1.26.10.1.2. Property `stack > cronJobs > ^.*$ > oidcProxy > skipAuth > skipAuth items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxy_volumeMounts"></a>7.1.26.11. Property `stack > cronJobs > ^.*$ > oidcProxy > volumeMounts`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Volume mounts for the OIDC proxy

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_oidcProxyGateway"></a>7.1.27. Property `stack > cronJobs > ^.*$ > oidcProxyGateway`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Native Envoy Gateway OIDC authentication configuration (used when gateway.oidcProtected is true). Requires explicit clientID and issuer configuration. clientSecret is auto-referenced from appSecrets. redirectURL is auto-generated as https://<gateway.host>/oauth2/callback.

| Property                                                                        | Pattern | Type            | Deprecated | Definition | Title/Description                                                                      |
| ------------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | -------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_oidcProxyGateway_annotations )               | No      | object          | No         | -          | Annotations to add to SecurityPolicy resources                                         |
| - [clientID](#cronJobs_pattern1_oidcProxyGateway_clientID )                     | No      | string          | No         | -          | OIDC client ID (required when gateway.oidcProtected is enabled)                        |
| - [cookieDomain](#cronJobs_pattern1_oidcProxyGateway_cookieDomain )             | No      | string          | No         | -          | Optional root domain for sharing tokens across subdomains (e.g., cluster.dev.czi.team) |
| - [cookieNames](#cronJobs_pattern1_oidcProxyGateway_cookieNames )               | No      | object          | No         | -          | Customize cookie names                                                                 |
| - [forwardAccessToken](#cronJobs_pattern1_oidcProxyGateway_forwardAccessToken ) | No      | boolean         | No         | -          | Forward access token to backend service                                                |
| - [logoutPath](#cronJobs_pattern1_oidcProxyGateway_logoutPath )                 | No      | string          | No         | -          | Path for logout operations                                                             |
| - [provider](#cronJobs_pattern1_oidcProxyGateway_provider )                     | No      | object          | No         | -          | OIDC provider configuration                                                            |
| - [refreshToken](#cronJobs_pattern1_oidcProxyGateway_refreshToken )             | No      | boolean         | No         | -          | Use refresh tokens to refresh access tokens (default true in Envoy Gateway v1.6.0+)    |
| - [resources](#cronJobs_pattern1_oidcProxyGateway_resources )                   | No      | array           | No         | -          | Optional OAuth2 resources parameter                                                    |
| - [scopes](#cronJobs_pattern1_oidcProxyGateway_scopes )                         | No      | array of string | No         | -          | OIDC scopes to request                                                                 |
| - [skipAuth](#cronJobs_pattern1_oidcProxyGateway_skipAuth )                     | No      | array of object | No         | -          | Paths to skip authentication (creates separate public HTTPRoute)                       |

##### <a name="cronJobs_pattern1_oidcProxyGateway_annotations"></a>7.1.27.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to SecurityPolicy resources

##### <a name="cronJobs_pattern1_oidcProxyGateway_clientID"></a>7.1.27.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > clientID`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** OIDC client ID (required when gateway.oidcProtected is enabled)

##### <a name="cronJobs_pattern1_oidcProxyGateway_cookieDomain"></a>7.1.27.3. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieDomain`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional root domain for sharing tokens across subdomains (e.g., cluster.dev.czi.team)

##### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames"></a>7.1.27.4. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Customize cookie names

| Property                                                                      | Pattern | Type   | Deprecated | Definition | Title/Description                   |
| ----------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------------------------- |
| - [accessToken](#cronJobs_pattern1_oidcProxyGateway_cookieNames_accessToken ) | No      | string | No         | -          | Custom name for access token cookie |
| - [idToken](#cronJobs_pattern1_oidcProxyGateway_cookieNames_idToken )         | No      | string | No         | -          | Custom name for ID token cookie     |

###### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames_accessToken"></a>7.1.27.4.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames > accessToken`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom name for access token cookie

###### <a name="cronJobs_pattern1_oidcProxyGateway_cookieNames_idToken"></a>7.1.27.4.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > cookieNames > idToken`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom name for ID token cookie

##### <a name="cronJobs_pattern1_oidcProxyGateway_forwardAccessToken"></a>7.1.27.5. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > forwardAccessToken`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Forward access token to backend service

##### <a name="cronJobs_pattern1_oidcProxyGateway_logoutPath"></a>7.1.27.6. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > logoutPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path for logout operations

##### <a name="cronJobs_pattern1_oidcProxyGateway_provider"></a>7.1.27.7. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** OIDC provider configuration

| Property                                                                                       | Pattern | Type   | Deprecated | Definition | Title/Description                                                         |
| ---------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [authorizationEndpoint](#cronJobs_pattern1_oidcProxyGateway_provider_authorizationEndpoint ) | No      | string | No         | -          | Optional authorization endpoint (auto-discovered by provider if empty)    |
| - [issuer](#cronJobs_pattern1_oidcProxyGateway_provider_issuer )                               | No      | string | No         | -          | OIDC provider issuer URL (required when gateway.oidcProtected is enabled) |
| - [tokenEndpoint](#cronJobs_pattern1_oidcProxyGateway_provider_tokenEndpoint )                 | No      | string | No         | -          | Optional token endpoint (auto-discovered by provider if empty)            |

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_authorizationEndpoint"></a>7.1.27.7.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > authorizationEndpoint`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional authorization endpoint (auto-discovered by provider if empty)

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_issuer"></a>7.1.27.7.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > issuer`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** OIDC provider issuer URL (required when gateway.oidcProtected is enabled)

###### <a name="cronJobs_pattern1_oidcProxyGateway_provider_tokenEndpoint"></a>7.1.27.7.3. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > provider > tokenEndpoint`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Optional token endpoint (auto-discovered by provider if empty)

##### <a name="cronJobs_pattern1_oidcProxyGateway_refreshToken"></a>7.1.27.8. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > refreshToken`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Use refresh tokens to refresh access tokens (default true in Envoy Gateway v1.6.0+)

##### <a name="cronJobs_pattern1_oidcProxyGateway_resources"></a>7.1.27.9. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > resources`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Optional OAuth2 resources parameter

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

##### <a name="cronJobs_pattern1_oidcProxyGateway_scopes"></a>7.1.27.10. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > scopes`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

**Description:** OIDC scopes to request

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                  | Description |
| ---------------------------------------------------------------- | ----------- |
| [scopes items](#cronJobs_pattern1_oidcProxyGateway_scopes_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxyGateway_scopes_items"></a>7.1.27.10.1. stack > cronJobs > ^.*$ > oidcProxyGateway > scopes > scopes items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth"></a>7.1.27.11. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** Paths to skip authentication (creates separate public HTTPRoute)

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                      | Description |
| -------------------------------------------------------------------- | ----------- |
| [skipAuth items](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items) | -           |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items"></a>7.1.27.11.1. stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                               | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [method](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items_method ) | No      | string | No         | -          | -                 |
| - [path](#cronJobs_pattern1_oidcProxyGateway_skipAuth_items_path )     | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items_method"></a>7.1.27.11.1.1. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items > method`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_oidcProxyGateway_skipAuth_items_path"></a>7.1.27.11.1.2. Property `stack > cronJobs > ^.*$ > oidcProxyGateway > skipAuth > skipAuth items > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

#### <a name="cronJobs_pattern1_persistence"></a>7.1.28. Property `stack > cronJobs > ^.*$ > persistence`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                         | Pattern | Type    | Deprecated | Definition | Title/Description      |
| ---------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ---------------------- |
| - [enabled](#cronJobs_pattern1_persistence_enabled )             | No      | boolean | No         | -          | Enable persistence     |
| - [existingClaim](#cronJobs_pattern1_persistence_existingClaim ) | No      | string  | No         | -          | Existing PVC name      |
| - [mountPath](#cronJobs_pattern1_persistence_mountPath )         | No      | string  | No         | -          | Mount path for the PVC |
| - [pvc](#cronJobs_pattern1_persistence_pvc )                     | No      | object  | No         | -          | -                      |

##### <a name="cronJobs_pattern1_persistence_enabled"></a>7.1.28.1. Property `stack > cronJobs > ^.*$ > persistence > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable persistence

##### <a name="cronJobs_pattern1_persistence_existingClaim"></a>7.1.28.2. Property `stack > cronJobs > ^.*$ > persistence > existingClaim`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Existing PVC name

##### <a name="cronJobs_pattern1_persistence_mountPath"></a>7.1.28.3. Property `stack > cronJobs > ^.*$ > persistence > mountPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Mount path for the PVC

##### <a name="cronJobs_pattern1_persistence_pvc"></a>7.1.28.4. Property `stack > cronJobs > ^.*$ > persistence > pvc`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                   | Pattern | Type                      | Deprecated | Definition | Title/Description        |
| -------------------------------------------------------------------------- | ------- | ------------------------- | ---------- | ---------- | ------------------------ |
| - [accessModes](#cronJobs_pattern1_persistence_pvc_accessModes )           | No      | array of enum (of string) | No         | -          | Access modes for the PVC |
| - [dataSource](#cronJobs_pattern1_persistence_pvc_dataSource )             | No      | object                    | No         | -          | -                        |
| - [resources](#cronJobs_pattern1_persistence_pvc_resources )               | No      | object                    | No         | -          | -                        |
| - [storageClassName](#cronJobs_pattern1_persistence_pvc_storageClassName ) | No      | string                    | No         | -          | Storage class name       |

###### <a name="cronJobs_pattern1_persistence_pvc_accessModes"></a>7.1.28.4.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > accessModes`

|              |                             |
| ------------ | --------------------------- |
| **Type**     | `array of enum (of string)` |
| **Required** | No                          |

**Description:** Access modes for the PVC

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                           | Description |
| ------------------------------------------------------------------------- | ----------- |
| [accessModes items](#cronJobs_pattern1_persistence_pvc_accessModes_items) | -           |

###### <a name="cronJobs_pattern1_persistence_pvc_accessModes_items"></a>7.1.28.4.1.1. stack > cronJobs > ^.*$ > persistence > pvc > accessModes > accessModes items

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "ReadWriteOnce"
* "ReadOnlyMany"
* "ReadWriteMany"
* "ReadWriteOncePod"

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource"></a>7.1.28.4.2. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                              | Pattern | Type   | Deprecated | Definition | Title/Description                                               |
| --------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | --------------------------------------------------------------- |
| - [apiGroup](#cronJobs_pattern1_persistence_pvc_dataSource_apiGroup ) | No      | string | No         | -          | API version of the data source                                  |
| - [kind](#cronJobs_pattern1_persistence_pvc_dataSource_kind )         | No      | string | No         | -          | Kind of the data source [VolumeSnapshot, PersistentVolumeClaim] |
| - [name](#cronJobs_pattern1_persistence_pvc_dataSource_name )         | No      | string | No         | -          | Name of the data source                                         |

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_apiGroup"></a>7.1.28.4.2.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > apiGroup`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** API version of the data source

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_kind"></a>7.1.28.4.2.2. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > kind`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Kind of the data source [VolumeSnapshot, PersistentVolumeClaim]

###### <a name="cronJobs_pattern1_persistence_pvc_dataSource_name"></a>7.1.28.4.2.3. Property `stack > cronJobs > ^.*$ > persistence > pvc > dataSource > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the data source

###### <a name="cronJobs_pattern1_persistence_pvc_resources"></a>7.1.28.4.3. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                             | Pattern | Type   | Deprecated | Definition | Title/Description     |
| -------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | --------------------- |
| - [requests](#cronJobs_pattern1_persistence_pvc_resources_requests ) | No      | object | No         | -          | PVC resource requests |

###### <a name="cronJobs_pattern1_persistence_pvc_resources_requests"></a>7.1.28.4.3.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** PVC resource requests

| Property                                                                    | Pattern | Type   | Deprecated | Definition | Title/Description        |
| --------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------ |
| - [storage](#cronJobs_pattern1_persistence_pvc_resources_requests_storage ) | No      | string | No         | -          | Storage resource request |

###### <a name="cronJobs_pattern1_persistence_pvc_resources_requests_storage"></a>7.1.28.4.3.1.1. Property `stack > cronJobs > ^.*$ > persistence > pvc > resources > requests > storage`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage resource request

###### <a name="cronJobs_pattern1_persistence_pvc_storageClassName"></a>7.1.28.4.4. Property `stack > cronJobs > ^.*$ > persistence > pvc > storageClassName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage class name

#### <a name="cronJobs_pattern1_podAnnotations"></a>7.1.29. Property `stack > cronJobs > ^.*$ > podAnnotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to pods

#### <a name="cronJobs_pattern1_podLabels"></a>7.1.30. Property `stack > cronJobs > ^.*$ > podLabels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Global labels to add to all pods

#### <a name="cronJobs_pattern1_podSecurityContext"></a>7.1.31. Property `stack > cronJobs > ^.*$ > podSecurityContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Pod security context

#### <a name="cronJobs_pattern1_progressDeadlineSeconds"></a>7.1.32. Property `stack > cronJobs > ^.*$ > progressDeadlineSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** the number of seconds the Deployment controller waits before indicating (in the Deployment status) that the Deployment progress has stalled

#### <a name="cronJobs_pattern1_readinessProbe"></a>7.1.33. Property `stack > cronJobs > ^.*$ > readinessProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Readiness probe configuration

| Property                                                                        | Pattern | Type   | Deprecated | Definition | Title/Description                                                                     |
| ------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [failureThreshold](#cronJobs_pattern1_readinessProbe_failureThreshold )       | No      | number | No         | -          | Number of failures before the probe is considered failed                              |
| - [httpGet](#cronJobs_pattern1_readinessProbe_httpGet )                         | No      | object | No         | -          | HTTP probe configuration (exec & tcpSocket are also available)                        |
| - [initialDelaySeconds](#cronJobs_pattern1_readinessProbe_initialDelaySeconds ) | No      | number | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_readinessProbe_periodSeconds )             | No      | number | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_readinessProbe_successThreshold )       | No      | number | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_readinessProbe_timeoutSeconds )           | No      | number | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_readinessProbe_failureThreshold"></a>7.1.33.1. Property `stack > cronJobs > ^.*$ > readinessProbe > failureThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_readinessProbe_httpGet"></a>7.1.33.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** HTTP probe configuration (exec & tcpSocket are also available)

| Property                                                      | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [path](#cronJobs_pattern1_readinessProbe_httpGet_path )     | No      | string      | No         | -          | Path to probe     |
| - [port](#cronJobs_pattern1_readinessProbe_httpGet_port )     | No      | Combination | No         | -          | Port to probe     |
| - [scheme](#cronJobs_pattern1_readinessProbe_httpGet_scheme ) | No      | string      | No         | -          | Scheme to use     |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_path"></a>7.1.33.2.1. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > path`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Path to probe

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port"></a>7.1.33.2.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Port to probe

| One of(Option)                                                    |
| ----------------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i0) |
| [item 1](#cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i1) |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i0"></a>7.1.33.2.2.1. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_port_oneOf_i1"></a>7.1.33.2.2.2. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > port > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_readinessProbe_httpGet_scheme"></a>7.1.33.2.3. Property `stack > cronJobs > ^.*$ > readinessProbe > httpGet > scheme`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Scheme to use

##### <a name="cronJobs_pattern1_readinessProbe_initialDelaySeconds"></a>7.1.33.3. Property `stack > cronJobs > ^.*$ > readinessProbe > initialDelaySeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_readinessProbe_periodSeconds"></a>7.1.33.4. Property `stack > cronJobs > ^.*$ > readinessProbe > periodSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_readinessProbe_successThreshold"></a>7.1.33.5. Property `stack > cronJobs > ^.*$ > readinessProbe > successThreshold`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_readinessProbe_timeoutSeconds"></a>7.1.33.6. Property `stack > cronJobs > ^.*$ > readinessProbe > timeoutSeconds`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_replicaCount"></a>7.1.34. Property `stack > cronJobs > ^.*$ > replicaCount`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of replicas

#### <a name="cronJobs_pattern1_resources"></a>7.1.35. Property `stack > cronJobs > ^.*$ > resources`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource requests and limits for the primary container

| Property                                             | Pattern | Type   | Deprecated | Definition | Title/Description |
| ---------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [limits](#cronJobs_pattern1_resources_limits )     | No      | object | No         | -          | Resource limits   |
| - [requests](#cronJobs_pattern1_resources_requests ) | No      | object | No         | -          | Resource requests |

##### <a name="cronJobs_pattern1_resources_limits"></a>7.1.35.1. Property `stack > cronJobs > ^.*$ > resources > limits`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource limits

| Property                                                | Pattern | Type        | Deprecated | Definition | Title/Description |
| ------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_resources_limits_cpu )       | No      | Combination | No         | -          | CPU limit         |
| - [memory](#cronJobs_pattern1_resources_limits_memory ) | No      | string      | No         | -          | Memory limit      |

###### <a name="cronJobs_pattern1_resources_limits_cpu"></a>7.1.35.1.1. Property `stack > cronJobs > ^.*$ > resources > limits > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU limit

| One of(Option)                                             |
| ---------------------------------------------------------- |
| [item 0](#cronJobs_pattern1_resources_limits_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_resources_limits_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_resources_limits_cpu_oneOf_i0"></a>7.1.35.1.1.1. Property `stack > cronJobs > ^.*$ > resources > limits > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_limits_cpu_oneOf_i1"></a>7.1.35.1.1.2. Property `stack > cronJobs > ^.*$ > resources > limits > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_limits_memory"></a>7.1.35.1.2. Property `stack > cronJobs > ^.*$ > resources > limits > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory limit

##### <a name="cronJobs_pattern1_resources_requests"></a>7.1.35.2. Property `stack > cronJobs > ^.*$ > resources > requests`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Resource requests

| Property                                                  | Pattern | Type        | Deprecated | Definition | Title/Description |
| --------------------------------------------------------- | ------- | ----------- | ---------- | ---------- | ----------------- |
| - [cpu](#cronJobs_pattern1_resources_requests_cpu )       | No      | Combination | No         | -          | CPU request       |
| - [memory](#cronJobs_pattern1_resources_requests_memory ) | No      | string      | No         | -          | Memory request    |

###### <a name="cronJobs_pattern1_resources_requests_cpu"></a>7.1.35.2.1. Property `stack > cronJobs > ^.*$ > resources > requests > cpu`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `combining`      |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** CPU request

| One of(Option)                                               |
| ------------------------------------------------------------ |
| [item 0](#cronJobs_pattern1_resources_requests_cpu_oneOf_i0) |
| [item 1](#cronJobs_pattern1_resources_requests_cpu_oneOf_i1) |

###### <a name="cronJobs_pattern1_resources_requests_cpu_oneOf_i0"></a>7.1.35.2.1.1. Property `stack > cronJobs > ^.*$ > resources > requests > cpu > oneOf > item 0`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_requests_cpu_oneOf_i1"></a>7.1.35.2.1.2. Property `stack > cronJobs > ^.*$ > resources > requests > cpu > oneOf > item 1`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_resources_requests_memory"></a>7.1.35.2.2. Property `stack > cronJobs > ^.*$ > resources > requests > memory`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Memory request

#### <a name="cronJobs_pattern1_restartPolicy"></a>7.1.36. Property `stack > cronJobs > ^.*$ > restartPolicy`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

**Description:** Restart policy for the pod

Must be one of:
* "Always"
* "OnFailure"
* "Never"

#### <a name="cronJobs_pattern1_rollout"></a>7.1.37. Property `stack > cronJobs > ^.*$ > rollout`

|                           |                      |
| ------------------------- | -------------------- |
| **Type**                  | `object`             |
| **Required**              | No                   |
| **Additional properties** | Any type allowed     |
| **Defined in**            | #/properties/rollout |

| Property                                               | Pattern | Type   | Deprecated | Definition | Title/Description                                   |
| ------------------------------------------------------ | ------- | ------ | ---------- | ---------- | --------------------------------------------------- |
| - [strategy](#cronJobs_pattern1_rollout_strategy )     | No      | object | No         | -          | Specifies the rollout strategy for the application. |
| - [](#cronJobs_pattern1_rollout_additionalProperties ) | No      | object | No         | -          | -                                                   |

##### <a name="cronJobs_pattern1_rollout_strategy"></a>7.1.37.1. Property `stack > cronJobs > ^.*$ > rollout > strategy`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

**Description:** Specifies the rollout strategy for the application.

| Property                                                      | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [blueGreen](#cronJobs_pattern1_rollout_strategy_blueGreen ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen"></a>7.1.37.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |
| **Default**               | `"blueGreen"`    |

| Property                                                                                      | Pattern | Type    | Deprecated | Definition                      | Title/Description                                                                                                       |
| --------------------------------------------------------------------------------------------- | ------- | ------- | ---------- | ------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| - [activeService](#cronJobs_pattern1_rollout_strategy_blueGreen_activeService )               | No      | string  | No         | -                               | Name of the service that the rollout modifies as the active service.                                                    |
| - [autoPromotionEnabled](#cronJobs_pattern1_rollout_strategy_blueGreen_autoPromotionEnabled ) | No      | boolean | No         | -                               | indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state. |
| - [prePromotionAnalysis](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis ) | No      | object  | No         | In #/properties/rolloutAnalysis | configuration to run analysis before a selector switch                                                                  |
| - [previewService](#cronJobs_pattern1_rollout_strategy_blueGreen_previewService )             | No      | string  | No         | -                               | Name of the service that the rollout modifies as the preview service.                                                   |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_activeService"></a>7.1.37.1.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > activeService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the active service.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_autoPromotionEnabled"></a>7.1.37.1.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > autoPromotionEnabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** indicates if the rollout should automatically promote the new ReplicaSet to the active service or enter a paused state.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis"></a>7.1.37.1.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis`

|                           |                              |
| ------------------------- | ---------------------------- |
| **Type**                  | `object`                     |
| **Required**              | No                           |
| **Additional properties** | Any type allowed             |
| **Defined in**            | #/properties/rolloutAnalysis |

**Description:** configuration to run analysis before a selector switch

| Property                                                                                                         | Pattern | Type            | Deprecated | Definition | Title/Description                                                       |
| ---------------------------------------------------------------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------------------------------------------------------------- |
| - [analysisRunMetadata](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata ) | No      | object          | No         | -          | extra labels to add to the AnalysisRun                                  |
| - [args](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args )                               | No      | array of object | No         | -          | the arguments that will be added to the AnalysisRuns                    |
| - [templates](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates )                     | No      | array of object | No         | -          | reference to a list of analysis templates to combine for an AnalysisRun |
| - [](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_additionalProperties )                   | No      | object          | No         | -          | -                                                                       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata"></a>7.1.37.1.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** extra labels to add to the AnalysisRun

| Property                                                                                                             | Pattern | Type   | Deprecated | Definition | Title/Description                                |
| -------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ------------------------------------------------ |
| - [annotations](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations ) | No      | object | No         | -          | additional annotations to add to the AnalysisRun |
| - [labels](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels )           | No      | object | No         | -          | additional labels to add to the AnalysisRun      |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_annotations"></a>7.1.37.1.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional annotations to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_analysisRunMetadata_labels"></a>7.1.37.1.1.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > analysisRunMetadata > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** additional labels to add to the AnalysisRun

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args"></a>7.1.37.1.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** the arguments that will be added to the AnalysisRuns

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                             | Description |
| ------------------------------------------------------------------------------------------- | ----------- |
| [args items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items"></a>7.1.37.1.1.3.2.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [name](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name )           | No      | string | No         | -          | -                 |
| - [value](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value )         | No      | string | No         | -          | -                 |
| - [valueFrom](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom ) | No      | object | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_name"></a>7.1.37.1.1.3.2.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_value"></a>7.1.37.1.1.3.2.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > value`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom"></a>7.1.37.1.1.3.2.1.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                                | Pattern | Type             | Deprecated | Definition | Title/Description |
| --------------------------------------------------------------------------------------------------------------------------------------- | ------- | ---------------- | ---------- | ---------- | ----------------- |
| - [fieldRef](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef )                         | No      | object           | No         | -          | -                 |
| - [podTemplateHashValue](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue ) | No      | enum (of string) | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef"></a>7.1.37.1.1.3.2.1.3.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| -------------------------------------------------------------------------------------------------------------------------- | ------- | ------ | ---------- | ---------- | ----------------- |
| - [fieldPath](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath ) | No      | string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_fieldRef_fieldPath"></a>7.1.37.1.1.3.2.1.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > fieldRef > fieldPath`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_args_items_valueFrom_podTemplateHashValue"></a>7.1.37.1.1.3.2.1.3.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > args > args items > valueFrom > podTemplateHashValue`

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "Latest"
* "Stable"

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates"></a>7.1.37.1.1.3.3. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of object` |
| **Required** | No                |

**Description:** reference to a list of analysis templates to combine for an AnalysisRun

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                                                       | Description |
| ----------------------------------------------------------------------------------------------------- | ----------- |
| [templates items](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items) | -           |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items"></a>7.1.37.1.1.3.3.1. stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                                                                           | Pattern | Type    | Deprecated | Definition | Title/Description                                                         |
| ------------------------------------------------------------------------------------------------------------------ | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------- |
| - [clusterScope](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope ) | No      | boolean | No         | -          | Whether to look for the templateName at cluster scope or namespace scope. |
| - [templateName](#cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName ) | No      | string  | No         | -          |  name of the AnalysisTemplate to use for the rollout analysis             |

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_clusterScope"></a>7.1.37.1.1.3.3.1.1. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > clusterScope`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Whether to look for the templateName at cluster scope or namespace scope.

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_prePromotionAnalysis_templates_items_templateName"></a>7.1.37.1.1.3.3.1.2. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > prePromotionAnalysis > templates > templates items > templateName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:**  name of the AnalysisTemplate to use for the rollout analysis

###### <a name="cronJobs_pattern1_rollout_strategy_blueGreen_previewService"></a>7.1.37.1.1.4. Property `stack > cronJobs > ^.*$ > rollout > strategy > blueGreen > previewService`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service that the rollout modifies as the preview service.

#### <a name="cronJobs_pattern1_s3Storage"></a>7.1.38. Property `stack > cronJobs > ^.*$ > s3Storage`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

| Property                                                             | Pattern | Type                      | Deprecated | Definition | Title/Description                           |
| -------------------------------------------------------------------- | ------- | ------------------------- | ---------- | ---------- | ------------------------------------------- |
| - [accessModes](#cronJobs_pattern1_s3Storage_accessModes )           | No      | array of enum (of string) | No         | -          | Access modes for the S3 storage             |
| - [annotations](#cronJobs_pattern1_s3Storage_annotations )           | No      | object                    | No         | -          | Additional annotations for PV/PVC           |
| - [bucketName](#cronJobs_pattern1_s3Storage_bucketName )             | No      | string                    | No         | -          | S3 bucket name                              |
| - [capacity](#cronJobs_pattern1_s3Storage_capacity )                 | No      | string                    | No         | -          | Storage capacity                            |
| - [enabled](#cronJobs_pattern1_s3Storage_enabled )                   | No      | boolean                   | No         | -          | Enable S3 CSI storage                       |
| - [labels](#cronJobs_pattern1_s3Storage_labels )                     | No      | object                    | No         | -          | Additional labels for PV/PVC                |
| - [pvName](#cronJobs_pattern1_s3Storage_pvName )                     | No      | string                    | No         | -          | Custom PV name (auto-generated if empty)    |
| - [pvcName](#cronJobs_pattern1_s3Storage_pvcName )                   | No      | string                    | No         | -          | Custom PVC name (auto-generated if empty)   |
| - [reclaimPolicy](#cronJobs_pattern1_s3Storage_reclaimPolicy )       | No      | string                    | No         | -          | Reclaim policy for the PV                   |
| - [region](#cronJobs_pattern1_s3Storage_region )                     | No      | string                    | No         | -          | AWS region                                  |
| - [volumeAttributes](#cronJobs_pattern1_s3Storage_volumeAttributes ) | No      | object                    | No         | -          | Additional CSI volume attributes            |
| - [volumeHandle](#cronJobs_pattern1_s3Storage_volumeHandle )         | No      | string                    | No         | -          | CSI volume handle (auto-generated if empty) |

##### <a name="cronJobs_pattern1_s3Storage_accessModes"></a>7.1.38.1. Property `stack > cronJobs > ^.*$ > s3Storage > accessModes`

|              |                             |
| ------------ | --------------------------- |
| **Type**     | `array of enum (of string)` |
| **Required** | No                          |

**Description:** Access modes for the S3 storage

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [accessModes items](#cronJobs_pattern1_s3Storage_accessModes_items) | -           |

###### <a name="cronJobs_pattern1_s3Storage_accessModes_items"></a>7.1.38.1.1. stack > cronJobs > ^.*$ > s3Storage > accessModes > accessModes items

|              |                    |
| ------------ | ------------------ |
| **Type**     | `enum (of string)` |
| **Required** | No                 |

Must be one of:
* "ReadWriteOnce"
* "ReadOnlyMany"
* "ReadWriteMany"
* "ReadWriteOncePod"

##### <a name="cronJobs_pattern1_s3Storage_annotations"></a>7.1.38.2. Property `stack > cronJobs > ^.*$ > s3Storage > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional annotations for PV/PVC

##### <a name="cronJobs_pattern1_s3Storage_bucketName"></a>7.1.38.3. Property `stack > cronJobs > ^.*$ > s3Storage > bucketName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** S3 bucket name

##### <a name="cronJobs_pattern1_s3Storage_capacity"></a>7.1.38.4. Property `stack > cronJobs > ^.*$ > s3Storage > capacity`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Storage capacity

##### <a name="cronJobs_pattern1_s3Storage_enabled"></a>7.1.38.5. Property `stack > cronJobs > ^.*$ > s3Storage > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable S3 CSI storage

##### <a name="cronJobs_pattern1_s3Storage_labels"></a>7.1.38.6. Property `stack > cronJobs > ^.*$ > s3Storage > labels`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional labels for PV/PVC

##### <a name="cronJobs_pattern1_s3Storage_pvName"></a>7.1.38.7. Property `stack > cronJobs > ^.*$ > s3Storage > pvName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom PV name (auto-generated if empty)

##### <a name="cronJobs_pattern1_s3Storage_pvcName"></a>7.1.38.8. Property `stack > cronJobs > ^.*$ > s3Storage > pvcName`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Custom PVC name (auto-generated if empty)

##### <a name="cronJobs_pattern1_s3Storage_reclaimPolicy"></a>7.1.38.9. Property `stack > cronJobs > ^.*$ > s3Storage > reclaimPolicy`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Reclaim policy for the PV

##### <a name="cronJobs_pattern1_s3Storage_region"></a>7.1.38.10. Property `stack > cronJobs > ^.*$ > s3Storage > region`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** AWS region

##### <a name="cronJobs_pattern1_s3Storage_volumeAttributes"></a>7.1.38.11. Property `stack > cronJobs > ^.*$ > s3Storage > volumeAttributes`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Additional CSI volume attributes

##### <a name="cronJobs_pattern1_s3Storage_volumeHandle"></a>7.1.38.12. Property `stack > cronJobs > ^.*$ > s3Storage > volumeHandle`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** CSI volume handle (auto-generated if empty)

#### <a name="cronJobs_pattern1_securityContext"></a>7.1.39. Property `stack > cronJobs > ^.*$ > securityContext`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Security context

#### <a name="cronJobs_pattern1_service"></a>7.1.40. Property `stack > cronJobs > ^.*$ > service`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Service configuration

| Property                                   | Pattern | Type   | Deprecated | Definition | Title/Description |
| ------------------------------------------ | ------- | ------ | ---------- | ---------- | ----------------- |
| - [port](#cronJobs_pattern1_service_port ) | No      | number | No         | -          | Service port      |
| - [type](#cronJobs_pattern1_service_type ) | No      | string | No         | -          | Service type      |

##### <a name="cronJobs_pattern1_service_port"></a>7.1.40.1. Property `stack > cronJobs > ^.*$ > service > port`

|              |          |
| ------------ | -------- |
| **Type**     | `number` |
| **Required** | No       |

**Description:** Service port

##### <a name="cronJobs_pattern1_service_type"></a>7.1.40.2. Property `stack > cronJobs > ^.*$ > service > type`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Service type

#### <a name="cronJobs_pattern1_serviceAccount"></a>7.1.41. Property `stack > cronJobs > ^.*$ > serviceAccount`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Service account configuration

| Property                                                        | Pattern | Type    | Deprecated | Definition | Title/Description                                                                                                   |
| --------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------------------------------------- |
| - [annotations](#cronJobs_pattern1_serviceAccount_annotations ) | No      | object  | No         | -          | Annotations to add to the service account                                                                           |
| - [automount](#cronJobs_pattern1_serviceAccount_automount )     | No      | boolean | No         | -          | Specifies whether to automatically mount a ServiceAccount's API credentials                                         |
| - [create](#cronJobs_pattern1_serviceAccount_create )           | No      | boolean | No         | -          | Specifies whether a service account should be created                                                               |
| - [name](#cronJobs_pattern1_serviceAccount_name )               | No      | string  | No         | -          | Name of the service account to use (if not set and create is true, a name is generated using the fullname template) |

##### <a name="cronJobs_pattern1_serviceAccount_annotations"></a>7.1.41.1. Property `stack > cronJobs > ^.*$ > serviceAccount > annotations`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Annotations to add to the service account

##### <a name="cronJobs_pattern1_serviceAccount_automount"></a>7.1.41.2. Property `stack > cronJobs > ^.*$ > serviceAccount > automount`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Specifies whether to automatically mount a ServiceAccount's API credentials

##### <a name="cronJobs_pattern1_serviceAccount_create"></a>7.1.41.3. Property `stack > cronJobs > ^.*$ > serviceAccount > create`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Specifies whether a service account should be created

##### <a name="cronJobs_pattern1_serviceAccount_name"></a>7.1.41.4. Property `stack > cronJobs > ^.*$ > serviceAccount > name`

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

**Description:** Name of the service account to use (if not set and create is true, a name is generated using the fullname template)

#### <a name="cronJobs_pattern1_shareProcessNamespace"></a>7.1.42. Property `stack > cronJobs > ^.*$ > shareProcessNamespace`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Share process namespace

#### <a name="cronJobs_pattern1_sidecars"></a>7.1.43. Property `stack > cronJobs > ^.*$ > sidecars`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** List of sidecars

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_startupProbe"></a>7.1.44. Property `stack > cronJobs > ^.*$ > startupProbe`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Startup probe configuration

| Property                                                                      | Pattern | Type    | Deprecated | Definition | Title/Description                                                                     |
| ----------------------------------------------------------------------------- | ------- | ------- | ---------- | ---------- | ------------------------------------------------------------------------------------- |
| - [enabled](#cronJobs_pattern1_startupProbe_enabled )                         | No      | boolean | No         | -          | Enable the startup probe                                                              |
| - [exec](#cronJobs_pattern1_startupProbe_exec )                               | No      | object  | No         | -          | Exec probe configuration                                                              |
| - [failureThreshold](#cronJobs_pattern1_startupProbe_failureThreshold )       | No      | integer | No         | -          | Number of failures before the probe is considered failed                              |
| - [initialDelaySeconds](#cronJobs_pattern1_startupProbe_initialDelaySeconds ) | No      | integer | No         | -          | Number of seconds after the container has started before the probe is first initiated |
| - [periodSeconds](#cronJobs_pattern1_startupProbe_periodSeconds )             | No      | integer | No         | -          | How often to perform the probe                                                        |
| - [successThreshold](#cronJobs_pattern1_startupProbe_successThreshold )       | No      | integer | No         | -          | Number of successes before the probe is considered successful                         |
| - [timeoutSeconds](#cronJobs_pattern1_startupProbe_timeoutSeconds )           | No      | integer | No         | -          | Timeout for the probe                                                                 |

##### <a name="cronJobs_pattern1_startupProbe_enabled"></a>7.1.44.1. Property `stack > cronJobs > ^.*$ > startupProbe > enabled`

|              |           |
| ------------ | --------- |
| **Type**     | `boolean` |
| **Required** | No        |

**Description:** Enable the startup probe

##### <a name="cronJobs_pattern1_startupProbe_exec"></a>7.1.44.2. Property `stack > cronJobs > ^.*$ > startupProbe > exec`

|                           |                  |
| ------------------------- | ---------------- |
| **Type**                  | `object`         |
| **Required**              | No               |
| **Additional properties** | Any type allowed |

**Description:** Exec probe configuration

| Property                                                   | Pattern | Type            | Deprecated | Definition | Title/Description |
| ---------------------------------------------------------- | ------- | --------------- | ---------- | ---------- | ----------------- |
| - [command](#cronJobs_pattern1_startupProbe_exec_command ) | No      | array of string | No         | -          | -                 |

###### <a name="cronJobs_pattern1_startupProbe_exec_command"></a>7.1.44.2.1. Property `stack > cronJobs > ^.*$ > startupProbe > exec > command`

|              |                   |
| ------------ | ----------------- |
| **Type**     | `array of string` |
| **Required** | No                |

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | See below          |

| Each item of this array must be                                     | Description |
| ------------------------------------------------------------------- | ----------- |
| [command items](#cronJobs_pattern1_startupProbe_exec_command_items) | -           |

###### <a name="cronJobs_pattern1_startupProbe_exec_command_items"></a>7.1.44.2.1.1. stack > cronJobs > ^.*$ > startupProbe > exec > command > command items

|              |          |
| ------------ | -------- |
| **Type**     | `string` |
| **Required** | No       |

##### <a name="cronJobs_pattern1_startupProbe_failureThreshold"></a>7.1.44.3. Property `stack > cronJobs > ^.*$ > startupProbe > failureThreshold`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of failures before the probe is considered failed

##### <a name="cronJobs_pattern1_startupProbe_initialDelaySeconds"></a>7.1.44.4. Property `stack > cronJobs > ^.*$ > startupProbe > initialDelaySeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of seconds after the container has started before the probe is first initiated

##### <a name="cronJobs_pattern1_startupProbe_periodSeconds"></a>7.1.44.5. Property `stack > cronJobs > ^.*$ > startupProbe > periodSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** How often to perform the probe

##### <a name="cronJobs_pattern1_startupProbe_successThreshold"></a>7.1.44.6. Property `stack > cronJobs > ^.*$ > startupProbe > successThreshold`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Number of successes before the probe is considered successful

##### <a name="cronJobs_pattern1_startupProbe_timeoutSeconds"></a>7.1.44.7. Property `stack > cronJobs > ^.*$ > startupProbe > timeoutSeconds`

|              |           |
| ------------ | --------- |
| **Type**     | `integer` |
| **Required** | No        |

**Description:** Timeout for the probe

#### <a name="cronJobs_pattern1_tolerations"></a>7.1.45. Property `stack > cronJobs > ^.*$ > tolerations`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Tolerations for the pod

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_topologySpreadConstraints"></a>7.1.46. Property `stack > cronJobs > ^.*$ > topologySpreadConstraints`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Topology spread constraints for the pod

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_volumeMounts"></a>7.1.47. Property `stack > cronJobs > ^.*$ > volumeMounts`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional volume mounts on the output Deployment definition

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

#### <a name="cronJobs_pattern1_volumes"></a>7.1.48. Property `stack > cronJobs > ^.*$ > volumes`

|              |         |
| ------------ | ------- |
| **Type**     | `array` |
| **Required** | No      |

**Description:** Additional volumes on the output Deployment definition

|                      | Array restrictions |
| -------------------- | ------------------ |
| **Min items**        | N/A                |
| **Max items**        | N/A                |
| **Items unicity**    | False              |
| **Additional items** | False              |
| **Tuple validation** | N/A                |

----------------------------------------------------------------------------------------------------------------------------
