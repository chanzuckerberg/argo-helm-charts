{{/*
Expand the name of the chart.
*/}}
{{- define "stack.name" -}}
{{- default .Chart.Name .nameOverride | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{- define "service.name" -}}
{{- .Values.name | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{- define "service.backend.name.ingress" -}}
{{- if .Values.ingress.oidcProtected -}}
{{- include "oidcProxy.name" . }}
{{- else }}
{{- include "service.fullname" . }}
{{- end -}}
{{- end -}}

{{- define "service.backend.port.ingress" -}}
{{- if .Values.ingress.oidcProtected -}}
{{- include "oidcProxy.port" . }}
{{- else }}
{{- .Values.service.port | int }}
{{- end -}}
{{- end -}}

{{- define "service.backend" -}}
name: {{ include "service.backend.name.ingress" . }}
port:
    number: {{ include "service.backend.port.ingress" . }}
{{- end -}}

{{- define "service.backend.name" -}}
{{- if or .Values.ingress.oidcProtected .Values.gateway.oidcProtected -}}
{{- include "oidcProxy.name" . }}
{{- else }}
{{- include "service.fullname" . }}
{{- end -}}
{{- end -}}

{{- define "service.backend.useBackendResource" -}}
{{- if and (.Values.gateway).backendTLS -}}
{{- if and .Values.gateway.backendTLS.enabled .Values.gateway.backendTLS.insecureSkipVerify -}}true{{- end -}}
{{- end -}}
{{- end -}}

{{- define "service.backend.resourceName" -}}
{{- printf "%s-backend" (include "service.fullname" .) -}}
{{- end -}}

{{- define "service.backend.refs" -}}
{{- if eq (include "service.backend.useBackendResource" .) "true" -}}
- group: gateway.envoyproxy.io
  kind: Backend
  name: {{ include "service.backend.resourceName" . }}
{{- else -}}
- name: {{ include "service.backend.name" . }}
  port: {{ include "service.backend.port" . }}
{{- end -}}
{{- end -}}

{{- define "service.backend.refs.direct" -}}
{{- if eq (include "service.backend.useBackendResource" .) "true" -}}
- group: gateway.envoyproxy.io
  kind: Backend
  name: {{ include "service.backend.resourceName" . }}
{{- else -}}
- name: {{ include "service.fullname" . }}
  port: {{ .Values.service.port | int }}
{{- end -}}
{{- end -}}

{{- define "service.backend.port" -}}
{{- if or .Values.ingress.oidcProtected .Values.gateway.oidcProtected -}}
{{- include "oidcProxy.port" . }}
{{- else }}
{{- .Values.service.port | int }}
{{- end -}}
{{- end -}}


{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "stack.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}


{{- define "certManagerAnnotations" -}}
cert-manager.io/cluster-issuer: letsencrypt-prod
cert-manager.io/private-key-algorithm: RSA
cert-manager.io/private-key-size: '4096'
external-dns.alpha.kubernetes.io/exclude: "false"
external-dns.alpha.kubernetes.io/target: "access.{{ include "clusterBaseDomain" . }}"
{{- end -}}


{{- define "service.fullname" -}}
{{ include "stack.fullname" . | lower }}-{{ include "service.name" . | lower }}
{{- end }}

{{/*
Name of the vanity-domain ListenerSet. Referenced by both the ListenerSet itself
and the HTTPRoute parentRef, so keep it in one place.
*/}}
{{- define "service.vanityListenerSetName" -}}
{{ include "service.fullname" . }}-vanity
{{- end }}

{{/*
Owning vanity ListenerSet for a hostname. A hostname may be declared once per
Gateway, so the first service to declare it owns the object and the others
parentRef it. Input: dict "root" $global "hostname" <string>.
*/}}
{{- define "stack.canonicalVanityListenerSet" -}}
{{- $root := .root -}}
{{- $want := .hostname -}}
{{- $found := "" -}}
{{- range $sname, $sv := fromYaml (include "stack.networkEndpoints" $root) -}}
  {{- $sv = $sv | default dict -}}
  {{- $g := mergeOverwrite (deepCopy (($root.Values.global).gateway | default dict)) ((get $sv "gateway") | default dict) -}}
  {{- $off := and (hasKey $g "enabled") (eq ($g.enabled | toString) "false") -}}
  {{- if not $off -}}
    {{- $ctx := dict "Chart" $root.Chart "Release" $root.Release "Values" (dict "name" $sname) -}}
    {{- $base := include "service.vanityListenerSetName" $ctx -}}
    {{- if and (eq $found "") ($g.vanity).enabled (eq ((($g.vanity).hostname) | default $g.host) $want) -}}
      {{- $found = $base -}}
    {{- end -}}
    {{- range $i, $rule := ($g.rules | default list) -}}
      {{- if and (eq $found "") ($rule.vanity).enabled (eq (($rule.vanity).hostname | default $rule.host) $want) -}}
        {{- $found = printf "%s-rule-%d" $base $i -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $found -}}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "stack.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}

{{- define "stack.labels" -}}
helm.sh/chart: {{ include "stack.chart" . }}
{{ include "stack.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "stack.annotations" -}}
{{ toYaml .Values.annotations }}
{{- end }}

{{- define "service.labels" -}}
{{ include "stack.labels" . }}
{{ include "service.selectorLabels" . }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "stack.selectorLabels" -}}
app.kubernetes.io/name: {{ include "stack.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- with .Values.argusMetadata }}
{{- if .appName }}
argus/app-name: {{ .appName }}
{{- end }}
{{- if .envName }}
argus/env-name: {{ .envName }}
{{- end }}
{{- if .stackName }}
argus/stack-name: {{ .stackName }}
{{- end }}
{{- if .repoName }}
argus/repo-name: {{ .repoName }}
{{- end }}
{{- if .repoOwner }}
argus/repo-owner: {{ .repoOwner }}
{{- end }}
{{- end }}
{{- end }}

{{- define "service.selectorLabels" -}}
{{- if .Values.agentEndpoint }}
agents.czi.team/agent: {{ .Values.agentName }}
{{- else }}
app.kubernetes.io/service: {{ include "service.fullname" . }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "service.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "service.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "cronjob.isEnabled" -}}
{{- if hasKey .Values "enabled" -}}
{{- .Values.enabled -}}
{{- else -}}
true
{{- end -}}
{{- end -}}

{{- define "service.nonsensitiveEnvVars" -}}
{{- $all := list }}
{{- range $i, $envHolder := . -}}
{{- $all = concat $all (default (list) $envHolder.env) }}
{{- end -}}
{{- $latest := dict }}
{{- range $e := $all -}}
{{- $_ := set $latest $e.name $e }}
{{- end -}}
{{- $envs := list }}
{{- $emitted := dict }}
{{- range $e := $all -}}
{{- if not (hasKey $emitted $e.name) }}
{{- $_ := set $emitted $e.name true }}
{{- $envs = append $envs (get $latest $e.name) }}
{{- end }}
{{- end -}}
{{- if ne (len $envs) 0 -}}
env:
{{ toYaml $envs }}
{{- else -}}
env: []
{{- end }}
{{- end }}

{{- define "stack.agentEnvironment" -}}
{{- $rendered := fromYaml (include "service.nonsensitiveEnvVars" (list .root.Values.global .workload)) -}}
{{- toYaml ($rendered.env | default list) -}}
{{- end }}

{{- define "stack.agentEnvironmentFrom" -}}
{{- $values := fromYaml (.root.Values.global | toYaml) -}}
{{- $values = mergeOverwrite $values .workload -}}
{{- $ctx := dict "Chart" .root.Chart "Release" .root.Release "Capabilities" .root.Capabilities "Values" $values -}}
{{- $rendered := fromYaml (include "service.configuration" $ctx | default "{}") -}}
{{- toYaml ($rendered.envFrom | default list) -}}
{{- end }}

{{- define "image" -}}
{{- if typeIs "string" .image }}
image: {{ .image }}
{{ else }}
image: {{ .image.repository }}:{{ .image.tag | default "latest" }}
{{- end }}
{{- end }}

{{- define "service.claimName" -}}
{{- if .Values.persistence.existingClaim }}
    {{- printf "%s" .Values.persistence.existingClaim -}}
{{- else -}}
    {{- printf "%s" (include "service.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
The default values in this chart adds httpGet probes to the deployment.
Container probes cannot have both httpGet and tcpSocket fields, so we use omit to remove one of them.
*/}}
{{- define "container.probe" -}}
{{- if or .tcpSocket .exec -}}
{{- toYaml (omit . "httpGet") }}
{{- else }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{- define "baseDomain" -}}
{{- $splits := (splitList "." .Values.ingress.host) }}
{{- $last := $splits | last }}
{{- $secondLast := $splits | initial | last }}
{{- printf "%s.%s" $secondLast $last -}}
{{- end -}}

{{- define "clusterBaseDomain" -}}
{{ splitList "." .Values.ingress.host | rest | join "." }} 
{{- end -}}

{{- define "oidcProxy.name" -}}
{{ include "stack.fullname" . | lower }}-oidc-proxy
{{- end -}}

{{- define "oidcProxy.port" -}}
{{ .Values.oidcProxy.port | default 4180 | int  }}
{{- end }}

{{- define "oidcProxy.labels" -}}
{{- include "oidcProxy.selectorLabels" . }}
k8s-app:  {{ include "oidcProxy.name" . }}
{{- end }}

{{- define "oidcProxy.selectorLabels" -}}
app.kubernetes.io/name: {{ include "oidcProxy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "oidcProxy.envFrom" -}}
{{- $envFrom := list -}}
{{- with fromYaml (include "service.configuration" .) -}}
{{- $envFrom = concat $envFrom (default (list) .envFrom) -}}
{{- end -}}
{{- $envFrom = concat $envFrom (default (list) .Values.oidcProxy.additionalSecrets) -}}
{{- toYaml $envFrom -}}
{{- end -}}

{{- define "oidcProxy.authDomain" -}}
{{ .Values.ingress.host }}
{{- end -}}

{{- define "ingress.servedHosts" -}}
{{- $v := .Values -}}
{{- $hosts := list $v.ingress.host -}}
{{- range $v.ingress.rules -}}
  {{- $hosts = append $hosts (.host | default $v.ingress.host) -}}
{{- end -}}
{{- toJson ($hosts | uniq) -}}
{{- end -}}

{{- define "validate.gatewayIngressCoexistence" -}}
{{- $ := .ctx -}}
{{- if and $.Values.gateway.enabled $.Values.ingress.enabled -}}
  {{- $v := $.Values -}}
  {{- $gatewayOidc := eq (include "securityPolicy.isOidc" (dict "root" .root "name" .name)) "true" -}}
  {{- $owner := $v.gateway.dnsOwner | default "ingress" -}}
  {{- if not (or (eq $owner "ingress") (eq $owner "gateway")) -}}
    {{- fail (printf "gateway.dnsOwner must be \"ingress\" or \"gateway\" when ingress and gateway are both enabled (got %q). Coexistence renders both routing modes and external-dns publishes only the dnsOwner side. Flip it to \"gateway\" to move DNS to the Envoy gateway NLB." $owner) -}}
  {{- end -}}
  {{- if and $gatewayOidc (not $v.ingress.oidcProtected) -}}
    {{- fail "an OIDC gateway.securityPolicy requires ingress.oidcProtected during coexistence: the still-serving nginx Ingress would expose the app without authentication. Set ingress.oidcProtected: true or disable the ingress." -}}
  {{- end -}}
  {{- if eq $owner "gateway" -}}
    {{- if $v.gateway.tlsPassthrough.enabled -}}
      {{- fail "gateway.dnsOwner: gateway cannot be combined with gateway.tlsPassthrough.enabled during coexistence: a TLSRoute is not an external-dns source, so excluding the Ingress would delete the host's DNS record." -}}
    {{- end -}}
    {{- $gwHosts := list $v.gateway.host -}}
    {{- range $v.gateway.rules -}}
      {{- $gwHosts = append $gwHosts .host -}}
    {{- end -}}
    {{- $missing := list -}}
    {{- range (fromJsonArray (include "ingress.servedHosts" $)) -}}
      {{- if not (has . $gwHosts) -}}
        {{- $missing = append $missing . -}}
      {{- end -}}
    {{- end -}}
    {{- if gt (len $missing) 0 -}}
      {{- fail (printf "gateway.dnsOwner: gateway would strip DNS for ingress hosts the gateway does not serve: %s. Add matching gateway.rules entries (or drop the ingress rules) before flipping." (join ", " $missing)) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{- define "gateway.coexistDnsAnnotations" -}}
{{- $v := .root.Values -}}
{{- if and $v.gateway.enabled $v.ingress.enabled (eq ($v.gateway.dnsOwner | default "ingress") "ingress") -}}
{{- if has .host (fromJsonArray (include "ingress.servedHosts" .root)) -}}
external-dns.alpha.kubernetes.io/exclude: "true"
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "ingress.coexistDnsAnnotations" -}}
{{- if and .Values.gateway.enabled .Values.ingress.enabled (eq (.Values.gateway.dnsOwner | default "ingress") "gateway") -}}
external-dns.alpha.kubernetes.io/exclude: "true"
{{- end -}}
{{- end -}}

{{/*
Validate that each gateway rule has a host specified
*/}}
{{- define "validate.gatewayRuleHost" -}}
{{- range $i, $rule := .Values.gateway.rules -}}
  {{- if not $rule.host -}}
    {{- fail (printf "gateway.rules[%d].host is required. Each rule must specify a host." $i) -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Return the OIDC issuer URL.
(Envoy Gateway does not yet support issuerRef, so this must be a string.)
*/}}
{{- define "securityPolicy.issuer" -}}
{{- $iss := ((.policy.oidc | default dict).provider | default dict).issuer -}}
{{- if not $iss -}}
  {{- fail (printf "securityPolicies.%s.oidc.provider.issuer is required" .name) -}}
{{- end -}}
{{- $iss -}}
{{- end -}}

{{- define "securityPolicy.secretName" -}}
{{- $o := .policy.oidc | default dict -}}
{{- if ($o.clientSecretFrom).property -}}
{{- include "securityPolicy.projectedSecretName" (dict "release" .release "name" .name) -}}
{{- else if $o.clientSecretName -}}{{- $o.clientSecretName -}}{{- else -}}{{- $o.globalSecretName | default "argus-global-oidc" -}}{{- end -}}
{{- end -}}

{{- define "securityPolicy.projectedSecretName" -}}
{{- printf "%s-oidc-%s" .release .name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "securityPolicy.clientSecretFromRemoteKey" -}}
{{- $from := .from -}}
{{- $key := $from.remoteKey | default ((((.root.Values.global).appSecrets).envSecret).secretKey) -}}
{{- if not $key -}}
{{- fail (printf "securityPolicies.%s.oidc.clientSecretFrom is set but no remote secret could be resolved. The chart falls back to global.appSecrets.envSecret.secretKey, which is empty here, so set clientSecretFrom.remoteKey explicitly." .name) -}}
{{- end -}}
{{- $key -}}
{{- end -}}


{{/*
Whether the OIDC OAuth2 callback path is already reachable through one of the
configured gateway paths. Input dict: "paths" (list), "callback" (string,
defaults to "/oauth2/callback"). A PathPrefix path covers the callback when it is
"/" or a path-segment prefix of the callback; an Exact path covers it only on an
exact match. Returns "true"/"".
*/}}
{{- define "gateway.oidcCallbackCovered" -}}
{{- $callback := .callback | default "/oauth2/callback" -}}
{{- $covered := false -}}
{{- range .paths -}}
  {{- if eq .pathType "Exact" -}}
    {{- if eq .path $callback -}}
      {{- $covered = true -}}
    {{- end -}}
  {{- else if eq .pathType "RegularExpression" -}}
  {{- else -}}
    {{- $p := trimSuffix "/" .path -}}
    {{- if or (eq $p "") (eq $p $callback) (hasPrefix (printf "%s/" $p) $callback) -}}
      {{- $covered = true -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if $covered -}}true{{- end -}}
{{- end -}}

{{/*
OIDC base path: the URL prefix the OAuth2 callback and logout live under. Envoy
Gateway requires redirectURL and logoutPath to match the service's own HTTPRoute,
otherwise the OAuth2 filter never sees those requests. The chart scans the service's
gateway.paths for the first non-root PathPrefix path and uses it as the base so
users never have to hand-write /oauth2 or /logout paths. When no such path exists
(all paths are root or Exact) the base path is empty, placing the callback at the
host root. Input dict: "paths" (list). Returns "" or "/prefix" with no trailing slash.
*/}}
{{- define "oidcProxyGateway.basePath" -}}
{{- $paths := .paths | default list -}}
{{- $base := "" -}}
{{- $found := false -}}
{{- range $paths -}}
  {{- if and (not $found) (ne (.pathType | default "Prefix") "Exact") (ne (.pathType | default "Prefix") "RegularExpression") (ne (.path | default "/") "/") -}}
    {{- $base = trimSuffix "/" .path -}}
    {{- $found = true -}}
  {{- end -}}
{{- end -}}
{{- $base -}}
{{- end -}}

{{/*
Fail when an OIDC-protected service's derived OAuth2 callback is not reachable
through any of its gateway paths. This turns an otherwise silent misconfiguration
(the login flow breaks because the callback lands on no route, or the wrong one)
into a clear render-time error. Input: the service context.
*/}}
{{- define "validate.groupCallbackReachable" -}}
{{- $root := .root -}}
{{- $primary := include "securityPolicy.groupPrimary" (dict "root" $root "key" .key) -}}
{{- if ne $primary "" -}}
  {{- if eq (include "securityPolicy.isOidc" (dict "root" $root "name" $primary)) "true" -}}
    {{- $pv := fromYaml (include "service.context" (dict "root" $root "name" $primary)) -}}
    {{- $basePath := include "oidcProxyGateway.basePath" (dict "paths" ($pv.gateway.paths | default list)) -}}
    {{- $callback := printf "%s/oauth2/callback" $basePath -}}
    {{- $covered := false -}}
    {{- range $n := (splitList " " (include "securityPolicy.groupMembers" (dict "root" $root "key" .key))) -}}
      {{- if ne $n "" -}}
        {{- $v := fromYaml (include "service.context" (dict "root" $root "name" $n)) -}}
        {{- if eq (include "gateway.oidcCallbackCovered" (dict "paths" ($v.gateway.paths | default list) "callback" $callback)) "true" -}}
          {{- $covered = true -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}
    {{- if not $covered -}}
      {{- fail (printf "the OAuth2 callback %q for security policy %q is not covered by any gateway path of the services attached to it (%s), so login would fail. Give one of them a Prefix path that covers it." $callback ((splitList "|" .key) | first) (include "securityPolicy.groupMembers" (dict "root" $root "key" .key))) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Validate that OIDC and basic auth are not both enabled on a gateway service.
A route can carry only one SecurityPolicy, and oidc + basicAuth are independent
auth mechanisms; combining them is unsupported.
*/}}
{{- define "validate.gatewaySecurityExclusive" -}}
{{- range $name, $def := fromYaml (include "securityPolicy.definitions" .) -}}
  {{- if and $def.oidc ($def.basicAuth).enabled -}}
    {{- fail (printf "securityPolicies.%s sets both oidc and basicAuth. Pick one auth method." $name) -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Gateway-only service whose HTTPRoute would target an oauth2-proxy that is not deployed.
Scoped to the post-cutover shape, where no Ingress remains to justify the proxy.
*/}}
{{- define "validate.oidcProxyBackendExists" -}}
{{- $ := .ctx -}}
{{- $v := $.Values -}}
{{- $gatewayOidc := eq (include "securityPolicy.isOidc" (dict "root" .root "name" .name)) "true" -}}
{{- if and $v.gateway.enabled (not $v.ingress.enabled) (not ($v.oidcProxy).enabled) (not $gatewayOidc) (not ($v.gateway.tlsPassthrough).enabled) -}}
  {{- if or $v.ingress.oidcProtected $v.gateway.oidcProtected -}}
    {{- fail (printf "service %q renders an HTTPRoute whose backend is the oauth2-proxy, but the Ingress is gone and global.oidcProxy.enabled is false, so that Service does not exist and the route answers 5xx. Note ingress.oidcProtected selects the proxy for gateway routes too, so removing an ingress block that set it to false is enough to cause this. Set oidcProtected: false on the service, or protect it with an OIDC gateway.securityPolicy." .name) -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Whether the service needs a SecurityPolicy (any of oidc, basicAuth, cors, ipAllowList).
Returns "true"/"" .
*/}}
{{- define "stack.networkEndpoints" -}}
{{- $endpoints := deepCopy (.Values.services | default dict) -}}
{{- range $name, $workload := ((.Values.agents | default dict).workloads | default dict) -}}
  {{- if or (hasKey $workload "service") (hasKey $workload "gateway") -}}
    {{- if ne ($workload.harness | default "") "custom-agent-code" -}}
      {{- fail (printf "agents.workloads.%s networking requires harness: custom-agent-code" $name) -}}
    {{- end -}}
    {{- if $workload.schedule -}}
      {{- fail (printf "agents.workloads.%s networking is not supported for scheduled Agents" $name) -}}
    {{- end -}}
    {{- $targetPort := (($workload.service | default dict).targetPort | default "") -}}
    {{- if or (eq (toString $targetPort) "") (not (regexMatch "^[0-9]+$" (toString $targetPort))) -}}
      {{- fail (printf "agents.workloads.%s networking requires a numeric service.targetPort" $name) -}}
    {{- end -}}
    {{- $endpointName := printf "agent-%s" $name -}}
    {{- if hasKey $endpoints $endpointName -}}
      {{- fail (printf "agents.workloads.%s conflicts with services.%s" $name $endpointName) -}}
    {{- end -}}
    {{- $endpoint := dict
          "agentEndpoint" true
          "agentName" $name
          "ingress" (dict "enabled" false)
          "service" (deepCopy ($workload.service | default dict))
          "gateway" (deepCopy ($workload.gateway | default dict)) -}}
    {{- if $workload.annotations -}}
      {{- $_ := set $endpoint "annotations" (deepCopy $workload.annotations) -}}
    {{- end -}}
    {{- $_ := set $endpoints $endpointName $endpoint -}}
  {{- end -}}
{{- end -}}
{{- toYaml $endpoints -}}
{{- end -}}

{{/*
Merged per-service context, mirroring the preamble each gateway template applies:
global values overlaid with the service block, plus the ingress/gateway
auto-enable and auto-disable rules. Takes (dict "root" $ "name" <serviceName>).
*/}}
{{- define "service.context" -}}
{{- $root := .root -}}
{{- $serviceName := .name -}}
{{- $serviceValues := index (fromYaml (include "stack.networkEndpoints" $root)) $serviceName -}}
{{- $values := fromYaml ($root.Values.global | toYaml) -}}
{{- $_ := set $values "name" $serviceName -}}
{{- $values = mergeOverwrite $values $serviceValues -}}
{{- if hasKey $serviceValues "gateway" -}}
  {{- $hasGatewayKeys := include "gateway.hasConfigKeys" (dict "Values" (dict "gateway" ($serviceValues.gateway | default dict))) -}}
  {{- if and $hasGatewayKeys (not (and (hasKey $serviceValues.gateway "enabled") (eq $serviceValues.gateway.enabled false))) -}}
    {{- $_ := set $values.gateway "enabled" true -}}
  {{- end -}}
{{- end -}}
{{- if and (hasKey $serviceValues "ingress") (hasKey $serviceValues.ingress "enabled") $serviceValues.ingress.enabled -}}
  {{- if not (and (hasKey $serviceValues "gateway") (or (hasKey $serviceValues.gateway "enabled") (hasKey $serviceValues.gateway "dnsOwner"))) -}}
    {{- $_ := set $values "gateway" (mergeOverwrite (default dict $values.gateway) (dict "enabled" false)) -}}
  {{- end -}}
{{- end -}}
{{- $values | toYaml -}}
{{- end -}}

{{/*
Declared securityPolicies with the two built-ins merged in, so
gateway.securityPolicy: oidc-protected-default and oidc-identity-headers both
need no configuration.
Takes the root context.
*/}}
{{- define "securityPolicy.definitions" -}}
{{- $declared := .Values.global.securityPolicies | default dict -}}
{{- $builtinOidc := dict
      "provider" (dict "issuer" "https://czi.okta.com")
      "globalSecretName" "argus-global-oidc"
      "scopes" (list "openid" "profile" "email" "groups")
      "denyRedirect" (dict "enabled" true)
      "forwardIDToken" (dict "enabled" true "header" "X-ID-Token")
      "logoutPath" "/logout" -}}
{{/*
oidc-identity-headers: oidc-protected-default plus a JWT provider that reads the
forwarded ID token and copies its claims into the request headers oauth2-proxy
used to set. Opt-in by name, so the default policy and every stack not asking
for it are unaffected. Emits email twice because consumers read either spelling.
*/}}
{{- $builtinIdentityJwt := dict
      "enabled" true
      "providers" (list (dict
        "name" "okta-id-token"
        "issuer" "https://czi.okta.com"
        "remoteJWKSUri" "https://czi.okta.com/oauth2/v1/keys"
        "extractFrom" (dict "headers" (list (dict "name" "X-ID-Token")))
        "claimToHeaders" (list
          (dict "claim" "email" "header" "X-Forwarded-Email")
          (dict "claim" "email" "header" "X-Auth-Request-Email")
          (dict "claim" "sub" "header" "X-Forwarded-User")))) -}}
{{- $authKeys := list "oidc" "basicAuth" "cors" "ipAllowList" "jwt" -}}
{{- $allowedKeys := concat $authKeys (list "annotations") -}}
{{- $merged := dict -}}
{{- range $name, $def := $declared -}}
  {{- if not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?$" $name) -}}
    {{- fail (printf "securityPolicies.%s is not a valid policy name. Use lowercase letters, digits and dashes only: the name becomes part of a Kubernetes object name and of the session cookie names." $name) -}}
  {{- end -}}
  {{- range $k, $_ := ($def | default dict) -}}
    {{- if not (has $k $allowedKeys) -}}
      {{- fail (printf "securityPolicies.%s sets unknown key %q. Valid keys are oidc, basicAuth, cors, ipAllowList, jwt and annotations." $name $k) -}}
    {{- end -}}
  {{- end -}}
  {{- $base := dict -}}
  {{- if or (eq $name "oidc-protected-default") (eq $name "oidc-identity-headers") (hasKey ($def | default dict) "oidc") -}}
    {{- $base = dict "oidc" (deepCopy $builtinOidc) -}}
  {{- end -}}
  {{- if eq $name "oidc-identity-headers" -}}
    {{- $_ := set $base "jwt" (deepCopy $builtinIdentityJwt) -}}
  {{- end -}}
  {{- $entry := mergeOverwrite $base (deepCopy $def) -}}
  {{/*
  The built-in identity provider only works while it agrees with the policy it
  sits in. Two keys can disagree with it, and both would 401 every request
  behind an Accepted policy, so both fail the render instead.

  Declaring your own jwt.providers replaces the built-in list outright, so none
  of this applies. Any other jwt key merges into the built-in and leaves the
  provider in place, so the checks still have to run.
  */}}
  {{- if and (eq $name "oidc-identity-headers") (not (hasKey (($def | default dict).jwt | default dict) "providers")) -}}
    {{- $o := ($entry.oidc | default dict) -}}
    {{/* The provider reads the header forwardIDToken writes, so it must be on. */}}
    {{- if and (hasKey $o "forwardIDToken") (not (($o.forwardIDToken | default dict).enabled | default false)) -}}
      {{- fail "securityPolicies.oidc-identity-headers sets oidc.forwardIDToken.enabled: false, but its JWT provider reads the token from that header, so no request could be verified. Remove the override, or declare your own jwt.providers." -}}
    {{- end -}}
    {{- $hdr := (($o.forwardIDToken | default dict).header | default "X-ID-Token") -}}
    {{- $iss := (($o.provider | default dict).issuer | default "") -}}
    {{/* A non-default issuer means a different IdP, whose JWKS path we cannot
         guess — deriving one produced a wrong URL for Okta custom auth servers. */}}
    {{- if and $iss (ne $iss "https://czi.okta.com") -}}
      {{- fail (printf "securityPolicies.oidc-identity-headers overrides oidc.provider.issuer to %s, but its built-in JWT provider validates against https://czi.okta.com and the JWKS path of another issuer cannot be derived. Declare your own jwt.providers entry with the right issuer and remoteJWKSUri." $iss) -}}
    {{- end -}}
    {{- range $p := (($entry.jwt | default dict).providers | default list) -}}
      {{- if eq $p.name "okta-id-token" -}}
        {{- $_ := set $p "extractFrom" (dict "headers" (list (dict "name" $hdr))) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- $recognized := false -}}
  {{- range $k := $authKeys -}}
    {{- if hasKey $entry $k -}}{{- $recognized = true -}}{{- end -}}
  {{- end -}}
  {{- if not $recognized -}}
    {{- fail (printf "securityPolicies.%s declares none of oidc, basicAuth, cors, ipAllowList or jwt, so it would attach a policy that enforces nothing. Remove it, or give it a setting." $name) -}}
  {{- end -}}
  {{- $_ := set $merged $name $entry -}}
{{- end -}}
{{- if not (hasKey $merged "oidc-protected-default") -}}
  {{- $_ := set $merged "oidc-protected-default" (dict "oidc" (deepCopy $builtinOidc)) -}}
{{- end -}}
{{- if not (hasKey $merged "oidc-identity-headers") -}}
  {{- $_ := set $merged "oidc-identity-headers" (dict "oidc" (deepCopy $builtinOidc) "jwt" (deepCopy $builtinIdentityJwt)) -}}
{{- end -}}
{{- $skeleton := dict
      "cors" (dict "enabled" false)
      "ipAllowList" (list)
      "basicAuth" (dict "enabled" false "realm" "")
      "jwt" (dict "enabled" false "providers" (list))
      "annotations" (dict) -}}
{{- $oidcSkeleton := dict
      "provider" (dict)
      "cookieNames" (dict)
      "denyRedirect" (dict "enabled" false)
      "forwardIDToken" (dict "enabled" false)
      "apiRoutes" (list) -}}
{{- $out := dict -}}
{{- range $name, $def := $merged -}}
  {{- $d := mergeOverwrite (deepCopy $skeleton) $def -}}
  {{- if $d.oidc -}}
    {{- $_ := set $d "oidc" (mergeOverwrite (deepCopy $oidcSkeleton) $d.oidc) -}}
  {{- end -}}
  {{- $_ := set $out $name $d -}}
{{- end -}}
{{- $out | toYaml -}}
{{- end -}}

{{/*
A service's effective policy name, or "" when it is public. An omitted or "none"
gateway.securityPolicy means no policy is attached.
Takes (dict "root" $ "name" <serviceName>).
*/}}
{{- define "securityPolicy.objectName" -}}
{{- $default := ((.root.Values.global.gateway) | default dict).host | default "" -}}
{{- if eq .host $default -}}
{{- printf "%s-%s" .fullname .policyName -}}
{{- else -}}
{{- printf "%s-%s-%s" .fullname .policyName (.host | sha256sum | trunc 8) -}}
{{- end -}}
{{- end -}}

{{- define "securityPolicy.name" -}}
{{- $v := fromYaml (include "service.context" (dict "root" .root "name" .name)) -}}
{{- $name := (($v.gateway | default dict).securityPolicy | default "") -}}
{{- if and (ne $name "") (ne $name "none") -}}{{- $name -}}{{- end -}}
{{- end -}}

{{/*
A service's resolved policy settings as YAML, or "" when it is public. Fails when
the service names a policy that is not declared.
Takes (dict "root" $ "name" <serviceName>).
*/}}
{{- define "securityPolicy.resolve" -}}
{{- $root := .root -}}
{{- $name := include "securityPolicy.name" (dict "root" $root "name" .name) -}}
{{- if ne $name "" -}}
  {{- $defs := fromYaml (include "securityPolicy.definitions" $root) -}}
  {{- if not (hasKey $defs $name) -}}
    {{- fail (printf "service %q sets gateway.securityPolicy: %q but global.securityPolicies has no such entry. Declare it, or use oidc-protected-default." .name $name) -}}
  {{- end -}}
  {{- index $defs $name | toYaml -}}
{{- end -}}
{{- end -}}

{{/*
Group key for a policy attachment: one SecurityPolicy is realized per policy per
hostname, because redirectURL and the OauthHMAC session cookie are host-scoped.
Takes (dict "root" $ "name" <serviceName>).
*/}}
{{- define "securityPolicy.groupKey" -}}
{{- $root := .root -}}
{{- $name := include "securityPolicy.name" (dict "root" $root "name" .name) -}}
{{- if ne $name "" -}}
  {{- $v := fromYaml (include "service.context" (dict "root" $root "name" .name)) -}}
  {{- printf "%s|%s" $name ($v.gateway.host | default $root.Values.global.gateway.host) -}}
{{- end -}}
{{- end -}}

{{/*
Services attached to a group key, space separated and sorted.
Takes (dict "root" $ "key" <groupKey>).
*/}}
{{- define "securityPolicy.groupKeys" -}}
{{- $root := .root -}}
{{- $policy := include "securityPolicy.name" (dict "root" $root "name" .name) -}}
{{- $keys := list -}}
{{- if ne $policy "" -}}
  {{- $v := fromYaml (include "service.context" (dict "root" $root "name" .name)) -}}
  {{- $g := $v.gateway | default dict -}}
  {{- $keys = append $keys (printf "%s|%s" $policy ($g.host | default $root.Values.global.gateway.host)) -}}
  {{- range $g.rules | default list -}}
    {{- if .host -}}
      {{- $keys = append $keys (printf "%s|%s" $policy .host) -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- join " " ($keys | uniq) -}}
{{- end -}}

{{- define "securityPolicy.memberRoute" -}}
{{- $root := .root -}}
{{- $host := .host -}}
{{- $v := fromYaml (include "service.context" (dict "root" $root "name" .name)) -}}
{{- $svc := dict "Chart" $root.Chart "Release" $root.Release "Capabilities" $root.Capabilities "Values" $v -}}
{{- $full := include "service.fullname" $svc -}}
{{- $g := $v.gateway | default dict -}}
{{- if eq $host ($g.host | default $root.Values.global.gateway.host) -}}
{{- $full -}}
{{- else -}}
{{- $out := "" -}}
{{- range $i, $rule := $g.rules | default list -}}
  {{- if and (eq $out "") (eq ($rule.host | default "") $host) -}}
    {{- $out = printf "%s-rule-%d" $full (int $i) -}}
  {{- end -}}
{{- end -}}
{{- $out -}}
{{- end -}}
{{- end -}}

{{- define "securityPolicy.groupMembers" -}}
{{- $root := .root -}}
{{- $key := .key -}}
{{- $members := list -}}
{{- range $name, $_ := fromYaml (include "stack.networkEndpoints" $root) -}}
  {{- $v := fromYaml (include "service.context" (dict "root" $root "name" $name)) -}}
  {{- $g := $v.gateway | default dict -}}
  {{- if and $g.enabled (not (($g.tlsPassthrough | default dict).enabled)) -}}
    {{- if has $key (splitList " " (include "securityPolicy.groupKeys" (dict "root" $root "name" $name))) -}}
      {{- $members = append $members $name -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- join " " (sortAlpha $members) -}}
{{- end -}}

{{/*
Root-most member of a group - the service with the shortest basePath - so the
policy's redirectURL and logoutPath land on a path that service serves.
Takes (dict "root" $ "key" <groupKey>).
*/}}
{{- define "securityPolicy.groupPrimary" -}}
{{- $root := .root -}}
{{- $primary := "" -}}
{{- $primaryBase := "" -}}
{{- $primaryCanHost := false -}}
{{- range $n := (splitList " " (include "securityPolicy.groupMembers" (dict "root" $root "key" .key))) -}}
  {{- if ne $n "" -}}
    {{- $v := fromYaml (include "service.context" (dict "root" $root "name" $n)) -}}
    {{- $paths := ($v.gateway.paths | default list) -}}
    {{- $base := include "oidcProxyGateway.basePath" (dict "paths" $paths) -}}
    {{- $canHost := false -}}
    {{- range $paths -}}
      {{- if and (ne (.pathType | default "Prefix") "Exact") (ne (.pathType | default "Prefix") "RegularExpression") -}}{{- $canHost = true -}}{{- end -}}
    {{- end -}}
    {{- if or (eq $primary "") (and $canHost (not $primaryCanHost)) (and (eq $canHost $primaryCanHost) (lt (len $base) (len $primaryBase))) -}}
      {{- $primary = $n -}}
      {{- $primaryBase = $base -}}
      {{- $primaryCanHost = $canHost -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- $primary -}}
{{- end -}}

{{/*
Reject values that still set the per-service security surface removed in 2.55.0.
A key that no longer does anything is a mistake, and for oidcProtected it would
silently publish a service that used to require a login, so fail rather than
ignore it. Takes (dict "root" $ "name" <serviceName>).
*/}}
{{- define "securityPolicy.validateRemovedGlobalKeys" -}}
{{- $root := .root -}}
{{- if hasKey $root.Values.global "oidcProxyGateway" -}}
  {{- fail "global.oidcProxyGateway was removed in stack 2.55.0. Move it under global.securityPolicies.<name>.oidc and attach it with gateway.securityPolicy on each service that should share that session." -}}
{{- end -}}
{{- range $k := (list "oidcProtected" "cors" "ipAllowList" "basicAuth" "jwt") -}}
  {{- if hasKey ($root.Values.global.gateway | default dict) $k -}}
    {{- fail (printf "global.gateway.%s was removed in stack 2.55.0. Move it into a global.securityPolicies entry and attach it with gateway.securityPolicy." $k) -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{- define "securityPolicy.validateRemovedKeys" -}}
{{- $root := .root -}}
{{- $sv := index (fromYaml (include "stack.networkEndpoints" $root)) .name -}}
{{- $g := ($sv.gateway | default dict) -}}
{{- range $k := (list "oidcProtected" "cors" "ipAllowList" "basicAuth" "jwt") -}}
  {{- if hasKey $g $k -}}
    {{- fail (printf "service %q sets gateway.%s, which was removed in stack 2.55.0. Move it into a global.securityPolicies entry and attach it with gateway.securityPolicy. See https://chanzuckerberg.github.io/argus/configuration/security/stack_auth.html." $.name $k) -}}
  {{- end -}}
{{- end -}}
{{- if hasKey $sv "oidcProxyGateway" -}}
  {{- fail (printf "service %q sets oidcProxyGateway, which was removed in stack 2.55.0. Move it under global.securityPolicies.<name>.oidc and attach it with gateway.securityPolicy." $.name) -}}
{{- end -}}
{{- if hasKey $root.Values.global "oidcProxyGateway" -}}
  {{- fail "global.oidcProxyGateway was removed in stack 2.55.0. Move it under global.securityPolicies.<name>.oidc and attach it with gateway.securityPolicy on each service that should share that session." -}}
{{- end -}}
{{- range $k := (list "oidcProtected" "cors" "ipAllowList" "basicAuth" "jwt") -}}
  {{- if hasKey ($root.Values.global.gateway | default dict) $k -}}
    {{- fail (printf "global.gateway.%s was removed in stack 2.55.0. Move it into a global.securityPolicies entry and attach it with gateway.securityPolicy." $k) -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Whether a service's resolved policy carries OIDC. Takes (dict "root" $ "name" <serviceName>).
*/}}
{{- define "securityPolicy.isOidc" -}}
{{- $y := include "securityPolicy.resolve" (dict "root" .root "name" .name) -}}
{{- if ne $y "" -}}
  {{- if (fromYaml $y).oidc -}}true{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Whether a service needs a SecurityPolicy at all. Takes (dict "root" $ "name" <serviceName>).
*/}}
{{- define "gateway.hasSecurityPolicy" -}}
{{- $y := include "securityPolicy.resolve" (dict "root" .root "name" .name) -}}
{{- if ne $y "" -}}
  {{- $p := fromYaml $y -}}
  {{- if or $p.oidc ($p.basicAuth).enabled ($p.cors).enabled (gt (len ($p.ipAllowList | default list)) 0) ($p.jwt).enabled -}}true{{- end -}}
{{- end -}}
{{- end -}}

{{/*
SecurityPolicy name suffix: keep "-oidc" when OIDC is on (name continuity with the
pre-consolidation policy, avoids delete/recreate), else "-security".
*/}}
{{- define "gateway.securityPolicy.suffix" -}}
{{- if .policy.oidc -}}oidc{{- else -}}security{{- end -}}
{{- end -}}

{{/*
Whether the service needs a BackendTrafficPolicy (sessionAffinity, rateLimit, or connect timeout).
*/}}
{{- define "gateway.hasBackendTrafficPolicy" -}}
{{- $g := .Values.gateway -}}
{{- if or $g.sessionAffinity.enabled $g.rateLimit.enabled $g.timeouts.connect (and $g.requestBuffer $g.requestBuffer.enabled) -}}true{{- end -}}
{{- end -}}

{{- define "gateway.basicAuthRealm" -}}
{{- $resolved := include "securityPolicy.resolve" (dict "root" .root "name" .name) -}}
{{- if ne $resolved "" -}}
  {{- $ba := (fromYaml $resolved).basicAuth | default dict -}}
  {{- if $ba.realm -}}
    {{- if not $ba.enabled -}}
      {{- fail (printf "service %q attaches a securityPolicy that sets basicAuth.realm without basicAuth.enabled, so no basic-auth 401 exists for the realm to apply to. Enable basicAuth or drop the realm." .name) -}}
    {{- end -}}
    {{- $ba.realm -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{- define "gateway.hstsValue" -}}
{{- $g := .Values.gateway -}}
{{- $v := $g.hsts.value -}}
{{- range (($g.responseHeaders | default dict).set | default list) -}}
  {{- if eq (lower .name) "strict-transport-security" -}}{{- $v = .value -}}{{- end -}}
{{- end -}}
{{- $v -}}
{{- end -}}

{{/*
HTTPRoute per-rule timeouts block body (no "timeouts:" key). Caller indents under a rule.
*/}}
{{- define "gateway.ruleTimeoutsInner" -}}
{{- $t := .Values.gateway.timeouts -}}
{{- if $t.request }}
request: {{ $t.request | quote }}
{{- end }}
{{- if $t.backendRequest }}
backendRequest: {{ $t.backendRequest | quote }}
{{- end }}
{{- end -}}

{{/*
Rule filters for the policy-less -public route that gateway.skipAuth renders: gateway.ruleFiltersInner
plus a RequestHeaderModifier removing the identity headers the resolved policy injects on the protected
route, so a client cannot forge them. oidc strips the fixed oauth2-proxy set plus forwardIDToken,
forwardAccessToken and claimToHeaders targets; jwt-only strips its claimToHeaders targets; basicAuth, cors
and ipAllowList add nothing. Input dict: "ctx" (service context), "Values", optional "policy" (resolved
SecurityPolicy).
*/}}
{{- define "gateway.publicRuleFiltersInner" -}}
{{- $ctx := .ctx -}}
{{- $gw := deepCopy .Values.gateway -}}
{{- $rh := deepCopy ($gw.requestHeaders | default dict) -}}
{{- $remove := $rh.remove | default list -}}
{{- /* dedup the operator's own remove list case-insensitively: Envoy matches header names case-insensitively, so casing variants are one header and must not double-count against the 16-header cap */ -}}
{{- $opDeduped := list -}}
{{- $seenOp := dict -}}
{{- range $r := $remove -}}
{{- if not (hasKey $seenOp (lower $r)) -}}
{{- $_ := set $seenOp (lower $r) true -}}
{{- $opDeduped = append $opDeduped $r -}}
{{- end -}}
{{- end -}}
{{- $remove = $opDeduped -}}
{{- $identity := list -}}
{{- with .policy -}}
{{- /* the fixed oauth2-proxy identity set is the OIDC signal set: only an oidc policy injects it, so only an oidc public route must strip it. basicAuth, cors, ipAllowList and jwt inject none of these. */ -}}
{{- if .oidc -}}
{{- $identity = list "X-Forwarded-Email" "X-Forwarded-User" "X-Forwarded-Preferred-Username" "X-Forwarded-Groups" "X-Auth-Request-Email" "X-Auth-Request-User" "X-Auth-Request-Preferred-Username" "X-Auth-Request-Groups" "X-ID-Token" "X-Forwarded-Access-Token" "X-Auth-Request-Access-Token" -}}
{{- end -}}
{{- /* plus the headers this policy writes: the forwarded ID token (oidc only) and every jwt claim target */ -}}
{{- /* only strip the forwarded ID token header the policy actually writes: the render side gates it on forwardIDToken.enabled, so match that or we would reject an operator header the policy never injects */ -}}
{{- if (((.oidc | default dict).forwardIDToken) | default dict).enabled -}}
{{- with ((.oidc | default dict).forwardIDToken | default dict).header -}}
{{- /* when the forwarded ID token goes to Authorization, honour skipAuthPreserveAuthorization like the forwardAccessToken branch below */ -}}
{{- if not (and (eq (lower .) "authorization") (eq (toString $gw.skipAuthPreserveAuthorization) "true")) -}}
{{- $identity = append $identity . -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if and (.oidc | default dict).forwardAccessToken (ne (toString $gw.skipAuthPreserveAuthorization) "true") -}}
{{- /* the OAuth2 filter rewrites Authorization to the access token on protected paths; skipAuthPreserveAuthorization keeps a public endpoint's own bearer token */ -}}
{{- $identity = append $identity "Authorization" -}}
{{- end -}}
{{- /* claimToHeaders only reach the backend when jwt is enabled, mirroring the render side's jwt.enabled gate */ -}}
{{- if (.jwt | default dict).enabled -}}
{{- range ((.jwt | default dict).providers | default list) -}}
{{- range (.claimToHeaders | default list) -}}
{{- with .header -}}
{{- /* a claim target of Authorization honours skipAuthPreserveAuthorization too */ -}}
{{- if not (and (eq (lower .) "authorization") (eq (toString $gw.skipAuthPreserveAuthorization) "true")) -}}
{{- $identity = append $identity . -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- range $h := $identity -}}
{{- range concat ($rh.set | default list) ($rh.add | default list) -}}
{{- if eq (lower (.name | default "")) (lower $h) -}}
{{- fail (printf "gateway.requestHeaders sets or adds %q, which the unauthenticated -public route removes to stop clients forging it. Envoy applies set and add after remove, so the value would reach the backend on public paths. Remove it from gateway.requestHeaders on this service." .name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- /* dedup case-insensitively: Envoy matches header names case-insensitively, so each counts once against the 16-header cap */ -}}
{{- range $h := $identity -}}
{{- $seen := false -}}
{{- range $r := $remove -}}{{- if eq (lower $r) (lower $h) -}}{{- $seen = true -}}{{- end -}}{{- end -}}
{{- if not $seen -}}
{{- $remove = append $remove $h -}}
{{- end -}}
{{- end -}}
{{- if gt (len $remove) 16 -}}
{{- /* the identity header count is the case-insensitively-unique identity set itself, derived independently: deduping $remove against it can collapse an operator remove that overlaps an identity header, so subtracting the operator list would undercount identity and misattribute the overlap to the operator */ -}}
{{- $idSet := dict -}}
{{- range $identity -}}{{- $_ := set $idSet (lower .) true -}}{{- end -}}
{{- $identityCount := len $idSet -}}
{{- if gt $identityCount 16 -}}
{{- fail (printf "the public route's RequestHeaderModifier would remove %d headers, but Gateway API allows 16. The %d identity headers stripped on the public route (the fixed oauth2-proxy set, plus any forwardIDToken header, forwarded access token or claimToHeaders target the policy injects) already exceed the cap on their own, so no gateway.requestHeaders.remove can fit. Reduce the policy's forwardIDToken/forwardAccessToken or claimToHeaders headers." (len $remove) $identityCount) -}}
{{- else -}}
{{- $allowed := sub 16 $identityCount -}}
{{- if le $allowed 0 -}}
{{- fail (printf "the public route's RequestHeaderModifier would remove %d headers, but Gateway API allows 16. gateway.requestHeaders.remove cannot add any more on a service with skipAuth or protectedPaths; the %d identity headers removed there automatically already fill the limit." (len $remove) $identityCount) -}}
{{- else -}}
{{- fail (printf "the public route's RequestHeaderModifier would remove %d headers, but Gateway API allows 16. gateway.requestHeaders.remove may list at most %d headers outside the identity set on a service with skipAuth or protectedPaths (an entry that repeats an identity header does not count), because %d identity headers are removed there automatically." (len $remove) $allowed $identityCount) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $_ := set $rh "remove" $remove -}}
{{- $_ := set $gw "requestHeaders" $rh -}}
{{- /* render with the real service context: filters such as pathRewrite name their HTTPRouteFilter from the release and service */ -}}
{{- $vals := deepCopy $ctx.Values -}}
{{- $_ := set $vals "gateway" $gw -}}
{{- include "gateway.ruleFiltersInner" (dict "Chart" $ctx.Chart "Release" $ctx.Release "Capabilities" $ctx.Capabilities "Values" $vals) -}}
{{- end -}}

{{/*
HTTPRoute per-rule filters list (no "filters:" key). Caller indents under a rule.
Covers hostRewrite (URLRewrite) and request/response header modifiers. Redirect is
handled separately as a whole-route rule.
*/}}
{{- define "gateway.ruleFiltersInner" -}}
{{- $g := .Values.gateway -}}
{{- if $g.hostRewrite }}
- type: URLRewrite
  urlRewrite:
    hostname: {{ $g.hostRewrite | quote }}
{{- end }}
{{- if ($g.pathRewrite).pattern }}
- type: ExtensionRef
  extensionRef:
    group: gateway.envoyproxy.io
    kind: HTTPRouteFilter
    name: {{ include "gateway.pathRewriteName" . }}
{{- end }}
{{- $rh := $g.requestHeaders -}}
{{- if and $rh (or $rh.set $rh.add $rh.remove) }}
- type: RequestHeaderModifier
  requestHeaderModifier:
    {{- if $rh.set }}
    set:
      {{- toYaml $rh.set | nindent 6 }}
    {{- end }}
    {{- if $rh.add }}
    add:
      {{- toYaml $rh.add | nindent 6 }}
    {{- end }}
    {{- if $rh.remove }}
    remove:
      {{- toYaml $rh.remove | nindent 6 }}
    {{- end }}
{{- end }}
{{- $sh := $g.responseHeaders -}}
{{- $set := list -}}
{{- if and $sh $sh.set -}}
{{- $set = $sh.set -}}
{{- end -}}
{{- if $g.hsts -}}
{{- $hasSts := false -}}
{{- range $set -}}
{{- if eq (lower .name) "strict-transport-security" -}}
{{- $hasSts = true -}}
{{- end -}}
{{- end -}}
{{- if not $hasSts -}}
{{- $set = append $set (dict "name" "Strict-Transport-Security" "value" $g.hsts.value) -}}
{{- end -}}
{{- end -}}
{{- if or $set (and $sh (or $sh.add $sh.remove)) }}
- type: ResponseHeaderModifier
  responseHeaderModifier:
    {{- if $set }}
    set:
      {{- toYaml $set | nindent 6 }}
    {{- end }}
    {{- if and $sh $sh.add }}
    add:
      {{- toYaml $sh.add | nindent 6 }}
    {{- end }}
    {{- if and $sh $sh.remove }}
    remove:
      {{- toYaml $sh.remove | nindent 6 }}
    {{- end }}
{{- end }}
{{- end -}}

{{- define "validate.passThroughAuthHeader" -}}
{{- $p := .policy -}}
{{- $name := .policyName -}}
{{- $why := "Envoy Gateway rejects such a policy and then serves its routes with no authentication at all." -}}
{{- if not $p.jwt.enabled -}}
  {{- fail (printf "securityPolicies.%s.oidc.passThroughAuthHeader skips OIDC for any request carrying the JWT filter's header, but the policy has no jwt block to verify it, so every such request would reach the backend unauthenticated. Set jwt.enabled: true with a providers entry for the clients you mean to admit." $name) -}}
{{- end -}}
{{- $providers := $p.jwt.providers -}}
{{- $fwd := $p.oidc.forwardIDToken -}}
{{- $fwdHeader := lower ($fwd.header | default "") -}}
{{- $readsAuthorization := not $providers -}}
{{- $readsHeader := not $providers -}}
{{- range $providers -}}
  {{- if not (kindIs "map" .extractFrom) -}}
    {{- $readsAuthorization = true -}}
    {{- $readsHeader = true -}}
  {{- else -}}
    {{- $provider := .name -}}
    {{- range (.extractFrom.headers | default list) -}}
      {{- $readsHeader = true -}}
      {{- if and $fwd.enabled (eq (lower (.name | default "")) $fwdHeader) -}}
        {{- fail (printf "securityPolicies.%s: jwt provider %s reads %s, the header oidc.forwardIDToken writes, while oidc.passThroughAuthHeader is on. %s Have the provider read the bearer token from Authorization by omitting extractFrom, declaring your own jwt.providers if this is the built-in oidc-identity-headers policy, or set oidc.forwardIDToken.enabled: false." $name $provider .name $why) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if not $readsHeader -}}
  {{- fail (printf "securityPolicies.%s.oidc.passThroughAuthHeader needs a jwt provider that reads a header, but every provider reads only cookies or query parameters. %s Give a provider extractFrom.headers, or omit extractFrom so it reads Authorization." $name $why) -}}
{{- end -}}
{{- if and $fwd.enabled $readsAuthorization (eq $fwdHeader "authorization") -}}
  {{- fail (printf "securityPolicies.%s: oidc.forwardIDToken writes Authorization, which a jwt provider without extractFrom also reads, while oidc.passThroughAuthHeader is on. %s Forward the ID token in another header, such as the default X-ID-Token." $name $why) -}}
{{- end -}}
{{- end -}}

{{/*
SecurityPolicy spec body (no "targetRefs"). Input dict: "ctx" (service), "host", "public" (bool).
Public routes (skipAuth) carry only cors/authorization, never oidc/basicAuth.
*/}}
{{- define "gateway.securityPolicy.body" -}}
{{- $ := .ctx -}}
{{- $p := .policy -}}
{{- $policyName := .policyName -}}
{{- $basePath := .basePath -}}
{{- if and (not .public) $p.oidc }}
oidc:
  provider:
    issuer: {{ include "securityPolicy.issuer" (dict "policy" $p "name" $policyName) | quote }}
    {{- if $p.oidc.provider.authorizationEndpoint }}
    authorizationEndpoint: {{ $p.oidc.provider.authorizationEndpoint | quote }}
    {{- end }}
    {{- if $p.oidc.provider.tokenEndpoint }}
    tokenEndpoint: {{ $p.oidc.provider.tokenEndpoint | quote }}
    {{- end }}
  {{- if $p.oidc.clientID }}
  clientID: {{ $p.oidc.clientID | quote }}
  {{- else }}
  clientIDRef:
    name: {{ include "securityPolicy.secretName" (dict "policy" $p "name" $policyName "release" $.Release.Name) }}
  {{- end }}
  clientSecret:
    name: {{ include "securityPolicy.secretName" (dict "policy" $p "name" $policyName "release" $.Release.Name) }}
  redirectURL: https://{{ .host }}{{ $basePath }}/oauth2/callback
  {{- if $p.oidc.logoutPath }}
  logoutPath: {{ printf "%s%s" $basePath $p.oidc.logoutPath | quote }}
  {{- end }}
  {{- if $p.oidc.forwardAccessToken }}
  forwardAccessToken: {{ $p.oidc.forwardAccessToken }}
  {{- end }}
  {{- if $p.oidc.passThroughAuthHeader }}
  {{- include "validate.passThroughAuthHeader" (dict "policy" $p "policyName" $policyName) }}
  passThroughAuthHeader: {{ $p.oidc.passThroughAuthHeader }}
  {{- end }}
  {{- if $p.oidc.forwardIDToken.enabled }}
  {{- if not $p.oidc.forwardIDToken.header }}
  {{- fail (printf "securityPolicies.%s.oidc.forwardIDToken is enabled but sets no header. Name the upstream header that should carry the ID token, or set enabled: false." $policyName) -}}
  {{- end }}
  forwardIDToken:
    header: {{ $p.oidc.forwardIDToken.header | quote }}
  {{- end }}
  {{- if $p.oidc.refreshToken }}
  refreshToken: {{ $p.oidc.refreshToken }}
  {{- end }}
  {{- if $p.oidc.cookieDomain }}
  cookieDomain: {{ $p.oidc.cookieDomain | quote }}
  {{- end }}
  cookieNames:
    accessToken: {{ $p.oidc.cookieNames.accessToken | default (printf "AccessToken-%s-%s" $policyName (.host | replace "." "-")) | quote }}
    idToken: {{ $p.oidc.cookieNames.idToken | default (printf "IdToken-%s-%s" $policyName (.host | replace "." "-")) | quote }}
  {{- $apiRoutes := $p.oidc.apiRoutes | default list }}
  {{- $denyEnabled := $p.oidc.denyRedirect.enabled }}
  {{- $defaultMatcherCount := 0 }}
  {{- if $denyEnabled }}{{- $defaultMatcherCount = 3 }}{{- end }}
  {{- if gt (add (len $apiRoutes) $defaultMatcherCount) 16 }}
    {{- fail (printf "securityPolicies.<name>.oidc.apiRoutes: Envoy Gateway caps denyRedirect matchers at 16, got %d apiRoutes plus %d default matchers" (len $apiRoutes) $defaultMatcherCount) }}
  {{- end }}
  {{- range $apiRoutes }}
    {{- $matchType := .matchType | default "Prefix" }}
    {{- if not (has $matchType (list "Prefix" "Exact" "RegularExpression")) }}
      {{- fail (printf "securityPolicies.<name>.oidc.apiRoutes: matchType %q is not one of Prefix, Exact, RegularExpression" $matchType) }}
    {{- end }}
    {{- if not .path }}
      {{- fail "securityPolicies.<name>.oidc.apiRoutes: path must not be empty" }}
    {{- end }}
    {{- if and (ne $matchType "RegularExpression") (not (hasPrefix "/" .path)) }}
      {{- fail (printf "securityPolicies.<name>.oidc.apiRoutes: path %q must start with / for %s matching (request paths always do, so it would never match)" .path $matchType) }}
    {{- end }}
    {{- if and (eq $matchType "Prefix") (eq .path "/") }}
      {{- fail "securityPolicies.<name>.oidc.apiRoutes: Prefix / would 401 every request including browser navigations, making login impossible. For a fully headless API, use matchType RegularExpression deliberately." }}
    {{- end }}
  {{- end }}
  {{- if or $denyEnabled (gt (len $apiRoutes) 0) }}
  denyRedirect:
    headers:
      {{- if $denyEnabled }}
      - name: Sec-Fetch-Mode
        type: RegularExpression
        value: "cors|no-cors|same-origin"
      - name: Sec-Fetch-Dest
        type: RegularExpression
        value: "empty|script|style|image|font"
      - name: X-Requested-With
        type: Exact
        value: XMLHttpRequest
      {{- end }}
      {{- range $apiRoutes }}
      - name: ":path"
        type: {{ .matchType | default "Prefix" }}
        value: {{ .path | quote }}
      {{- end }}
  {{- end }}
  {{- if $p.oidc.csrfTokenTTL }}
  csrfTokenTTL: {{ $p.oidc.csrfTokenTTL | quote }}
  {{- end }}
  {{- if $p.oidc.scopes }}
  scopes:
    {{- toYaml $p.oidc.scopes | nindent 4 }}
  {{- end }}
  {{- if $p.oidc.resources }}
  resources:
    {{- toYaml $p.oidc.resources | nindent 4 }}
  {{- end }}
{{- end }}
{{- if and (not .public) $p.jwt.enabled }}
jwt:
  {{- if hasKey $p.jwt "optional" }}
  optional: {{ $p.jwt.optional }}
  {{- end }}
  {{- if hasKey $p.jwt "failOpen" }}
  failOpen: {{ $p.jwt.failOpen }}
  {{- end }}
  providers:
{{- if and $p.jwt.providers (gt (len $p.jwt.providers) 0) }}
  {{- range $i, $provider := $p.jwt.providers }}
    {{- /* Each provider passes through verbatim, so every JWTProvider field the
         CRD accepts — localJWKS, recomputeRoute, remoteJWKS cache and backend
         settings — reaches it, and a key this chart has never heard of fails
         loudly at the API server instead of vanishing here. Only
         remoteJWKSUri, the chart's own shorthand, is rewritten. */ -}}
    {{- $out := omit $provider "remoteJWKSUri" -}}
    {{- $rj := deepCopy ($provider.remoteJWKS | default dict) -}}
    {{- if and $provider.remoteJWKSUri (not $rj.uri) -}}
      {{- $_ := set $rj "uri" $provider.remoteJWKSUri -}}
    {{- end -}}
    {{- if $rj -}}
      {{- $_ := set $out "remoteJWKS" $rj -}}
    {{- end -}}
    {{- if and (not $rj.uri) (not $provider.localJWKS) -}}
      {{- fail (printf "securityPolicies.<name>.jwt.providers[%d] needs a key source: set remoteJWKSUri (find it with: curl -s <issuer>/.well-known/openid-configuration | jq -r .jwks_uri), or localJWKS for an inline or ConfigMap key set." $i) -}}
    {{- end -}}
    {{- if and $rj.uri $provider.localJWKS -}}
      {{- fail (printf "securityPolicies.<name>.jwt.providers[%d] sets both a remote and a local key source; the CRD permits exactly one." $i) -}}
    {{- end -}}
    {{- $_ := required (printf "securityPolicies.<name>.jwt.providers[%d].name is required. Provide a unique identifier for this JWT provider (e.g., 'okta', 'github-actions', 'eks-dev')" $i) $provider.name -}}
    {{- $_ := required (printf "securityPolicies.<name>.jwt.providers[%d].issuer is required. This should match the 'iss' claim in your JWT tokens" $i) $provider.issuer -}}
    {{- range $c := ($provider.claimToHeaders | default list) -}}
      {{- $_ := required "securityPolicies.<name>.jwt.providers[].claimToHeaders[].claim is required. Name the JWT claim to read, for example email or sub" $c.claim -}}
      {{- $_ := required "securityPolicies.<name>.jwt.providers[].claimToHeaders[].header is required. Name the upstream request header to write the claim into, for example X-Forwarded-Email" $c.header -}}
    {{- end }}
    - {{ toYaml $out | nindent 6 | trim }}
  {{- end }}
{{- else }}
    - name: default
      remoteJWKS:
        uri: {{ required "securityPolicies.<name>.jwt.remoteJWKSUri is required when securityPolicies.<name>.jwt.enabled is true (or use gateway.jwt.providers list). Find it with: curl -s <issuer>/.well-known/openid-configuration | jq -r .jwks_uri" $p.jwt.remoteJWKSUri | quote }}
      issuer: {{ required "securityPolicies.<name>.jwt.issuer is required when securityPolicies.<name>.jwt.enabled is true (or set oidcProxyGateway.provider.issuer, or use gateway.jwt.providers list)" ($p.jwt.issuer | default (($p.oidc | default dict).provider | default dict).issuer) | quote }}
{{- end }}
{{- end }}
{{- if and (not .public) $p.basicAuth.enabled }}
basicAuth:
  users:
    name: {{ required "securityPolicies.<name>.basicAuth.secretName is required when securityPolicies.<name>.basicAuth.enabled is true" $p.basicAuth.secretName }}
{{- end }}
{{- if $p.cors.enabled }}
cors:
  {{- if $p.cors.allowOrigins }}
  allowOrigins:
    {{- toYaml $p.cors.allowOrigins | nindent 4 }}
  {{- end }}
  {{- if $p.cors.allowMethods }}
  allowMethods:
    {{- toYaml $p.cors.allowMethods | nindent 4 }}
  {{- end }}
  {{- if $p.cors.allowHeaders }}
  allowHeaders:
    {{- toYaml $p.cors.allowHeaders | nindent 4 }}
  {{- end }}
  {{- if $p.cors.exposeHeaders }}
  exposeHeaders:
    {{- toYaml $p.cors.exposeHeaders | nindent 4 }}
  {{- end }}
  {{- if $p.cors.allowCredentials }}
  allowCredentials: true
  {{- end }}
  {{- if $p.cors.maxAge }}
  maxAge: {{ $p.cors.maxAge | quote }}
  {{- end }}
{{- end }}
{{- if gt (len $p.ipAllowList) 0 }}
authorization:
  defaultAction: Deny
  rules:
    - action: Allow
      principal:
        clientCIDRs:
          {{- toYaml $p.ipAllowList | nindent 10 }}
{{- end }}
{{- end -}}

{{/*
Check if gateway config keys are provided (auto-enable detection)
Returns: "true" if any gateway.* keys exist (excluding just "enabled")
*/}}
{{- define "gateway.hasConfigKeys" -}}
{{- if .Values.gateway -}}
  {{- $gatewayKeys := keys (omit .Values.gateway "enabled" "dnsOwner") -}}
  {{- if gt (len $gatewayKeys) 0 -}}true{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create the full dashboard data structure as a Helm dictionary and return it as a JSON string.
*/}}
{{- define "stack.grafanaDashboard.json" -}}
{{- $panels := list -}}
{{- $global := . -}}
{{- range $idx, $serviceName := (keys .Values.services | sortAlpha) -}}
  {{- $serviceValues := index $global.Values.services $serviceName -}}
  {{- $globalValuesDict := $global.Values.global | toYaml -}}
  {{- $values := fromYaml $globalValuesDict -}}
  {{- $values = set $values "name" $serviceName -}}
  {{- $values := mergeOverwrite $values $serviceValues -}}
  {{- $service := dict "Chart" $global.Chart "Release" $global.Release "Capabilities" $global.Capabilities "Values" $values -}}
  {{- $gwEnabled := false -}}
  {{- if hasKey $serviceValues "gateway" -}}
    {{- $svcGw := $serviceValues.gateway | default dict -}}
    {{- $explicitOff := and (hasKey $svcGw "enabled") (eq ($svcGw.enabled | toString) "false") -}}
    {{- if and (hasKey $svcGw "enabled") $svcGw.enabled -}}
      {{- $gwEnabled = true -}}
    {{- else if and (include "gateway.hasConfigKeys" (dict "Values" (dict "gateway" $svcGw))) (not $explicitOff) -}}
      {{- $gwEnabled = true -}}
    {{- end -}}
  {{- end -}}
  {{- $ingEnabled := $values.ingress.enabled -}}
  {{- if and $gwEnabled (not (and (hasKey $serviceValues "ingress") (hasKey ($serviceValues.ingress | default dict) "enabled") $serviceValues.ingress.enabled)) -}}
    {{- $ingEnabled = false -}}
  {{- end -}}
{{- with $service -}}
{{- if .Values.grafanaDashboard.enabled -}}
{{- $sectionPanelDict := dict "collapsed" false "panels" (list) "title" (printf "Service: %s" $serviceName) "type" "row" "serviceIndex" $idx -}}
{{- $panels = append $panels $sectionPanelDict -}}

{{- if or $ingEnabled $gwEnabled }}
{{- $routingArgs := dict "global" $global "service" $service "useIngress" $ingEnabled "useGateway" $gwEnabled -}}
{{- $successRatePanelDict := include "stack.grafanaDashboard.charts.serviceSuccessRate" $routingArgs | fromYaml -}}
{{- $panels = append $panels $successRatePanelDict -}}
{{- $failureRatePanelDict := include "stack.grafanaDashboard.charts.serviceFailureRate" $routingArgs | fromYaml -}}
{{- $panels = append $panels $failureRatePanelDict -}}
{{- $ingressLatencyPanelDict := include "stack.grafanaDashboard.charts.serviceIngressLatency" $routingArgs | fromYaml -}}
{{- $panels = append $panels $ingressLatencyPanelDict -}}
{{- end }}
{{- $cpuUsagePanelDict := include "stack.grafanaDashboard.charts.serviceCpuUsage" (dict "global" $global "service" $service) | fromYaml -}}
{{- $panels = append $panels $cpuUsagePanelDict -}}
{{- $memoryUsagePanelDict := include "stack.grafanaDashboard.charts.serviceMemoryUsage" (dict "global" $global "service" $service) | fromYaml -}}
{{- $panels = append $panels $memoryUsagePanelDict -}}
{{- $containerRestartsPanelDict := include "stack.grafanaDashboard.charts.serviceContainerRestarts" (dict "global" $global "service" $service) | fromYaml -}}
{{- $panels = append $panels $containerRestartsPanelDict -}}

{{/* Add extra panels from grafanaDashboard.extraPanels */}}
{{- range $extraPanel := .Values.grafanaDashboard.extraPanels -}}
  {{- $panels = append $panels $extraPanel -}}
{{- end -}}

{{- end -}}
{{- end -}}
{{- end -}}

{{/* Iterate over cronJobs and add panels for each cronjob */}}
{{- range $idx, $cronJobName := (keys .Values.cronJobs | sortAlpha) -}}
  {{- $cronJobValues := index $global.Values.cronJobs $cronJobName -}}
  {{- $globalValuesDict := $global.Values.global | toYaml -}}
  {{- $values := fromYaml $globalValuesDict -}}
  {{- $values = set $values "name" $cronJobName -}}
  {{- $values := mergeOverwrite $values $cronJobValues -}}
  {{- $cronJob := dict "Chart" $global.Chart "Release" $global.Release "Capabilities" $global.Capabilities "Values" $values -}}
{{- with $cronJob -}}
{{- if .Values.grafanaDashboard.enabled -}}
{{- $sectionPanelDict := dict "collapsed" false "panels" (list) "title" (printf "CronJob: %s" $cronJobName) "type" "row" "serviceIndex" (add $idx (len $global.Values.services)) -}}
{{- $panels = append $panels $sectionPanelDict -}}

{{- $cronJobMetricsPanelDict := include "stack.grafanaDashboard.charts.cronJobMetrics" (dict "global" $global "cronJob" $cronJob) | fromYaml -}}
{{- $panels = append $panels $cronJobMetricsPanelDict -}}
{{- $cronJobLastSuccessfulRunPanelDict := include "stack.grafanaDashboard.charts.cronJobLastSuccessfulRun" (dict "global" $global "cronJob" $cronJob) | fromYaml -}}
{{- $panels = append $panels $cronJobLastSuccessfulRunPanelDict -}}
{{- $cronJobAvgDurationPanelDict := include "stack.grafanaDashboard.charts.cronJobAverageDuration" (dict "global" $global "cronJob" $cronJob) | fromYaml -}}
{{- $panels = append $panels $cronJobAvgDurationPanelDict -}}

{{/* Add extra panels from grafanaDashboard.extraPanels */}}
{{- range $extraPanel := .Values.grafanaDashboard.extraPanels -}}
  {{- $panels = append $panels $extraPanel -}}
{{- end -}}

{{- end -}}
{{- end -}}
{{- end -}}

{{/* Now iterate over panels and set gridPos and id sequentially */}}
{{- $finalPanels := list -}}
{{- $currentX := 0 -}}
{{- $currentY := 0 -}}
{{- $currentRowHeight := 8 -}}
{{- range $panelIdx, $panel := $panels -}}
  {{- $panel = set $panel "id" (add $panelIdx 1) -}}
  {{- if eq $panel.type "row" -}}
    {{/* Row panel - if we have panels on current row, move to next row first */}}
    {{- if gt $currentX 0 -}}
      {{- $currentY = add $currentY $currentRowHeight -}}
    {{- end -}}
    {{- $currentX = 0 -}}
    {{- $panel = set $panel "gridPos" (dict "h" 1 "w" 24 "x" 0 "y" $currentY) -}}
    {{- $panel = unset $panel "serviceIndex" -}}
    {{/* After row, start panels on next line */}}
    {{- $currentY = add $currentY 1 -}}
    {{- $currentRowHeight = 8 -}}
  {{- else -}}
    {{/* Regular panel - use existing gridPos.h and gridPos.w, calculate x and y */}}
    {{- $existingGridPos := $panel.gridPos -}}
    {{- $h := default 8 $existingGridPos.h | int -}}
    {{- $w := default 12 $existingGridPos.w | int -}}

    {{/* If panel doesn't fit on current row, wrap to next row */}}
    {{- if gt (add $currentX $w) 24 -}}
      {{- $currentX = 0 -}}
      {{- $currentY = add $currentY $currentRowHeight -}}
      {{- $currentRowHeight = $h -}}
    {{- else -}}
      {{/* Track max height of panels in current row */}}
      {{- if gt $h $currentRowHeight -}}
        {{- $currentRowHeight = $h -}}
      {{- end -}}
    {{- end -}}

    {{/* Set final gridPos with calculated x and y */}}
    {{- $panel = set $panel "gridPos" (dict "h" $h "w" $w "x" $currentX "y" $currentY) -}}

    {{/* Move x position for next panel */}}
    {{- $currentX = add $currentX $w -}}
    {{/* If we've filled the row, reset x and move to next row */}}
    {{- if ge $currentX 24 -}}
      {{- $currentX = 0 -}}
      {{- $currentY = add $currentY $currentRowHeight -}}
      {{- $currentRowHeight = 8 -}}
    {{- end -}}
  {{- end -}}
  {{- $finalPanels = append $finalPanels $panel -}}
{{- end -}}

{{/* 3. Build the final, top-level dashboard dictionary */}}
{{- $dashboardTitle := $global.Release.Name }}
{{- $dashboard := dict
    "id" nil
    "uid" $dashboardTitle
    "title" $dashboardTitle
    "tags" (list)
    "style" "dark"
    "timezone" "browser"
    "editable" true
    "hideControls" false
    "graphTooltip" 1
    "panels" $finalPanels
    "time" (dict "from" "now-6h" "to" "now")
    "timepicker" (dict "time_options" (list) "refresh_intervals" (list))
    "templating" (dict "list" (list
      (dict
        "name" "namespace"
        "type" "constant"
        "hide" 2
        "query" $global.Release.Namespace
        "current" (dict "value" $global.Release.Namespace "text" $global.Release.Namespace)
      )
      (dict
        "name" "stackName"
        "type" "constant"
        "hide" 2
        "query" $global.Values.global.argusMetadata.stackName
        "current" (dict "value" $global.Values.global.argusMetadata.stackName "text" $global.Values.global.argusMetadata.stackName)
      )
    ))
    "annotations" (dict "list" (list
      (dict
        "builtIn" 1
        "datasource" (dict
          "type" "grafana"
          "uid" "-- Grafana --"
        )
        "enable" true
        "hide" true
        "iconColor" "rgba(0, 211, 255, 1)"
        "name" "Annotations & Alerts"
        "type" "dashboard"
      )
      (dict
        "datasource" (dict
          "type" "datasource"
          "uid" "grafana"
        )
        "enable" true
        "iconColor" "red"
        "name" "Argus Events"
        "target" (dict
          "limit" 100
          "matchAny" false
          "tags" (list
            (printf "app:%s" $global.Values.global.argusMetadata.appName)
            (printf "env:%s" $global.Values.global.argusMetadata.envName)
          )
          "type" "tags"
        )
      )
    ))
    "refresh" $global.Values.global.grafanaDashboard.refresh
    "schemaVersion" 17
    "version" 0
    "links" (list)
-}}

{{/* 5. Return the *entire data structure*. DO NOT pipe to toJson here. */}}
{{- $dashboard | toPrettyJson }}
{{- end -}}

{{/*
Create a success rate panel for a service.
Expects a dict with keys: global, service
*/}}
{{- define "stack.grafanaDashboard.charts.serviceSuccessRate" -}}
{{- $global := .global -}}
{{- $service := .service -}}
{{- $useIngress := .useIngress -}}
{{- $useGateway := .useGateway -}}
{{- $serviceFullname := include "service.fullname" $service -}}
{{- $targets := list -}}
{{- if $useIngress -}}
{{- $q := printf "sum(rate(nginx_ingress_controller_requests{namespace=\"$namespace\", ingress=\"%s\", status=~\"[23]..\"}[5m]))\n/\nsum(rate(nginx_ingress_controller_requests{namespace=\"$namespace\", ingress=\"%s\"}[5m])) * 100" $serviceFullname $serviceFullname -}}
{{- $targets = append $targets (dict "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid) "editorMode" "code" "expr" $q "legendFormat" "nginx" "range" true "refId" "A") -}}
{{- end -}}
{{- if $useGateway -}}
{{- $q := printf "sum(rate(envoy_cluster_upstream_rq_xx{container=\"envoy\", envoy_cluster_name=~\"httproute/$namespace/%s(-rule-[0-9]+|-public)?/rule/.*\", envoy_response_code_class=~\"[23]\"}[5m]))\n/\nsum(rate(envoy_cluster_upstream_rq_xx{container=\"envoy\", envoy_cluster_name=~\"httproute/$namespace/%s(-rule-[0-9]+|-public)?/rule/.*\"}[5m])) * 100" $serviceFullname $serviceFullname -}}
{{- $targets = append $targets (dict "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid) "editorMode" "code" "expr" $q "legendFormat" "gateway" "range" true "refId" "B") -}}
{{- end -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 12)
    "options" (dict
      "legend" (dict
        "calcs" (list)
        "displayMode" "list"
        "placement" "bottom"
        "showLegend" true
      )
      "tooltip" (dict
        "hideZeros" false
        "mode" "single"
        "sort" "none"
      )
    )
    "pluginVersion" "12.1.0"
    "targets" $targets
    "title" "Success %"
    "type" "timeseries"
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{/*
Create a failure rate panel for a service, segmented by error code.
Expects a dict with keys: global, service
*/}}
{{- define "stack.grafanaDashboard.charts.serviceFailureRate" -}}
{{- $global := .global -}}
{{- $service := .service -}}
{{- $useIngress := .useIngress -}}
{{- $useGateway := .useGateway -}}
{{- $serviceFullname := include "service.fullname" $service -}}
{{- $targets := list -}}
{{- if $useIngress -}}
{{- $q := printf "sum(rate(nginx_ingress_controller_requests{namespace=\"$namespace\", ingress=\"%s\", status=~\"[45]..\"}[5m])) by (status)\n/ on() group_left\nsum(rate(nginx_ingress_controller_requests{namespace=\"$namespace\", ingress=\"%s\"}[5m])) * 100" $serviceFullname $serviceFullname -}}
{{- $targets = append $targets (dict "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid) "editorMode" "code" "expr" $q "legendFormat" "{{status}}" "range" true "refId" "A") -}}
{{- end -}}
{{- if $useGateway -}}
{{- $q := printf "sum(rate(envoy_cluster_upstream_rq_xx{container=\"envoy\", envoy_cluster_name=~\"httproute/$namespace/%s(-rule-[0-9]+|-public)?/rule/.*\", envoy_response_code_class=~\"[45]\"}[5m])) by (envoy_response_code_class)\n/ on() group_left\nsum(rate(envoy_cluster_upstream_rq_xx{container=\"envoy\", envoy_cluster_name=~\"httproute/$namespace/%s(-rule-[0-9]+|-public)?/rule/.*\"}[5m])) * 100" $serviceFullname $serviceFullname -}}
{{- $targets = append $targets (dict "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid) "editorMode" "code" "expr" $q "legendFormat" "{{envoy_response_code_class}}xx" "range" true "refId" "B") -}}
{{- end -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 12)
    "options" (dict
      "legend" (dict
        "calcs" (list)
        "displayMode" "list"
        "placement" "bottom"
        "showLegend" true
      )
      "tooltip" (dict
        "hideZeros" false
        "mode" "single"
        "sort" "none"
      )
    )
    "pluginVersion" "12.1.0"
    "targets" $targets
    "title" "Failure % by Error Code"
    "type" "timeseries"
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{/*
Create a CPU usage panel for a service.
Expects a dict with keys: global, service
*/}}
{{- define "stack.grafanaDashboard.charts.serviceCpuUsage" -}}
{{- $global := .global -}}
{{- $service := .service -}}
{{- $metricsQuery := printf "sum(rate(container_cpu_usage_seconds_total{namespace=\"$namespace\", pod=~\"%s-.*\", container!=\"\"}[5m])) by (pod)" (include "service.fullname" $service) -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 12)
    "fieldConfig" (dict "defaults" (dict "unit" "short"))
    "options" (dict
      "legend" (dict
        "calcs" (list)
        "displayMode" "list"
        "placement" "bottom"
        "showLegend" true
      )
      "tooltip" (dict
        "hideZeros" false
        "mode" "single"
        "sort" "none"
      )
    )
    "pluginVersion" "12.1.0"
    "targets" (list
      (dict
        "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
        "editorMode" "code"
        "expr" $metricsQuery
        "legendFormat" "{{pod}}"
        "range" true
        "refId" "A"
      )
    )
    "title" "CPU Usage"
    "type" "timeseries"
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{/*
Create a memory usage panel for a service.
Expects a dict with keys: global, service
*/}}
{{- define "stack.grafanaDashboard.charts.serviceMemoryUsage" -}}
{{- $global := .global -}}
{{- $service := .service -}}
{{- $metricsQuery := printf "sum(container_memory_working_set_bytes{namespace=\"$namespace\", pod=~\"%s-.*\", container!=\"\"}) by (pod)" (include "service.fullname" $service) -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 12)
    "fieldConfig" (dict "defaults" (dict "unit" "bytes"))
    "options" (dict
      "legend" (dict
        "calcs" (list)
        "displayMode" "list"
        "placement" "bottom"
        "showLegend" true
      )
      "tooltip" (dict
        "hideZeros" false
        "mode" "single"
        "sort" "none"
      )
    )
    "pluginVersion" "12.1.0"
    "targets" (list
      (dict
        "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
        "editorMode" "code"
        "expr" $metricsQuery
        "legendFormat" "{{pod}}"
        "range" true
        "refId" "A"
      )
    )
    "title" "Memory Usage"
    "type" "timeseries"
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{/*
Create a container restarts panel for a service.
Expects a dict with keys: global, service
*/}}
{{- define "stack.grafanaDashboard.charts.serviceContainerRestarts" -}}
{{- $global := .global -}}
{{- $service := .service -}}
{{- $metricsQuery := printf "increase(kube_pod_container_status_restarts_total{namespace=\"$namespace\", pod=~\"%s-.*\"}[5m])" (include "service.fullname" $service) -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 12)
    "options" (dict
      "legend" (dict
        "calcs" (list)
        "displayMode" "list"
        "placement" "bottom"
        "showLegend" true
      )
      "tooltip" (dict
        "hideZeros" false
        "mode" "single"
        "sort" "none"
      )
    )
    "pluginVersion" "12.1.0"
    "targets" (list
      (dict
        "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
        "editorMode" "code"
        "expr" $metricsQuery
        "legendFormat" "{{pod}}"
        "range" true
        "refId" "A"
      )
    )
    "title" "Container Restarts"
    "type" "timeseries"
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{/*
Create an ingress latency panel for a service.
Expects a dict with keys: global, service
*/}}
{{- define "stack.grafanaDashboard.charts.serviceIngressLatency" -}}
{{- $global := .global -}}
{{- $service := .service -}}
{{- $useIngress := .useIngress -}}
{{- $useGateway := .useGateway -}}
{{- $serviceFullname := include "service.fullname" $service -}}
{{- $targets := list -}}
{{- if $useIngress -}}
{{- $q := printf "sum(rate(nginx_ingress_controller_request_duration_seconds_sum{namespace=\"$namespace\", status=\"200\", ingress=\"%s\"}[5m]))\n/\nsum(rate(nginx_ingress_controller_request_duration_seconds_count{namespace=\"$namespace\", status=\"200\", ingress=\"%s\"}[5m]))" $serviceFullname $serviceFullname -}}
{{- $targets = append $targets (dict "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid) "editorMode" "code" "expr" $q "legendFormat" "nginx" "range" true "refId" "A") -}}
{{- end -}}
{{- if $useGateway -}}
{{- $q := printf "sum(rate(envoy_cluster_upstream_rq_time_sum{container=\"envoy\", envoy_cluster_name=~\"httproute/$namespace/%s(-rule-[0-9]+|-public)?/rule/.*\"}[5m]))\n/\nsum(rate(envoy_cluster_upstream_rq_time_count{container=\"envoy\", envoy_cluster_name=~\"httproute/$namespace/%s(-rule-[0-9]+|-public)?/rule/.*\"}[5m]))\n/ 1000" $serviceFullname $serviceFullname -}}
{{- $targets = append $targets (dict "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid) "editorMode" "code" "expr" $q "legendFormat" "gateway" "range" true "refId" "B") -}}
{{- end -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 12)
    "options" (dict
      "legend" (dict
        "calcs" (list)
        "displayMode" "list"
        "placement" "bottom"
        "showLegend" true
      )
      "tooltip" (dict
        "hideZeros" false
        "mode" "single"
        "sort" "none"
      )
    )
    "pluginVersion" "12.1.0"
    "targets" $targets
    "title" "Request Latency (s)"
    "type" "timeseries"
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{/*
Create a cronjob metrics panel showing success and failure events as bars.
Expects a dict with keys: global, cronJob
*/}}
{{- define "stack.grafanaDashboard.charts.cronJobMetrics" -}}
{{- $global := .global -}}
{{- $cronJob := .cronJob -}}
{{- $cronJobFullname := include "service.fullname" $cronJob -}}
{{- $successQuery := printf "count((kube_job_status_succeeded{namespace=\"$namespace\", job_name=~\"%s-.*\"} UNLESS kube_job_status_succeeded{namespace=\"$namespace\", job_name=~\"%s-.*\"} offset $__interval) == 1)" $cronJobFullname $cronJobFullname -}}
{{- $failureQuery := printf "count((kube_job_status_failed{namespace=\"$namespace\", job_name=~\"%s-.*\"} UNLESS kube_job_status_failed{namespace=\"$namespace\", job_name=~\"%s-.*\"} offset $__interval) == 1)" $cronJobFullname $cronJobFullname -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 12)
    "options" (dict
      "legend" (dict
        "calcs" (list)
        "displayMode" "list"
        "placement" "bottom"
        "showLegend" true
      )
      "tooltip" (dict
        "hideZeros" true
        "mode" "multi"
        "sort" "none"
      )
      "orientation" "auto"
      "xTickLabelRotation" 0
      "xTickLabelSpacing" 100
      "barWidth" 0.97
      "barRadius" 0
      "fullHighlight" false
      "groupWidth" 0.7
      "showValue" "auto"
      "stacking" "none"
    )
    "pluginVersion" "12.1.0"
    "targets" (list
      (dict
        "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
        "editorMode" "code"
        "expr" $successQuery
        "legendFormat" "Success"
        "range" true
        "refId" "A"
      )
      (dict
        "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
        "editorMode" "code"
        "expr" $failureQuery
        "legendFormat" "Failure"
        "range" true
        "refId" "B"
      )
    )
    "title" "CronJob Executions"
    "type" "barchart"
    "transformations" (list
      (dict
        "id" "filterByValue"
        "options" (dict
          "filters" (list
            (dict
              "config" (dict
                "id" "equal"
                "options" (dict "value" 0)
              )
              "fieldName" ""
            )
          )
          "match" "all"
          "type" "exclude"
        )
      )
    )
    "fieldConfig" (dict
      "defaults" (dict
        "unit" "short"
        "min" 0
        "custom" (dict
          "drawStyle" "bars"
          "barAlignment" 0
          "lineInterpolation" "linear"
          "barWidthFactor" 0.6
          "fillOpacity" 80
          "gradientMode" "none"
          "hideFrom" (dict
            "tooltip" false
            "viz" false
            "legend" false
          )
          "lineWidth" 1
          "pointSize" 5
          "scaleDistribution" (dict "type" "linear")
          "showPoints" "never"
          "spanNulls" false
          "stacking" (dict "group" "A" "mode" "none")
          "thresholdsStyle" (dict "mode" "off")
        )
      )
      "overrides" (list
        (dict
          "matcher" (dict "id" "byFrameRefID" "options" "A")
          "properties" (list
            (dict
              "id" "color"
              "value" (dict "mode" "fixed" "fixedColor" "green")
            )
          )
        )
        (dict
          "matcher" (dict "id" "byFrameRefID" "options" "B")
          "properties" (list
            (dict
              "id" "color"
              "value" (dict "mode" "fixed" "fixedColor" "red")
            )
          )
        )
      )
    )
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{/*
Create a stat panel showing the last successful run of a cronjob.
Expects a dict with keys: global, cronJob
*/}}
{{- define "stack.grafanaDashboard.charts.cronJobLastSuccessfulRun" -}}
{{- $global := .global -}}
{{- $cronJob := .cronJob -}}
{{- $cronJobFullname := include "service.fullname" $cronJob -}}
{{- $lastSuccessQuery := printf "max(kube_job_status_completion_time{namespace=\"$namespace\", job_name=~\"%s-.*\"} > 0) * 1000" $cronJobFullname -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 6)
    "options" (dict
      "colorMode" "value"
      "graphMode" "none"
      "justifyMode" "auto"
      "orientation" "auto"
      "reduceOptions" (dict
        "calcs" (list "lastNotNull")
        "fields" ""
        "values" false
      )
      "textMode" "value_and_name"
      "showPercentChange" false
    )
    "pluginVersion" "12.1.0"
    "targets" (list
      (dict
        "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
        "editorMode" "code"
        "expr" $lastSuccessQuery
        "legendFormat" "Last Successful Run"
        "range" false
        "instant" true
        "refId" "A"
      )
    )
    "title" "Last Successful Run"
    "type" "stat"
    "fieldConfig" (dict
      "defaults" (dict
        "unit" "dateTimeFromNow"
        "noValue" "No completions found"
        "mappings" (list
          (dict
            "type" "special"
            "options" (dict
              "match" "null"
              "result" (dict
                "text" "No completions"
                "color" "orange"
              )
            )
          )
        )
        "thresholds" (dict
          "mode" "absolute"
          "steps" (list
            (dict "color" "green" "value" nil)
          )
        )
      )
    )
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{/*
Create a stat panel showing the average duration of cronjob runs.
Expects a dict with keys: global, cronJob
*/}}
{{- define "stack.grafanaDashboard.charts.cronJobAverageDuration" -}}
{{- $global := .global -}}
{{- $cronJob := .cronJob -}}
{{- $cronJobFullname := include "service.fullname" $cronJob -}}
{{- $avgDurationQuery := printf "avg(kube_job_status_completion_time{namespace=\"$namespace\", job_name=~\"%s-.*\"} - kube_job_status_start_time{namespace=\"$namespace\", job_name=~\"%s-.*\"})" $cronJobFullname $cronJobFullname -}}
{{- $panelDict := dict
    "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
    "gridPos" (dict "h" 8 "w" 6)
    "options" (dict
      "colorMode" "value"
      "graphMode" "area"
      "justifyMode" "auto"
      "orientation" "auto"
      "reduceOptions" (dict
        "calcs" (list "lastNotNull")
        "fields" ""
        "values" false
      )
      "textMode" "value_and_name"
      "showPercentChange" false
    )
    "pluginVersion" "12.1.0"
    "targets" (list
      (dict
        "datasource" (dict "type" "prometheus" "uid" $global.Values.global.grafanaDashboard.datasources.prometheus.uid)
        "editorMode" "code"
        "expr" $avgDurationQuery
        "legendFormat" "Average Duration"
        "range" true
        "refId" "A"
      )
    )
    "title" "Average Job Duration"
    "type" "stat"
    "fieldConfig" (dict
      "defaults" (dict
        "unit" "s"
        "noValue" "No data"
        "decimals" 2
        "thresholds" (dict
          "mode" "absolute"
          "steps" (list
            (dict "color" "green" "value" nil)
            (dict "color" "yellow" "value" 60)
            (dict "color" "red" "value" 300)
          )
        )
      )
    )
-}}
{{- $panelDict | toYaml -}}
{{- end -}}

{{- define "gateway.effectiveSectionName" -}}
{{- if .Values.gateway.sectionName -}}
{{- .Values.gateway.sectionName -}}
{{- else if (.Values.gateway.httpsRedirect).enabled -}}
https
{{- end -}}
{{- end -}}

{{- define "gateway.httpsRedirectHosts" -}}
{{- $hosts := list .Values.gateway.host -}}
{{- range .Values.gateway.rules -}}
{{- $hosts = append $hosts .host -}}
{{- end -}}
{{- toYaml (uniq (compact $hosts)) -}}
{{- end -}}

{{- define "s3Storage.annotations" -}}
{{- $s3 := .Values.global.s3Storage -}}
{{- $annotations := deepCopy ($s3.annotations | default dict) -}}
{{- if and $s3.pvcName (not (hasKey $annotations "argocd.argoproj.io/sync-options")) -}}
{{- $_ := set $annotations "argocd.argoproj.io/sync-options" "Prune=false,Delete=false" -}}
{{- end -}}
{{- if $annotations -}}
{{- toYaml $annotations -}}
{{- end -}}
{{- end -}}

{{- define "gateway.authenticationDefault" -}}
{{- ((.Values.gateway.authentication | default dict).default | default "protected") -}}
{{- end -}}

{{- define "gateway.publicPaths" -}}
{{- $authentication := .Values.gateway.authentication | default dict -}}
{{- if gt (len ($authentication.publicPaths | default list)) 0 -}}
{{- toYaml $authentication.publicPaths -}}
{{- else -}}
{{- toYaml (.Values.gateway.skipAuth | default list) -}}
{{- end -}}
{{- end -}}

{{- define "gateway.publicRoute" -}}
{{- $service := .ctx -}}
{{- $global := .root -}}
{{- $filters := .filters -}}
{{- $timeouts := .timeouts -}}
{{- $rules := list -}}
{{- with $service -}}
{{- $authentication := .Values.gateway.authentication | default dict -}}
{{- $pathSource := "gateway.skipAuth" -}}
{{- if gt (len ($authentication.publicPaths | default list)) 0 -}}
{{- $pathSource = "gateway.authentication.publicPaths" -}}
{{- end -}}
{{- $publicPaths := fromYamlArray (include "gateway.publicPaths" .) -}}
{{- if eq (include "gateway.authenticationDefault" .) "public" -}}
{{- range .Values.gateway.paths -}}
{{- $rules = append $rules (dict "path" (.path | default "/") "pathType" (include "gateway.pathMatchType" .pathType) "method" "" "weight" (.weight | default 0)) -}}
{{- end -}}
{{- else if gt (len $publicPaths) 0 -}}
{{- if .Values.gateway.redirect.enabled -}}
{{- if eq $pathSource "gateway.skipAuth" -}}
{{- fail "gateway.skipAuth cannot be combined with gateway.redirect.enabled: a redirect-only route serves no backend, so there is nothing to exempt from authentication, and the public route would send the listed paths to the backend instead of redirecting them. Remove one or the other." -}}
{{- else -}}
{{- fail "gateway.authentication.publicPaths cannot be combined with gateway.redirect.enabled: a redirect-only route serves no backend, so there is nothing to exempt from authentication. Remove one or the other." -}}
{{- end -}}
{{- end -}}
{{- range $publicPaths -}}
{{- if not (hasPrefix "/" .path) -}}
{{- fail (printf "gateway public path %q must start with /. The gateway matches these as literal path prefixes, not regexes. Write the plain prefix, for example /public/ rather than ^/public/." .path) -}}
{{- end -}}
{{- $pathType := .pathType | default "PathPrefix" -}}
{{- if not (has $pathType (list "PathPrefix" "Exact")) -}}
{{- fail (printf "gateway public pathType %q is not valid. Use PathPrefix (the default) or Exact." $pathType) -}}
{{- end -}}
{{- if and (eq .path "/") (eq $pathType "PathPrefix") -}}
{{- if eq $pathSource "gateway.skipAuth" -}}
{{- fail "gateway.skipAuth path / with pathType PathPrefix would make the whole service public: the -public HTTPRoute shadows the policy-protected route for every request. List the specific prefixes that should be unauthenticated instead, or use pathType Exact to expose only the root." -}}
{{- else -}}
{{- fail "gateway.authentication.publicPaths path / with pathType PathPrefix would make the whole service public. Set gateway.authentication.default to public with protectedPaths, list specific public prefixes or use pathType Exact." -}}
{{- end -}}
{{- end -}}
{{- $rules = append $rules (dict "path" .path "pathType" $pathType "method" (.method | default "") "weight" 0) -}}
{{- end -}}
{{- end -}}
{{- if gt (len $rules) 0 -}}
---
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: {{ include "service.fullname" .  }}-public
  labels:
    {{- include "service.labels" . | nindent 4 }}
  annotations:
    {{- with (mergeOverwrite
                (dict)
                (.Values.annotations)
                (.Values.gateway.annotations)
                (dict "external-dns.alpha.kubernetes.io/exclude" "true")
      ) }}
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  parentRefs:
    {{- if .Values.gateway.vanity.enabled }}
    - group: gateway.networking.k8s.io
      kind: ListenerSet
      name: {{ include "stack.canonicalVanityListenerSet" (dict "root" $global "hostname" (.Values.gateway.vanity.hostname | default .Values.gateway.host)) }}
    {{- else }}
    - name: {{ .Values.gateway.gatewayName }}
      namespace: {{ .Values.gateway.gatewayNamespace }}
      {{- with (include "gateway.effectiveSectionName" .) }}
      sectionName: {{ . }}
      {{- end }}
    {{- end }}
    {{- range $i, $rule := .Values.gateway.rules }}
    {{- if and $rule.vanity $rule.vanity.enabled }}
    - group: gateway.networking.k8s.io
      kind: ListenerSet
      name: {{ include "stack.canonicalVanityListenerSet" (dict "root" $global "hostname" ($rule.vanity.hostname | default $rule.host)) }}
    {{- end }}
    {{- end }}
  hostnames:
    - {{ .Values.gateway.host }}
  {{- range $i, $rule := .Values.gateway.rules }}
    - {{ $rule.host }}
  {{- end }}
  {{- $protectedPaths := .Values.gateway.paths | default list -}}
  {{- range .Values.gateway.rules -}}
    {{- $protectedPaths = concat $protectedPaths (.paths | default $service.Values.gateway.paths | default list) -}}
  {{- end -}}
  {{- range $protectedPaths -}}
    {{- if eq .pathType "RegularExpression" -}}
      {{- if eq $pathSource "gateway.skipAuth" -}}
      {{- fail (printf "service %q combines gateway.skipAuth with a RegularExpression path (%q). Envoy Gateway ranks a regex match above a path prefix however specific the prefix is, so the protected route would win over the -public route and the paths meant to be unauthenticated would silently require login. The -public route covers gateway.host and every gateway.rules host, so a regex under either one shadows it. Express the protected routes as Prefix or Exact paths, or drop skipAuth and let the regex route carry the policy." $service.Values.name .path) -}}
      {{- else -}}
      {{- fail (printf "service %q combines gateway.authentication.publicPaths with a RegularExpression path (%q). Envoy Gateway ranks a regex match above a path prefix however specific the prefix is, so the protected route would win over the -public route. Express the protected routes as Prefix or Exact paths, or remove the public exception." $service.Values.name .path) -}}
      {{- end -}}
    {{- end -}}
  {{- end }}
  rules:
    {{- range $rules }}
    - matches:
        - path:
            type: {{ .pathType }}
            value: {{ .path }}
          {{- if and .method (ne .method "*") }}
          method: {{ .method }}
          {{- end }}
      backendRefs:
        {{- include "service.backend.refs.direct" $service | nindent 8 }}
          {{- if .weight }}
          weight: {{ .weight }}
          {{- end }}
      {{- if $filters }}
      filters:
        {{- $filters | nindent 8 }}
      {{- end }}
      {{- if $timeouts }}
      timeouts:
        {{- $timeouts | nindent 8 }}
      {{- end }}
    {{- end }}
{{- end }}
{{- end -}}
{{- end -}}

{{- define "gateway.pathMatchType" -}}
{{- if eq . "Exact" -}}
Exact
{{- else if eq . "RegularExpression" -}}
RegularExpression
{{- else -}}
PathPrefix
{{- end -}}
{{- end }}

{{- define "gateway.pathRewriteName" -}}
{{ include "service.fullname" . }}-path-rewrite
{{- end }}

{{- define "validate.pathRewrite" -}}
{{- $r := .rewrite -}}
{{- if not $r.pattern -}}
{{- fail (printf "service %q sets gateway.pathRewrite without a pattern. Envoy Gateway rewrites the path by regex, so both pattern and substitution are required." .name) -}}
{{- end -}}
{{- if not $r.substitution -}}
{{- fail (printf "service %q sets gateway.pathRewrite without a substitution. Use \\1, \\2 and so on to reference capture groups from the pattern, mirroring the nginx rewrite-target it replaces." .name) -}}
{{- end -}}
{{- end }}

{{- /* Rejects a path that YAML would normalise or the HTTPRoute API would refuse; on the protected route that leaves the -public route standing alone. Also rejects ; and %, which the guard rule claims. Takes (dict "label" "value"). */ -}}
{{- define "gateway.assertPlainPath" -}}
{{- if or (not (hasPrefix "/" .value)) (not (regexMatch "^[-A-Za-z0-9/._~!$&'()*+,=:@]+$" .value)) (contains "//" .value) (contains "/./" .value) (contains "/../" .value) (hasSuffix "/." .value) (hasSuffix "/.." .value) -}}
{{- fail (printf "%s must be a plain path: start with /, ASCII only, no whitespace, percent-encoding or semicolon, no double slash or dot segment. Write the plain path." .label) -}}
{{- end -}}
{{- end -}}

{{- define "validate.pathAuthentication" -}}
{{- $globalAuthentication := ((((.root.Values.global).gateway | default dict).authentication) | default dict) -}}
{{- if or (eq ($globalAuthentication.default | default "protected") "public") (gt (len ($globalAuthentication.publicPaths | default list)) 0) (gt (len ($globalAuthentication.protectedPaths | default list)) 0) -}}
{{- fail "gateway.authentication must keep default protected with empty path lists globally. Set publicPaths or default public with protectedPaths under services.NAME.gateway.authentication." -}}
{{- end -}}
{{- /* protectedPaths lives under gateway.authentication. The schema does not reject unknown keys, so a top-level gateway.protectedPaths would otherwise be ignored and the service would render fully protected without warning. */ -}}
{{- if hasKey (((.root.Values.global).gateway | default dict)) "protectedPaths" -}}
{{- fail "gateway.protectedPaths is not a chart key and would be ignored. Set services.NAME.gateway.authentication.default to public and list the prefixes under services.NAME.gateway.authentication.protectedPaths." -}}
{{- end -}}
{{- $root := .root -}}
{{- with .ctx -}}
{{- $g := .Values.gateway -}}
{{- $name := .Values.name -}}
{{- if hasKey $g "protectedPaths" -}}
{{- fail (printf "service %s sets gateway.protectedPaths, which is not a chart key and would be ignored. Set gateway.authentication.default to public and list the prefixes under gateway.authentication.protectedPaths." $name) -}}
{{- end -}}
{{- $authentication := $g.authentication | default dict -}}
{{- $default := $authentication.default | default "protected" -}}
{{- $publicPaths := $authentication.publicPaths | default list -}}
{{- $protectedPaths := $authentication.protectedPaths | default list -}}
{{- $skipAuth := $g.skipAuth | default list -}}
{{- if not (has $default (list "protected" "public")) -}}
{{- fail (printf "service %s sets gateway.authentication.default to %q. Use protected or public." $name $default) -}}
{{- end -}}
{{- if and (gt (len $publicPaths) 0) (gt (len $skipAuth) 0) -}}
{{- fail (printf "service %s sets both gateway.authentication.publicPaths and gateway.skipAuth. Keep one; skipAuth remains only for backward compatibility." $name) -}}
{{- end -}}
{{- if eq $default "protected" -}}
{{- if gt (len $protectedPaths) 0 -}}
{{- fail (printf "service %s sets gateway.authentication.protectedPaths while authentication.default is protected. Set default to public explicitly, or remove protectedPaths." $name) -}}
{{- end -}}
{{- else -}}
{{- if or (gt (len $publicPaths) 0) (gt (len $skipAuth) 0) -}}
{{- fail (printf "service %s sets public path exceptions while gateway.authentication.default is already public. Remove publicPaths or skipAuth." $name) -}}
{{- end -}}
{{- if eq (len $protectedPaths) 0 -}}
{{- fail (printf "service %s sets gateway.authentication.default to public without protectedPaths. Remove authentication to keep the service protected, or list the paths that require OIDC." $name) -}}
{{- end -}}
{{- if and $g.enabled $g.tlsPassthrough.enabled -}}
{{- fail (printf "service %s sets gateway.authentication.default to public with tlsPassthrough enabled; a TLSRoute carries no HTTP paths. Remove one." $name) -}}
{{- end -}}
{{- if and $g.enabled (ne (include "securityPolicy.isOidc" (dict "root" $root "name" $name)) "true") -}}
{{- fail (printf "service %s sets gateway.authentication.default to public but its gateway.securityPolicy is not an OIDC policy. Set one, or use the protected default." $name) -}}
{{- end -}}
{{- if and .Values.ingress.enabled (not .Values.ingress.oidcProtected) -}}
{{- fail (printf "service %s sets gateway.authentication.default to public but renders an nginx Ingress with ingress.oidcProtected false, so protectedPaths are served without authentication there. Set oidcProtected true and list public prefixes in oidcProxy.skipAuth, or use the protected default." $name) -}}
{{- end -}}
{{- if not $g.enabled -}}
{{- fail (printf "service %s sets gateway.authentication.default to public but its gateway is disabled, so no Envoy routes render. Set gateway.dnsOwner or gateway.enabled true, or use the protected default." $name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "gateway.protectedRules" -}}
{{- $root := .root -}}
{{- $p := .policy -}}
{{- $g := .service.Values.gateway -}}
{{- $authentication := $g.authentication | default dict -}}
{{- $name := .service.Values.name -}}
{{- $rules := list -}}
{{- if gt (len ($g.rules | default list)) 0 -}}
{{- fail (printf "service %s sets gateway.authentication.default to public together with gateway.rules, which is not supported. Move the extra hosts to their own service." $name) -}}
{{- end -}}
{{- if (($g.redirect | default dict).enabled) -}}
{{- fail (printf "service %s sets gateway.authentication.protectedPaths with gateway.redirect.enabled. A redirect route has nothing to protect; remove one." $name) -}}
{{- end -}}
{{- if ((($g.pathRewrite | default dict).pattern)) -}}
{{- fail (printf "service %s sets gateway.authentication.protectedPaths with gateway.pathRewrite. The rewrite also applies to the public route and could rewrite onto a protected path; remove one." $name) -}}
{{- end -}}
{{- /* The OAuth2 filter answers the callback and logout only on the route the policy targets. Checked even with no prefix listed: a base path the API server rejects drops the protected route while the -public one stays, leaving every path unauthenticated. */ -}}
{{- $basePath := include "oidcProxyGateway.basePath" (dict "paths" $g.paths) -}}
{{- $callback := printf "%s/oauth2" $basePath -}}
{{- include "gateway.assertPlainPath" (dict "label" (printf "the OIDC callback of service %s renders as %q (from the gateway.paths base path %q), which" $name $callback $basePath) "value" $callback) -}}
{{- $rules = append $rules (dict "path" $callback "match" $callback "pathType" "PathPrefix" "auto" true "caseSensitive" true) -}}
{{- if $p.oidc.logoutPath -}}
{{- $lp := printf "%s%s" $basePath $p.oidc.logoutPath -}}
{{- include "gateway.assertPlainPath" (dict "label" (printf "securityPolicies.%s.oidc.logoutPath %q renders as %q, which" (include "securityPolicy.name" (dict "root" $root "name" $name)) $p.oidc.logoutPath $lp) "value" $lp) -}}
{{- $rules = append $rules (dict "path" $lp "match" $lp "pathType" "Exact" "auto" true "caseSensitive" true) -}}
{{- end -}}
{{- /* gateway.paths render unquoted on the -public route, so each must survive YAML normalisation exactly as compared below, carry no ; or % (the guard rule claims those), and not be a regex, which Envoy Gateway ranks above every protected prefix. */ -}}
{{- range $g.paths -}}
{{- $gp := .path | default "/" -}}
{{- if eq (.pathType | default "Prefix") "RegularExpression" -}}
{{- fail (printf "service %s combines gateway.authentication.protectedPaths with a RegularExpression path (%q) in gateway.paths. A regex outranks the protected prefixes; use Prefix or Exact." $name $gp) -}}
{{- end -}}
{{- if or (contains ";" $gp) (contains "%" $gp) -}}
{{- fail (printf "gateway.paths entry %q on service %s contains ; or %%. With protectedPaths such requests go to the protected route, so this entry can never be public; remove it." $gp $name) -}}
{{- end -}}
{{- include "gateway.assertPlainPath" (dict "label" (printf "gateway public path %q on service %s" $gp $name) "value" $gp) -}}
{{- end -}}
{{- range ($authentication.protectedPaths | default list) -}}
{{- $pp := .path | default "" -}}
{{- if not $pp -}}
{{- fail (printf "a gateway.authentication.protectedPaths entry on service %s has no path. Each entry needs path: /<prefix>." $name) -}}
{{- end -}}
{{- $cs := .caseSensitive | default false -}}
{{- range $k, $_ := omit . "path" "caseSensitive" -}}
{{- fail (printf "gateway.authentication.protectedPaths entry %q on service %s has an unsupported key %q. Only path and caseSensitive are allowed." $pp $name $k) -}}
{{- end -}}
{{- include "gateway.assertPlainPath" (dict "label" (printf "gateway.authentication.protectedPaths path %q on service %s" $pp $name) "value" $pp) -}}
{{- if eq $pp "/" -}}
{{- fail (printf "gateway.authentication.protectedPaths path / on service %s would protect the whole service. Use authentication.default protected instead." $name) -}}
{{- else if hasSuffix "/" $pp -}}
{{- fail (printf "gateway.authentication.protectedPaths path %q on service %s must not end with /. Write the prefix as %q." $pp $name (trimSuffix "/" $pp)) -}}
{{- end -}}
{{- /* An Exact entry covers no subtree, so it cannot host a prefix. */ -}}
{{- $covered := false -}}
{{- range $g.paths -}}
{{- $base := trimSuffix "/" (.path | default "/") -}}
{{- if and (ne (.pathType | default "Prefix") "Exact") (or (eq $base "") (eq $base $pp) (hasPrefix (printf "%s/" $base) $pp)) -}}{{- $covered = true -}}{{- end -}}
{{- end -}}
{{- if not $covered -}}
{{- fail (printf "gateway.authentication.protectedPaths %q on service %s is not under any Prefix entry of gateway.paths. Add a broader prefix or correct the path." $pp $name) -}}
{{- end -}}
{{- /* Two spellings of one prefix are one rule unless both are caseSensitive; mixing the settings is ambiguous. */ -}}
{{- $dup := false -}}
{{- range $rules -}}
{{- if eq (lower .path) (lower $pp) -}}
{{- if .auto -}}
{{- if or (eq .path $pp) (not $cs) -}}
{{- fail (printf "gateway.authentication.protectedPaths %q on service %s is already kept on the protected route as the OIDC %s path; remove it." $pp $name (ternary "logout" "callback" (eq .pathType "Exact"))) -}}
{{- end -}}
{{- else if ne .caseSensitive $cs -}}
{{- fail (printf "gateway.authentication.protectedPaths entries %q and %q on service %s are one prefix in different case but differ in caseSensitive. Keep one, or make both caseSensitive." .path $pp $name) -}}
{{- else if or (eq .path $pp) (not $cs) -}}
{{- $dup = true -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if not $dup -}}
{{- /* Default: case-insensitive regex on a whole segment. Envoy Gateway ranks Exact, then RegularExpression, then PathPrefix (internal/gatewayapi/sort.go), so it wins over the -public remainder. caseSensitive opts into a native PathPrefix in this spelling only. */ -}}
{{- $rules = append $rules (dict "path" $pp "match" (ternary $pp (printf "(?i)^%s(/.*)?$" (regexQuoteMeta $pp)) $cs) "pathType" (ternary "PathPrefix" "RegularExpression" $cs) "auto" false "caseSensitive" $cs) -}}
{{- end -}}
{{- end -}}
{{- /* An oidc.apiRoutes matcher lives on the policy, which targets only the protected route: outside every protected prefix it is never reached and API callers get a redirect instead of a 401. It runs on :path, which carries the query string, so only the path part is compared. */ -}}
{{- range (($p.oidc | default dict).apiRoutes | default list) -}}
{{- $ap := regexReplaceAll "\\?.*$" (.path | default "") "" -}}
{{- if eq (.matchType | default "Prefix") "RegularExpression" -}}
{{- fail (printf "securityPolicies oidc.apiRoutes entry %q uses RegularExpression, which the chart cannot place under a gateway.authentication.protectedPaths prefix of service %s. Use Prefix or Exact." $ap $name) -}}
{{- end -}}
{{- $under := false -}}
{{- range $rules -}}
{{- $a := ternary $ap (lower $ap) .caseSensitive -}}
{{- $b := ternary .path (lower .path) .caseSensitive -}}
{{- if and (not .auto) (or (eq $a $b) (hasPrefix (printf "%s/" $b) $a)) -}}{{- $under = true -}}{{- end -}}
{{- end -}}
{{- if not $under -}}
{{- fail (printf "securityPolicies oidc.apiRoutes entry %q is not under a gateway.authentication.protectedPaths prefix of service %s, so the public route would serve it. Move it, give the service its own policy, or remove it." $ap $name) -}}
{{- end -}}
{{- end -}}
{{- /* Fail closed on shapes the edge does not normalise: a matrix parameter (/admin;x) or an encoded octet (/adm%69n) can reach a protected handler on a backend that strips or decodes them, so every path on the host carrying ; or % goes to the protected route. */ -}}
{{- /* Appended last so the rule count and the collision loop below see it; the loop skips it via .guard. */ -}}
{{- $rules = append $rules (dict "path" "" "match" "^.*[;%].*$" "pathType" "RegularExpression" "auto" true "guard" true "caseSensitive" true) -}}
{{- $autoCount := 0 -}}
{{- range $rules -}}
{{- if .auto -}}{{- $autoCount = add1 $autoCount -}}{{- end -}}
{{- if gt (len .match) 1024 -}}
{{- fail (printf "%s %q on service %s renders a %d-character match; the HTTPRoute API allows 1024. Shorten the prefix or its base path." (ternary "the automatic OIDC path" "gateway.authentication.protectedPaths" .auto) .path $name (len .match)) -}}
{{- end -}}
{{- end -}}
{{- if gt (len $rules) 16 -}}
{{- fail (printf "service %s would render %d rules on its protected HTTPRoute (%d prefixes plus %d automatic rules); the HTTPRoute API allows 16. Protect at most %d prefixes." $name (len $rules) (sub (len $rules) $autoCount) $autoCount (sub 16 $autoCount)) -}}
{{- end -}}
{{- /* Every gateway.paths entry must be strictly broader than every protected prefix, callback and logout included: an equal or narrower entry on the -public route wins Gateway API precedence and serves the protected path without authentication. */ -}}
{{- range $pr := $rules -}}
{{- range $g.paths -}}
{{- $gp := .path | default "/" -}}
{{- $cg := ternary $gp (lower $gp) $pr.caseSensitive -}}
{{- $cp := ternary $pr.path (lower $pr.path) $pr.caseSensitive -}}
{{- if and (not $pr.guard) (or (eq (trimSuffix "/" $cg) $cp) (hasPrefix (printf "%s/" $cp) $cg)) -}}
{{- fail (printf "gateway.paths entry %q on service %s collides with %s %q; the public route would shadow the protected one. Remove it from gateway.paths." $gp $name (ternary "the OIDC path" "gateway.authentication.protectedPaths" $pr.auto) $pr.path) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- /* The guard rule takes every ; or % path on the host and outranks any sibling's PathPrefix, so the service must be alone on its host, vanity and gateway.rules hosts included. */ -}}
{{- range $otherName, $_ := fromYaml (include "stack.networkEndpoints" $root) -}}
{{- $og := (fromYaml (include "service.context" (dict "root" $root "name" $otherName))).gateway | default dict -}}
{{- if and (ne $otherName $name) $og.enabled (not (($og.tlsPassthrough | default dict).enabled)) -}}
{{- $hosts := list -}}
{{- range append ($og.rules | default list) $og -}}
{{- $hosts = append $hosts (.host | default "") -}}
{{- if ((.vanity | default dict).enabled) -}}{{- $hosts = append $hosts ((.vanity | default dict).hostname | default "") -}}{{- end -}}
{{- end -}}
{{- if has $g.host $hosts -}}
{{- fail (printf "service %s also routes host %s. gateway.authentication.protectedPaths on service %s sends every ; or %% path on that host to its own route, so it must be alone on the host. Move one, or use the protected default." $otherName $g.host $name) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- toYaml $rules -}}
{{- end -}}
